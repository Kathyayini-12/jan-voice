/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Complaint, ComplaintStatus, Priority } from '../types';

const CATEGORIES = [
  {
    category: 'Roads',
    department: 'Ministry of Road Transport & Highways / PWD',
    titles: [
      'Deep pothole hazard near main crossing',
      'Cracked asphalt and waterlogging on main road',
      'Missing manhole cover on pedestrian pathway',
      'Damaged flyover joint creating high-speed bumps',
      'Incomplete road construction causing severe dust pollution'
    ],
    descriptions: [
      'A massive pothole of size 3x4 feet has formed right in the middle of the road. Multiple motorbikes have slipped during night hours. Water logging makes it impossible to spot.',
      'The entire stretch of the road has lost its top layer. Heavy rains have caused severe mud formation and waterlogging, making it inaccessible for small cars.',
      'There is an open manhole on the busy shopping street near the primary school. It poses a grave danger to children and blind pedestrians. Urgent action is requested.',
      'The expansion joint of the main flyover has gaped wide open. Cars passing over it at 40km/h experience heavy shocks, raising structural safety concerns.',
      'The municipal contractor abandoned the road digging halfway. Due to heavy traffic, fine dust has filled the air, causing severe breathing issues for elderly residents.'
    ],
    actions: [
      'Deploy rapid asphalt patching team and barricade the zone.',
      'Initiate full road resurfacing work order under ward budget.',
      'Settle standard iron manhole cover and seal edges immediately.',
      'Bridge structural joint with rubber padding and steel plates.',
      'Sprinkle water to suppress dust and issue penalty notice to contractor.'
    ],
    resolutionTimes: ['24 Hours', '5 Days', '12 Hours', '3 Days', '2 Days']
  },
  {
    category: 'Water',
    department: 'Ministry of Jal Shakti / Municipal Water Board',
    titles: [
      'Water pipeline burst wasting thousands of liters',
      'Highly contaminated brown water supply in taps',
      'No water supply for the last 5 days in sector',
      'Leaking valve causing continuous flooding of street',
      'Low water pressure in municipal lines'
    ],
    descriptions: [
      'The main drinking water pipe has ruptured near the junction. Water is gushing out like a fountain, flooding the adjacent road and wasting precious municipal supply.',
      'The water coming out of our household taps is dark brown, smelling foul and containing tiny mud particles. Several children have been admitted for dysentery.',
      'We have had zero water supply in Block B for the last five days. The community tanker is charging exorbitant rates, causing heavy financial distress.',
      'A major valve in the distribution line has developed a high-pressure leak. Thousands of gallons are draining into the sewer daily, turning the street into a swamp.',
      'The water pressure is so low that it doesn\'t even reach the ground floor tanks. We have to use external pumps which is burning out our electricity grids.'
    ],
    actions: [
      'Dispatch water engineering division to shut main valve and clamp rupture.',
      'Flushing municipal lines and inspect for sewage line crossover leak.',
      'Resume backup line pumps and send 3 free government water tankers.',
      'Replace leaking brass control valve and reinforce concrete casing.',
      'Inspect sub-station booster pumps and clean supply blockages.'
    ],
    resolutionTimes: ['6 Hours', '36 Hours', '12 Hours', '18 Hours', '2 Days']
  },
  {
    category: 'Electricity',
    department: 'Ministry of Power / State DisCom',
    titles: [
      'Sparking transformer putting residential block at risk',
      'Hanging high-voltage live wires touching tree branches',
      'Prolonged unannounced 12-hour power load shedding',
      'Damaged digital sub-station meter causing billing spikes',
      'Broken streetlights making pathway dark and unsafe'
    ],
    descriptions: [
      'The pole-mounted transformer is sparking heavily every few minutes. Strong burning smell is coming and nearby houses are experiencing severe voltage surges.',
      'Heavy winds have caused high-tension electric cables to sag. They are hanging just 6 feet above the street, touching branches. One spark could ignite a massive fire.',
      'We are facing unscheduled power cuts of up to 12 hours daily during peak summer. Elderly people are suffering and students are unable to prepare for board exams.',
      'The residential cluster meter is malfunctioning, showing 4x consumption. This month citizens have received utility bills of ₹25,000, creating massive panic.',
      'The entire street light network from the bus stand to our colony is broken. antisocial elements gather, making it extremely unsafe for women and seniors.'
    ],
    actions: [
      'Isolate transformer and dispatch line crew for immediate replacement.',
      'Emergency shutoff of line, trim branches, and pull cables taut.',
      'Adjust load distribution and coordinate emergency grid supply lines.',
      'Replace collective digital meter and issue corrected credit vouchers.',
      'Replace old sodium lamps with modern high-efficiency energy-saving LED lamps.'
    ],
    resolutionTimes: ['4 Hours', '8 Hours', '24 Hours', '2 Days', '36 Hours']
  },
  {
    category: 'Garbage',
    department: 'Municipal Corporation / Solid Waste Management',
    titles: [
      'Overflowing garbage dumpster causing terrible stench',
      'Illegal toxic waste dumping behind community park',
      'No doorstep garbage collection for over two weeks',
      'Stagnant waste breeding swarms of mosquitoes',
      'Biomedical clinic throwing used syringes in civic bins'
    ],
    descriptions: [
      'The large municipal waste bin has not been cleared for 8 days. Garbage is spilling over 20 meters, blocking the pathway. Stray dogs are tearing it open, causing an unbearable smell.',
      'An industrial truck dumped plastic barrels filled with chemical sludge right behind our children\'s park. It is smelling strongly of sulfur and burning our eyes.',
      'The door-to-door sanitation cart has stopped coming to our lane. Residents are forced to dump waste on the roadside, breaking all hygiene norms.',
      'A pile of rotting organic waste has mixed with rainwater, forming a stagnant black puddle. Swarms of mosquitoes are breeding, raising local dengue fears.',
      'A local dental and diagnostic clinic is dumping medical waste, including syringes, blood bandages, and vials directly into public bins, risking sanitation workers.'
    ],
    actions: [
      'Dispatch compacting truck and deep-clean dumpster site with chlorine.',
      'Seal toxic dump site, deploy hazardous material team, trace vehicle via CCTV.',
      'Reinstate daily cart schedules and issue warnings to ward sanitation staff.',
      'Clear organic residue, spray anti-larval mosquito fogging chemicals.',
      'Issue immediate show-cause notice and seal clinic for biological hazard.'
    ],
    resolutionTimes: ['12 Hours', '24 Hours', '3 Days', '18 Hours', '12 Hours']
  },
  {
    category: "Women's Safety",
    department: 'State Police / Women Safety Cell',
    titles: [
      'Catcalling and harassment hotspot near girls college',
      'Zero patrolling in dark alleys near central metro transit',
      'Stalking incident reported near central library lane',
      'Peeping tom and security breach in public ladies restroom',
      'Liquor shop opened next to girls hostel causing security issues'
    ],
    descriptions: [
      'Groups of boys stand near the girls high school gate during dispersal hours. They pass vulgar remarks, block paths, and follow students. Girls feel deeply unsafe.',
      'The connecting pathway from the railway station is completely dark due to dead lights. Antisocial groups drink alcohol openly there, harassing lone female commuters.',
      'A group of men in a black car has been stalking female students heading to the library every evening. This has created a heavy climate of fear in the ward.',
      'The safety lock on the ladies municipal restroom has been broken. Yesterday a suspicious male was found loitering inside the common wash basin zone.',
      'A local liquor vend has opened directly adjacent to the university girls hostel. Drinkers loiter on the road, play loud music, and pass lewd comments.'
    ],
    actions: [
      'Deploy undercover female officers (She-Teams) and setup permanent police post.',
      'Establish a regular evening police patrolling route and order street lighting repair.',
      'Review CCTV cameras around the library block and register an FIR.',
      'Deploy structural repair team to fix security doors and appoint a warden.',
      'Review license conditions, issue temporary suspension, and enforce curfew.'
    ],
    resolutionTimes: ['2 Hours', '4 Hours', '6 Hours', '12 Hours', '24 Hours']
  },
  {
    category: 'Education',
    department: 'Department of School Education & Literacy',
    titles: [
      'Dilapidated ceiling falling in primary school classroom',
      'No clean drinking water facility in government high school',
      'Broken toilets forcing girls to drop out of school',
      'Shortage of textbooks and basic writing desks',
      'Teacher absenteeism in village primary school'
    ],
    descriptions: [
      'A large portion of the concrete plaster fell from the ceiling of Class IV during school hours. Luckily, it was Sunday. The beams are rusted and unsafe.',
      'The government high school water cooler is broken and rusted. Students are forced to drink water from a common tap connected to an raw borewell.',
      'All three toilets for female students are choked and have broken doors. Due to lack of basic sanitation, girls are skipping classes during their periods.',
      'Over 80 students are sitting on cold concrete floors as there are no desks. Also, the mid-day meal quality has deteriorated, smelling stale.',
      'The main mathematics teacher has not visited the village school for the last 3 weeks, leaving the students syllabus completely stranded before exams.'
    ],
    actions: [
      'Declare classroom structurally condemned and dispatch repair contractors.',
      'Install heavy-duty UV water purifier and stainless steel drinking fountain.',
      'Sanction immediate funds for toilet rebuilding and hire a daily cleaner.',
      'Procure 50 dual-desks and order deep audit of mid-day meal vendors.',
      'Issue warning letter to the principal and deploy a guest teacher.'
    ],
    resolutionTimes: ['2 Days', '24 Hours', '3 Days', '5 Days', '48 Hours']
  }
];

const CITIZEN_NAMES = [
  'Varada Venugopal', 'Srinivas Rao', 'K. Kathyayini', 'Rajkumar Patnaik', 'M. Anuradha',
  'G. Subbalakshmi', 'V. Jagannadham', 'Ch. Satyanarayana', 'P. Ramadevi', 'B. Venkateswarlu',
  'S. Meenakshi', 'Y. Srinivasa Reddy', 'T. Appala Raju', 'V. Sandhya', 'K. Rama Krishna'
];

const NEIGHBORHOODS = [
  'Gajuwaka Junction, Visakhapatnam North',
  'Madhurawada, Visakhapatnam North',
  'Muralinagar Sector 2, Visakhapatnam North',
  'Akkayyapalem Market Road, Visakhapatnam North',
  'Seethammadhara Block A, Visakhapatnam North',
  'MVP Colony Sector 4, Visakhapatnam North',
  'Kancharapalem High School Lane, Visakhapatnam North',
  'Dwaraka Nagar 3rd Lane, Visakhapatnam North',
  'Siripuram circle, Visakhapatnam North',
  'Gopalapatnam Highway Road, Visakhapatnam North'
];

const COMPLAINT_STATUSES: ComplaintStatus[] = ['Pending', 'In Progress', 'Resolved', 'Rejected'];

/**
 * Generate 65 high-quality complaints
 */
export function generateComplaints(): Complaint[] {
  const list: Complaint[] = [];

  // 1. First add the handcrafted 6 complaints we know and love (shifted to Visakhapatnam locations)
  const handcrafted: Complaint[] = [
    {
      id: 'JV-2026-9041',
      category: 'Roads',
      title: 'Severe Potholes on Gajuwaka Junction Flyover Link',
      description: 'There are huge potholes that have appeared near the main Gajuwaka junction. This has caused three two-wheeler accidents in the last 48 hours. Water gets logged in them making them invisible during night hours.',
      reporter: 'Rajesh Sharma',
      phone: '9876543210',
      location: 'Gajuwaka Junction, Visakhapatnam North',
      department: 'Ministry of Road Transport & Highways / PWD',
      status: 'In Progress',
      priority: 'High',
      date: '2026-07-02',
      image: 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80',
      lat: 17.6904,
      lng: 83.2084,
      assignedWorker: 'AE Satish Yadav',
      updates: [
        { date: '2026-07-02', status: 'Submitted', note: 'Complaint filed via JanVoice AI with photo and voice evidence.', officer: 'System Auto-Route' },
        { date: '2026-07-03', status: 'In Progress', note: 'Inspected by Vizag Municipal Corp Engineer, patching scheduled.', officer: 'EE Vinay Mishra' }
      ],
      urgencyScore: 8,
      impactScore: 9,
      verificationScore: 9,
      feasibilityScore: 8,
      priorityScore: 92,
      affectedCount: 14200,
      verificationConfidence: 96,
      gpsVerified: true,
      suggestedAction: 'Deploy instant thermal asphalt patch and place flashing safety barrier.',
      estimatedResolutionTime: '24 Hours',
      aiExplanation: 'High Priority because 14,200 citizens are affected and severe road accident risk is detected near Gajuwaka junction.'
    },
    {
      id: 'JV-2026-8942',
      category: 'Water',
      title: 'Water Pipeline Burst near Muralinagar Sector 2',
      description: 'The primary distribution pipeline has burst. Millions of liters of drinking water are being wasted and flooding the local park. This has completely starved Sector 2 water tanks.',
      reporter: 'Varada Venugopal',
      phone: '8765432109',
      location: 'Muralinagar Sector 2, Visakhapatnam North',
      department: 'Ministry of Jal Shakti / Municipal Water Board',
      status: 'Pending',
      priority: 'Critical',
      date: '2026-07-07',
      lat: 17.7423,
      lng: 83.2845,
      updates: [
        { date: '2026-07-07', status: 'Submitted', note: 'AI Auto-categorized as Critical due to clean water crisis and road collapse risk.', officer: 'AI Agent JanVoice' }
      ],
      urgencyScore: 10,
      impactScore: 10,
      verificationScore: 9,
      feasibilityScore: 9,
      priorityScore: 95,
      affectedCount: 12430,
      verificationConfidence: 98,
      gpsVerified: true,
      suggestedAction: 'Immediate repair recommended. Shut main reservoir valve #12, isolate pipeline, weld high-density PVC sleeve. Delay may affect hospitals and schools.',
      estimatedResolutionTime: '6 Hours',
      aiExplanation: 'Critical Priority because 12,430 citizens are affected and water reservoir pipeline rupture risk is detected.'
    },
    {
      id: 'JV-2026-8743',
      category: 'Water',
      title: 'Contaminated Muddy Water Supply in Dwaraka Nagar',
      description: 'The tap water supplied today is dark brown and smelling like chemical waste. We suspect sewage water line has cracked and mixed with the fresh water pipeline. Children are falling sick.',
      reporter: 'Meera Deshmukh',
      phone: '7654321098',
      location: 'Dwaraka Nagar 3rd Lane, Visakhapatnam North',
      department: 'Ministry of Jal Shakti / Municipal Water Board',
      status: 'In Progress',
      priority: 'Critical',
      date: '2026-07-06',
      lat: 17.7289,
      lng: 83.3067,
      assignedWorker: 'Inspector K. Apparao',
      updates: [
        { date: '2026-07-06', status: 'Submitted', note: 'Verified by GPS coordinate check and auto-assigned.', officer: 'AI Agent JanVoice' },
        { date: '2026-07-07', status: 'In Progress', note: 'Testing lab collected water samples. Excavation begun to find joint breach.', officer: 'Inspector K. Apparao' }
      ],
      urgencyScore: 9,
      impactScore: 10,
      verificationScore: 10,
      feasibilityScore: 7,
      priorityScore: 91,
      affectedCount: 8900,
      verificationConfidence: 97,
      gpsVerified: true,
      suggestedAction: 'Flush water grid, deploy mobile chemical testing lab, bypass Sector-4 link.',
      estimatedResolutionTime: '12 Hours',
      aiExplanation: 'Critical Priority because 8,900 citizens are affected by water-borne epidemic and sewage line crossover contamination is detected.'
    },
    {
      id: 'JV-2026-8451',
      category: "Women's Safety",
      title: 'Dark Alley and Harassment near MVP Colony Bus Stop',
      description: 'The lane behind MVP Colony bus stand has broken streetlights. Young women return from coaching centers at night and are harassed by anti-social groups drinking alcohol in the dark.',
      reporter: 'Anjali Sharma',
      phone: '9988776655',
      location: 'MVP Colony Sector 4, Visakhapatnam North',
      department: 'State Police / Women Safety Cell',
      status: 'In Progress',
      priority: 'Critical',
      date: '2026-07-05',
      lat: 17.7441,
      lng: 83.3325,
      assignedWorker: 'SI Neha Singh',
      updates: [
        { date: '2026-07-05', status: 'Submitted', note: 'Emergency flag raised automatically. Routed to police and municipal department.', officer: 'AI Verification' },
        { date: '2026-07-06', status: 'In Progress', note: 'Police patrolling car designated to park at bus stop from 7 PM to 10 PM. Lights repair ordered.', officer: 'SI Neha Singh' }
      ],
      urgencyScore: 9,
      impactScore: 9,
      verificationScore: 9,
      feasibilityScore: 9,
      priorityScore: 94,
      affectedCount: 3500,
      verificationConfidence: 94,
      gpsVerified: true,
      suggestedAction: 'Set up Police PCR patrol vehicle, dispatch municipal team to fit instant 40W LED lamps.',
      estimatedResolutionTime: '8 Hours',
      aiExplanation: 'Critical Priority because 3,500 students and female commuters are affected by broken street lights and active security threat is detected.'
    }
  ];

  list.push(...handcrafted);

  // 2. Generate 60 additional random realistic complaints to reach ~65, fully distributed
  let currentIdCounter = 8300;
  
  // Spread over coordinates in Visakhapatnam North (Lat: 17.68 to 17.78, Lng: 83.20 to 83.35)
  for (let i = 0; i < 60; i++) {
    const catGroup = CATEGORIES[i % CATEGORIES.length];
    const itemIndex = Math.floor(Math.random() * catGroup.titles.length);
    
    const category = catGroup.category;
    const department = catGroup.department;
    const title = catGroup.titles[itemIndex];
    const description = catGroup.descriptions[itemIndex];
    const suggestedAction = catGroup.actions[itemIndex];
    const estimatedResolutionTime = catGroup.resolutionTimes[itemIndex];
    
    const reporter = CITIZEN_NAMES[Math.floor(Math.random() * CITIZEN_NAMES.length)];
    const phone = '9' + Math.floor(100000000 + Math.random() * 900000000).toString().substring(0, 9);
    const location = NEIGHBORHOODS[Math.floor(Math.random() * NEIGHBORHOODS.length)];
    
    // Status distribution: 30% Pending, 40% In Progress, 20% Resolved, 10% Rejected
    let status: ComplaintStatus = 'Pending';
    const randStatus = Math.random();
    if (randStatus > 0.9) status = 'Rejected';
    else if (randStatus > 0.7) status = 'Resolved';
    else if (randStatus > 0.3) status = 'In Progress';
    
    // Priorities based on category
    let priority: Priority = 'Medium';
    if (category === "Women's Safety" || category === 'Water') {
      priority = Math.random() > 0.4 ? 'Critical' : 'High';
    } else if (category === 'Roads' || category === 'Electricity') {
      priority = Math.random() > 0.5 ? 'High' : 'Medium';
    } else {
      priority = Math.random() > 0.6 ? 'Medium' : 'Low';
    }

    const d = new Date();
    d.setDate(d.getDate() - Math.floor(Math.random() * 20));
    const date = d.toISOString().split('T')[0];
    
    // Visakhapatnam North Bounding Box
    const lat = 17.68 + Math.random() * 0.10;
    const lng = 83.20 + Math.random() * 0.15;
    
    // AI Metrics
    const urgencyScore = priority === 'Critical' ? 9 + Math.floor(Math.random() * 2) :
                         priority === 'High' ? 7 + Math.floor(Math.random() * 2) :
                         priority === 'Medium' ? 5 + Math.floor(Math.random() * 2) : 2 + Math.floor(Math.random() * 3);

    const impactScore = Math.floor(4 + Math.random() * 7); // 4 - 10
    const verificationScore = Math.floor(6 + Math.random() * 5); // 6 - 10
    const feasibilityScore = Math.floor(5 + Math.random() * 6); // 5 - 10
    
    // Priority score out of 100 based on the formula
    // Score = Verification Score × Urgency Score × Impact Score × Feasibility Score
    // Let's scale it between 35 and 99
    const rawMult = (urgencyScore * impactScore * verificationScore * feasibilityScore);
    const priorityScore = Math.min(98, Math.max(35, Math.floor(35 + (rawMult / 10000) * 63)));

    const affectedCount = priority === 'Critical' ? Math.floor(5000 + Math.random() * 10000) :
                           priority === 'High' ? Math.floor(1000 + Math.random() * 4000) :
                           Math.floor(50 + Math.random() * 950);

    const verificationConfidence = Math.floor(75 + Math.random() * 24);
    const gpsVerified = Math.random() > 0.15;
    
    const isDuplicate = i > 40 && Math.random() > 0.7; // some duplicates
    const duplicateParentId = isDuplicate ? list[Math.floor(Math.random() * 20)].id : undefined;
    
    const updates: Complaint['updates'] = [{ date, status: 'Submitted' as ComplaintStatus, note: 'AI Auto-parsed, verified, and mapped.' }];
    if (status === 'In Progress' || status === 'Resolved' || status === 'Rejected') {
      const upDate = new Date(date);
      upDate.setDate(upDate.getDate() + 1);
      updates.push({ 
        date: upDate.toISOString().split('T')[0], 
        status, 
        note: status === 'Resolved' ? 'Verified resolved. Infrastructure checked.' : 
              status === 'Rejected' ? 'Duplicate of existing ticket. Citizen notified.' : 'Assigned to field engineer.',
        officer: 'Ward Superintendent'
      });
    }

    currentIdCounter -= 1;

    let riskFactor = 'general civic inconvenience detected';
    if (category === 'Roads') riskFactor = 'high pothole damage and vehicle transit risks detected';
    else if (category === 'Water') riskFactor = 'clean drinking water outage and residential water crisis detected';
    else if (category === 'Electricity') riskFactor = 'overhead sparking hazard and fire breakout risk detected';
    else if (category === "Women's Safety") riskFactor = 'street harassment and critical dark-spot incident risk detected';
    else if (category === 'Garbage') riskFactor = 'epidemic risk and open-air municipal health hazard detected';
    else if (category === 'Health') riskFactor = 'medical response lag and secondary disease breakout risk detected';
    else if (category === 'Education') riskFactor = 'government school safety hazard and basic utility outage detected';
    else if (category === 'Agriculture') riskFactor = 'crop damage risk and irrigation canal blockage detected';

    const aiExplanation = `${priority} Priority because ${affectedCount.toLocaleString()} citizens are affected and ${riskFactor}.`;
    
    list.push({
      id: `JV-2026-${currentIdCounter}`,
      category,
      title,
      description,
      reporter,
      phone,
      location,
      department,
      status,
      priority,
      date,
      lat,
      lng,
      updates,
      urgencyScore,
      impactScore,
      verificationScore,
      feasibilityScore,
      priorityScore,
      affectedCount,
      verificationConfidence,
      gpsVerified,
      suggestedAction,
      estimatedResolutionTime,
      isDuplicate,
      duplicateParentId,
      aiExplanation
    });
  }

  return list;
}
