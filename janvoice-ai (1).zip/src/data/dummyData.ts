/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Complaint, Department, Scheme, VillageStatus } from '../types';

export const DUMMY_DEPARTMENTS: Department[] = [
  {
    id: 'dept-roads',
    name: 'Ministry of Road Transport & Highways / PWD',
    head: 'Shri Nitin Gadkari (Union Minister) / Dr. A. K. Sharma (State Chief)',
    staffCount: 142,
    unresolvedCount: 18,
    resolvedCount: 312,
    rating: 4.6,
  },
  {
    id: 'dept-water',
    name: 'Ministry of Jal Shakti / Municipal Water Board',
    head: 'Shri C. R. Patil (Union Minister) / Smt. Rekha Vyas (Director)',
    staffCount: 95,
    unresolvedCount: 22,
    resolvedCount: 185,
    rating: 4.1,
  },
  {
    id: 'dept-power',
    name: 'Ministry of Power / State DisCom',
    head: 'Shri Manohar Lal (Union Minister) / Shri R. K. Mittal (Superintendent Eng.)',
    staffCount: 110,
    unresolvedCount: 11,
    resolvedCount: 298,
    rating: 4.4,
  },
  {
    id: 'dept-waste',
    name: 'Municipal Corporation / Solid Waste Management',
    head: 'Smt. Ananya Rao (Commissioner) / Shri Suresh Kumar (Chief Inspector)',
    staffCount: 250,
    unresolvedCount: 35,
    resolvedCount: 512,
    rating: 3.9,
  },
  {
    id: 'dept-health',
    name: 'Ministry of Health & Family Welfare / Chief Medical Office',
    head: 'Shri J. P. Nadda (Union Minister) / Dr. Sunita Deshmukh (CMO)',
    staffCount: 180,
    unresolvedCount: 8,
    resolvedCount: 145,
    rating: 4.5,
  },
  {
    id: 'dept-safety',
    name: 'State Police / Women Safety Cell',
    head: 'Shri Amit Shah (Union Minister) / Smt. Kiran Bedi (Adviser Emeritus)',
    staffCount: 160,
    unresolvedCount: 5,
    resolvedCount: 220,
    rating: 4.8,
  },
  {
    id: 'dept-edu',
    name: 'Department of School Education & Literacy',
    head: 'Shri Dharmendra Pradhan (Union Minister) / Smt. Meena Sen (Education Officer)',
    staffCount: 85,
    unresolvedCount: 14,
    resolvedCount: 95,
    rating: 4.2,
  },
  {
    id: 'dept-agri',
    name: 'Ministry of Agriculture & Farmers Welfare',
    head: 'Shri Shivraj Singh Chouhan (Union Minister) / Shri Ram Swaroop (Agri Extension Officer)',
    staffCount: 75,
    unresolvedCount: 12,
    resolvedCount: 160,
    rating: 4.3,
  }
];

export const DUMMY_SCHEMES: Scheme[] = [
  {
    id: 'scheme-ayushman',
    title: 'Ayushman Bharat Pradhan Mantri Jan Arogya Yojana (PM-JAY)',
    ministry: 'Ministry of Health and Family Welfare',
    description: 'Provides free health insurance cover of up to ₹5 Lakh per family per year for secondary and tertiary care hospitalization.',
    benefits: 'Cashless treatment, covers pre & post-hospitalization, and over 1,350 medical procedures included.',
    category: 'Healthcare'
  },
  {
    id: 'scheme-jjm',
    title: 'Jal Jeevan Mission (JJM)',
    ministry: 'Ministry of Jal Shakti',
    description: 'Aims to provide safe and adequate drinking water through individual household tap connections by 2024 to all households in rural India.',
    benefits: '55 liters of clean water per capita per day, regular water testing, and community-led local management.',
    category: 'Water'
  },
  {
    id: 'scheme-kisan',
    title: 'Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)',
    ministry: 'Ministry of Agriculture & Farmers Welfare',
    description: 'An initiative by the Government of India that guarantees ₹6,000 per year in three equal installments to all landholding farmer families.',
    benefits: 'Direct benefit transfer (DBT) into bank accounts, support for seeds/fertilizer purchases, and crop inputs.',
    category: 'Agriculture'
  },
  {
    id: 'scheme-awas',
    title: 'Pradhan Mantri Awas Yojana (PMAY) - Gramin & Urban',
    ministry: 'Ministry of Housing and Urban Affairs / Rural Development',
    description: 'A flagship mission of the Government of India to provide an all-weather pucca house with basic amenities to all eligible beneficiaries.',
    benefits: 'Financial assistance of up to ₹1.2 Lakh (Rural) or interest subsidies on home loans up to 6.5% (Urban).',
    category: 'Housing'
  },
  {
    id: 'scheme-sbm',
    title: 'Swachh Bharat Mission (SBM) 2.0',
    ministry: 'Ministry of Housing and Urban Affairs / Jal Shakti',
    description: 'Accelerates sanitation efforts, focusing on solid waste management, making cities ODF (Open Defecation Free) plus, and recycling.',
    benefits: 'Subsidy for toilet construction, door-to-door garbage collection systems, and community composting facilities.',
    category: 'Garbage'
  }
];

import { generateComplaints } from './complaintsGenerator';

export const INITIAL_COMPLAINTS: Complaint[] = generateComplaints();


export const DUMMY_VILLAGES: VillageStatus[] = [
  {
    name: 'Kalyanpur Khas',
    complaintsCount: 42,
    resolvedCount: 35,
    infrastructureScore: 82,
    waterScore: 78,
    healthScore: 85,
    safetyScore: 90,
  },
  {
    name: 'Ramgarh',
    complaintsCount: 68,
    resolvedCount: 41,
    infrastructureScore: 54,
    waterScore: 48,
    healthScore: 62,
    safetyScore: 58,
  },
  {
    name: 'Mohanpur',
    complaintsCount: 51,
    resolvedCount: 38,
    infrastructureScore: 68,
    waterScore: 71,
    healthScore: 60,
    safetyScore: 72,
  },
  {
    name: 'Shantipur',
    complaintsCount: 29,
    resolvedCount: 26,
    infrastructureScore: 89,
    waterScore: 85,
    healthScore: 88,
    safetyScore: 94,
  },
  {
    name: 'Gopalpur',
    complaintsCount: 55,
    resolvedCount: 45,
    infrastructureScore: 71,
    waterScore: 59,
    healthScore: 75,
    safetyScore: 70,
  },
  {
    name: 'Bhimpur Block B',
    complaintsCount: 78,
    resolvedCount: 48,
    infrastructureScore: 45,
    waterScore: 39,
    healthScore: 50,
    safetyScore: 55,
  }
];

export const FAQ_ITEMS = [
  {
    q: 'How does JanVoice AI automatically route complaints?',
    a: 'When you submit a complaint via text, voice, or photo, our advanced server-side AI model parses your input. It automatically identifies the category (e.g., Water, Roads), detects the priority level based on emergency words, translates the regional language to English, extracts geographic coordinates from your photo metadata or GPS pin, and forwards it to the correct government officer of that specific ward instantly.'
  },
  {
    q: 'Can I submit complaints in my local regional language?',
    a: 'Absolutely! You can write or speak in Hindi, Tamil, Telugu, Marathi, Bengali, Gujarati, Kannada, Punjabi, and many more. JanVoice AI includes real-time translation that transcribes and translates regional speeches or text into bilingual records for officers and MPs, while keeping your original native copy intact.'
  },
  {
    q: 'What makes JanVoice AI different from normal portal complaint systems?',
    a: 'Unlike normal portals which take weeks to manually route and analyze, JanVoice AI prioritizes issues instantly. It groups duplicate complaints from the same street together so that multiple reports about the same pothole are combined into one master ticket. This prevents duplicate dispatch, alerts the MP directly of critical hot zones, and generates automated risk forecasts for upcoming monsoons or dry spells.'
  },
  {
    q: 'Is my personal identity kept confidential?',
    a: 'Yes, your safety is paramount. When reporting corruption, women safety issues, or community-sensitive concerns, you can choose to enable the "Anonymize Identity" toggle. The government officer will only see the issue description, coordinates, and photo without any phone or name tags.'
  },
  {
    q: 'How is Member of Parliament (MP) involved?',
    a: 'Your local MP gets a direct premium dashboard. They can monitor the resolving speeds of different officers, compare which villages are falling behind in infrastructure and water, examine complaint density heatmaps, and read AI insights to plan where to allocate rural and constituency development budgets (MPLADS).'
  }
];

export const NEWS_UPDATES = [
  {
    title: 'JanVoice AI launches Voice-to-Complaint in 12 Regional Indian Languages',
    date: 'July 01, 2026',
    category: 'Technology Update',
    summary: 'Citizens can now record complaints in Marathi, Bengali, Tamil, Kannada, and others. The system will transcribe, categorize, and auto-route them in real-time.'
  },
  {
    title: 'Kalyanpur MP Allocates ₹2.4 Crore for AI-Identified High Risk Water Zones',
    date: 'June 25, 2026',
    category: 'Policy & Development',
    summary: 'Using the MP executive dashboard insights, the local Member of Parliament has authorized water pipeline upgrades for 4 critical water-scarce villages.'
  },
  {
    title: 'Monsoon Preparedness: Duplicate Complaint grouping reduces Municipal workload by 40%',
    date: 'June 18, 2026',
    category: 'Efficiency Milestone',
    summary: 'By auto-grouping multiple citizen reports of clogged drains in the same block, the Municipal Corporation dispatched single response teams, saving budget and fuel.'
  }
];
