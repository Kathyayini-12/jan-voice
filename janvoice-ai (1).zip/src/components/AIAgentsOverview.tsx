/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Brain, 
  ShieldAlert, 
  Copy, 
  Cpu, 
  Layers, 
  Volume2, 
  TrendingUp, 
  Database,
  CheckCircle,
  Eye,
  ArrowRight,
  RefreshCw,
  Search,
  MessageSquare,
  AlertTriangle,
  Play,
  FileCheck
} from 'lucide-react';
import { motion } from 'motion/react';
import { Complaint } from '../types';

interface AIAgentsProps {
  complaints: Complaint[];
}

export default function AIAgentsOverview({ complaints }: AIAgentsProps) {
  const [activeAgent, setActiveAgent] = useState<string>('analysis');
  const [demoInputText, setDemoInputText] = useState<string>(
    "There is a huge pothole near Gajuwaka Junction that has already caused two accidents. Water is pooling inside it making it invisible after sunset."
  );
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  const agents = [
    {
      id: 'analysis',
      name: 'AI Complaint Analysis Agent',
      desc: 'Performs lexical scanning and classification of complaints.',
      icon: Brain,
      color: 'from-blue-500 to-indigo-600',
      badge: 'Cognitive Engine'
    },
    {
      id: 'priority',
      name: 'AI Priority Score Agent',
      desc: 'Calculates priority using our 4-factor mathematical equation.',
      icon: TrendingUp,
      color: 'from-amber-500 to-orange-600',
      badge: 'Decision Matrix'
    },
    {
      id: 'duplicate',
      name: 'AI Duplicate Detection Agent',
      desc: 'Identifies geo-spatial duplicates and merges clusters.',
      icon: Copy,
      color: 'from-purple-500 to-pink-600',
      badge: 'Geo-Cluster Engine'
    },
    {
      id: 'route',
      name: 'AI Route Agent',
      desc: 'Dynamic department dispatching without manual human triaging.',
      icon: Cpu,
      color: 'from-emerald-500 to-teal-600',
      badge: 'Workflow Broker'
    },
    {
      id: 'verification',
      name: 'AI Verification Agent',
      desc: 'Validates photos, audio spectra, GPS, and time authenticity stamps.',
      icon: ShieldAlert,
      color: 'from-rose-500 to-red-600',
      badge: 'Antifraud Vault'
    }
  ];

  const triggerAnalysis = () => {
    setIsProcessing(true);
    setAnalysisResult(null);

    setTimeout(() => {
      setIsProcessing(false);
      setAnalysisResult({
        category: 'Roads',
        location: 'Gajuwaka Junction, Visakhapatnam North',
        severity: 'HIGH',
        authenticity: '96% (Verified via GPS & Active Accident Reports)',
        department: 'Ministry of Road Transport & Highways / PWD',
        summary: 'Dangerous pothole in active high-speed corridor causing immediate traffic hazard and accidents.',
        priorityScore: 92,
        metrics: {
          verification: 9.2,
          urgency: 9.0,
          impact: 9.5,
          feasibility: 8.5
        }
      });
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans">
      <div className="text-center max-w-3xl mx-auto mb-10">
        <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 font-semibold px-3 py-1 rounded-full text-xs uppercase tracking-wider inline-flex items-center gap-1.5 mb-3">
          <Sparkles size={12} className="text-indigo-600 animate-pulse" />
          Autonomous AI Operations Room
        </span>
        <h2 className="text-3xl font-bold text-gray-900 tracking-tight">Meet the JanVoice AI Agent Fleet</h2>
        <p className="text-gray-500 text-sm mt-2">
          An assembly of 8 specialized deep-learning agents collaborating in parallel to parse, verify, prioritize, and route public issues without manual bureaucracy.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Navigation panel */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-bold uppercase text-gray-400 tracking-wider mb-2 px-2">Select Active Agent</h3>
          {agents.map((agent) => {
            const Icon = agent.icon;
            const isActive = activeAgent === agent.id;
            return (
              <button
                key={agent.id}
                onClick={() => {
                  setActiveAgent(agent.id);
                  setAnalysisResult(null);
                }}
                className={`w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-start gap-4 ${
                  isActive 
                    ? 'bg-white border-indigo-200 shadow-md ring-1 ring-indigo-100/50' 
                    : 'bg-white border-gray-100 hover:border-gray-200 hover:shadow-xs'
                }`}
              >
                <div className={`p-2.5 rounded-lg bg-linear-to-br ${agent.color} text-white shrink-0 shadow-xs`}>
                  <Icon size={18} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-sm text-gray-800 truncate">{agent.name}</span>
                    <span className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded font-mono shrink-0 uppercase tracking-wider">{agent.badge}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed line-clamp-2">{agent.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Live Playground / Visualization Panel */}
        <div className="lg:col-span-8 bg-white border border-gray-100 rounded-2xl shadow-sm p-6 relative overflow-hidden">
          {/* Subtle grid pattern background */}
          <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none"></div>

          {activeAgent === 'analysis' && (
            <div className="relative space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Brain className="text-indigo-600" size={22} />
                  <div>
                    <h3 className="font-bold text-gray-900 text-base">AI Complaint Analysis Agent Playground</h3>
                    <p className="text-[11px] text-gray-400">Deep NLP categorizer and context extractor</p>
                  </div>
                </div>
                <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Active Node
                </span>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Simulated Citizen Input</label>
                <div className="relative">
                  <textarea
                    value={demoInputText}
                    onChange={(e) => setDemoInputText(e.target.value)}
                    rows={3}
                    className="w-full text-sm border border-gray-200 rounded-xl p-3.5 pr-10 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition bg-gray-50/50"
                    placeholder="Enter a complaint text in English, Hindi, or Telugu..."
                  />
                  <button
                    onClick={triggerAnalysis}
                    disabled={isProcessing}
                    className="absolute bottom-3 right-3 bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-lg transition shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    {isProcessing ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
                  </button>
                </div>
                <p className="text-[10px] text-gray-400">Type or paste any issue. Our cognitive NLP pipeline will segment it on submission.</p>
              </div>

              {isProcessing && (
                <div className="p-8 border border-dashed border-gray-200 rounded-xl bg-gray-50 flex flex-col items-center justify-center text-center space-y-3">
                  <RefreshCw className="text-indigo-600 animate-spin" size={28} />
                  <div>
                    <p className="text-xs font-bold text-gray-700">Lexing input streams...</p>
                    <p className="text-[10px] text-gray-400">Syntactic analysis and department cross-reference running</p>
                  </div>
                </div>
              )}

              {analysisResult && !isProcessing && (
                <div className="space-y-4 animate-fade-in">
                  <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Analysis Extraction Results</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 border border-gray-100 p-3 rounded-xl">
                      <div className="text-[10px] font-bold text-gray-400 uppercase">Detected Category</div>
                      <div className="font-bold text-gray-800 text-sm mt-0.5">{analysisResult.category}</div>
                    </div>
                    <div className="bg-gray-50 border border-gray-100 p-3 rounded-xl">
                      <div className="text-[10px] font-bold text-gray-400 uppercase">Extracted Location</div>
                      <div className="font-bold text-gray-800 text-sm mt-0.5">{analysisResult.location}</div>
                    </div>
                    <div className="bg-gray-50 border border-gray-100 p-3 rounded-xl">
                      <div className="text-[10px] font-bold text-gray-400 uppercase">Emergency Severity</div>
                      <div className="font-bold text-rose-600 text-xs mt-0.5 inline-flex items-center gap-1 font-semibold">
                        <AlertTriangle size={12} /> {analysisResult.severity}
                      </div>
                    </div>
                    <div className="bg-gray-50 border border-gray-100 p-3 rounded-xl">
                      <div className="text-[10px] font-bold text-gray-400 uppercase">AI Verification Level</div>
                      <div className="font-bold text-emerald-600 text-sm mt-0.5">{analysisResult.authenticity}</div>
                    </div>
                  </div>

                  <div className="bg-indigo-50 border border-indigo-100/60 p-4 rounded-xl space-y-1">
                    <div className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1">
                      <Sparkles size={11} /> Suggested Routing Target
                    </div>
                    <div className="font-bold text-gray-800 text-sm">{analysisResult.department}</div>
                    <p className="text-xs text-gray-600 leading-relaxed mt-1">
                      <strong>Abstract:</strong> {analysisResult.summary}
                    </p>
                  </div>
                </div>
              )}

              {!analysisResult && !isProcessing && (
                <div className="p-8 border border-dashed border-gray-200 rounded-xl bg-gray-50/50 flex flex-col items-center justify-center text-center space-y-2">
                  <Brain className="text-gray-300" size={32} />
                  <div>
                    <p className="text-xs font-bold text-gray-600">Cognitive Analyzer Standby</p>
                    <p className="text-[11px] text-gray-400">Click the play button or type custom text to trigger structural analysis.</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeAgent === 'priority' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <TrendingUp className="text-amber-500" size={22} />
                  <div>
                    <h3 className="font-bold text-gray-900 text-base">Mathematical Priority Scoring (MP Engine)</h3>
                    <p className="text-[11px] text-gray-400">Priority Score = Verification × Urgency × Impact × Feasibility</p>
                  </div>
                </div>
              </div>

              <div className="bg-amber-50/70 border border-amber-100 rounded-xl p-4 text-xs leading-relaxed text-amber-900">
                This engine removes subjective favoritism or political bias from grievance queues. It assigns a raw mathematical priority between 0% and 100% to rank which public works projects must be executed first.
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Verification */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Verification Score</span>
                      <span className="text-amber-600 font-bold font-mono">94%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '94%' }}></div>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-tight">Reports backed by matched GPS, high-res photos, and multiple unique citizen supports.</p>
                  </div>

                  {/* Urgency */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Urgency Score</span>
                      <span className="text-amber-600 font-bold font-mono">90%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '90%' }}></div>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-tight">Time-sensitive threats, safety concerns, school zone proximity, and weather exposure indices.</p>
                  </div>

                  {/* Impact */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Impact Score</span>
                      <span className="text-amber-600 font-bold font-mono">95%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '95%' }}></div>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-tight">Density projection of citizens directly affected (e.g., 12,430 residents near water line leak).</p>
                  </div>

                  {/* Feasibility */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-gray-700">Feasibility Score</span>
                      <span className="text-amber-600 font-bold font-mono">82%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '82%' }}></div>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-tight">Budget alignment with MPLADS schemes, material logistics, contractor availability, and weather windows.</p>
                  </div>
                </div>

                <div className="bg-slate-900 text-white rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 mt-6">
                  <div>
                    <span className="text-[9px] bg-amber-500 text-slate-950 font-bold px-2 py-0.5 rounded uppercase font-sans">Combined Priority</span>
                    <h4 className="text-lg font-bold mt-1">Water Pipeline Burst (Madhurawada)</h4>
                    <p className="text-xs text-gray-400">94% Priority. Solves water crisis for 12,430 residents.</p>
                  </div>
                  <div className="text-center bg-slate-800 border border-slate-700 px-4 py-2.5 rounded-xl shrink-0">
                    <span className="text-2xl font-black text-amber-400">94%</span>
                    <p className="text-[9px] text-gray-400 uppercase font-mono tracking-wider mt-0.5">Final Priority</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeAgent === 'duplicate' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Copy className="text-purple-500" size={22} />
                  <div>
                    <h3 className="font-bold text-gray-900 text-base">AI Duplicate Detection & Merging</h3>
                    <p className="text-[11px] text-gray-400">Preventing dual dispatch and administrative burden</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-gray-500 leading-relaxed">
                  When a citizen uploads a complaint, our neural mapping model matches its GPS coordinate and NLP keyword markers against active unresolved complaints. If a matched issue is discovered within a 200m radius, the system prompts a merge instead of filing a new ticket.
                </p>

                <div className="border border-purple-100 bg-purple-50/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-purple-800">
                    <AlertTriangle size={14} className="text-purple-600 animate-bounce" />
                    Pending Incident Merging Suggestion
                  </div>

                  <div className="bg-white border border-purple-100 p-3 rounded-lg text-xs space-y-1">
                    <div className="font-bold text-gray-800">Primary Complaint: Pothole at Gajuwaka Junction</div>
                    <div className="text-[10px] text-purple-600 font-mono font-bold">Ticket ID: JV-2026-9041 (Active)</div>
                    <p className="text-gray-500 mt-1">
                      "Huge dangerous pothole at the center of the road, causing two-wheelers to fall during night hours."
                    </p>
                  </div>

                  <div className="text-center py-1 flex justify-center">
                    <ArrowRight size={16} className="text-purple-400 rotate-90" />
                  </div>

                  <div className="bg-white border border-purple-100 p-3 rounded-lg text-xs space-y-1 border-dashed">
                    <div className="font-bold text-purple-800 inline-flex items-center gap-1">
                      Incoming Report
                    </div>
                    <p className="text-gray-500">
                      "Pothole on Gajuwaka road, near the crossroads. Extremely deep and fill of mud water. Please fix."
                    </p>
                  </div>

                  <div className="bg-purple-950 text-white p-3.5 rounded-xl text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
                    <span className="font-semibold text-center sm:text-left">
                      "This issue already exists nearby. Do you want to support it instead?"
                    </span>
                    <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-4 py-1.5 rounded-lg text-[10px] transition shrink-0 cursor-pointer">
                      Upvote & Support Issue (+1)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeAgent === 'route' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Cpu className="text-emerald-500" size={22} />
                  <div>
                    <h3 className="font-bold text-gray-900 text-base">Autonomous AI Route & Dispatch Agent</h3>
                    <p className="text-[11px] text-gray-400">Instant dispatch bypassing municipal desks</p>
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-500 leading-relaxed">
                By understanding semantic descriptors (e.g., "live cables sparking" vs "muddy tap water"), the AI routes grievances to specialized state departments instantly, bypassing manual clerks.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-emerald-50/50 border border-emerald-100 p-3.5 rounded-xl text-center space-y-1.5 flex flex-col justify-between">
                  <div className="text-[10px] font-bold text-emerald-700 uppercase">Roads Department</div>
                  <div className="text-xs font-semibold text-gray-700">PWD, NHAI</div>
                  <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-bold uppercase tracking-wider inline-block">Auto-Target #1</span>
                </div>
                <div className="bg-blue-50/50 border border-blue-100 p-3.5 rounded-xl text-center space-y-1.5 flex flex-col justify-between">
                  <div className="text-[10px] font-bold text-blue-700 uppercase">Water Department</div>
                  <div className="text-xs font-semibold text-gray-700">Jal Shakti, VMC</div>
                  <span className="text-[9px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-bold uppercase tracking-wider inline-block">Auto-Target #2</span>
                </div>
                <div className="bg-amber-50/50 border border-amber-100 p-3.5 rounded-xl text-center space-y-1.5 flex flex-col justify-between">
                  <div className="text-[10px] font-bold text-amber-700 uppercase">Electricity</div>
                  <div className="text-xs font-semibold text-gray-700">State DisCom</div>
                  <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-mono font-bold uppercase tracking-wider inline-block">Auto-Target #3</span>
                </div>
              </div>

              <div className="border border-gray-100 rounded-xl p-4 flex items-center justify-between bg-gray-50/50">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-600 text-white rounded-full p-2">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Dispatch Speed Achieved</h4>
                    <p className="text-[11px] text-gray-400">Mean routing time reduced from 4.2 days to 0.8 seconds.</p>
                  </div>
                </div>
                <span className="font-mono text-xs text-emerald-600 font-bold">+400% Efficiency</span>
              </div>
            </div>
          )}

          {activeAgent === 'verification' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="text-rose-500" size={22} />
                  <div>
                    <h3 className="font-bold text-gray-900 text-base">AI Anti-Fraud Verification Pipeline</h3>
                    <p className="text-[11px] text-gray-400">Validating image pixels, GPS coordinates, and noise levels</p>
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-500 leading-relaxed">
                To prevent spam, prank complaints, or stock internet photo uploads, our verification agent scans every submitted file. It cross-references photo EXIF coordinates with user GPS pins and performs reverse image checks in real-time.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-gray-200 rounded-xl overflow-hidden bg-gray-50 p-3 space-y-2">
                  <div className="relative h-28 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img 
                      src="https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=300&q=80" 
                      className="w-full h-full object-cover opacity-75" 
                      alt="pothole verification"
                    />
                    <div className="absolute inset-0 bg-linear-to-t from-slate-900/60 to-transparent flex items-end p-2">
                      <span className="text-[9px] font-mono text-white font-bold">Metadata Checked</span>
                    </div>
                  </div>
                  <div className="text-[11px] space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-500">EXIF Lat/Lng:</span>
                      <span className="text-emerald-600 font-bold font-mono">17.6904 / 83.2084</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">GPS Distance:</span>
                      <span className="text-emerald-600 font-bold font-mono">14 meters (MATCH)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Exif Timestamp:</span>
                      <span className="text-gray-700 font-bold">2026-07-07 15:42 (MATCH)</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col justify-between space-y-3">
                  <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl">
                    <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">AI Verification Decision</div>
                    <div className="text-xl font-bold text-emerald-600 mt-1">98% Authentic</div>
                    <p className="text-[11px] text-emerald-700 mt-1 leading-relaxed">
                      All security checklists passed. Original photo captured locally with matched GPS coordinates and genuine metadata signature.
                    </p>
                  </div>

                  <div className="bg-rose-50 border border-rose-100 p-4 rounded-xl">
                    <div className="text-[10px] font-bold text-rose-800 uppercase tracking-wider">Prank/AI Image Detection</div>
                    <div className="text-xs font-semibold text-rose-700 mt-1">Stock/Duplicate Check Passed</div>
                    <p className="text-[11px] text-rose-600 mt-0.5 leading-relaxed">
                      Zero matching records found in Google Reverse Image index or local historic ticket logs.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
