/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  Languages, 
  Eye, 
  User, 
  ShieldCheck, 
  TrendingUp, 
  Sparkles,
  Download,
  CheckCircle2,
  Lock,
  Bell,
  Trash2
} from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onDownloadZip: () => void;
  isDownloading: boolean;
  textSize: 'normal' | 'large' | 'xlarge';
  setTextSize: (size: 'normal' | 'large' | 'xlarge') => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
  notifications?: any[];
  setNotifications?: (n: any[]) => void;
}

export default function Header({
  currentView,
  setCurrentView,
  userRole,
  setUserRole,
  onDownloadZip,
  isDownloading,
  textSize,
  setTextSize,
  highContrast,
  setHighContrast,
  notifications = [],
  setNotifications
}: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [lang, setLang] = useState('English');
  const [showNotifications, setShowNotifications] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'departments', label: 'Departments' },
    { id: 'raise', label: 'Raise Complaint' },
    { id: 'track', label: 'Track Complaint' },
    { id: 'map', label: 'Live Map' },
    { id: 'ai-assistant', label: 'AI Assistant' },
    { id: 'ai-agents', label: 'AI Agents' },
    { id: 'contact', label: 'Contact' },
  ];

  const languages = ['English', 'हिन्दी (Hindi)', 'தமிழ் (Tamil)', 'తెలుగు (Telugu)', 'मराठी (Marathi)', 'বাংলা (Bengali)'];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // If looks like a ticket number, route to track
      if (searchQuery.toUpperCase().startsWith('JV-') || !isNaN(Number(searchQuery))) {
        setCurrentView(`track:${searchQuery}`);
      } else {
        // Trigger a generic search or alert
        alert(`Searching for: "${searchQuery}" across JanVoice portal.`);
      }
    }
  };

  return (
    <header className="w-full flex flex-col font-sans border-b border-gray-200 bg-white shadow-xs">
      {/* Top Tri-color Bar */}
      <div className="h-1.5 w-full flex">
        <div className="bg-[#FF9933] flex-1"></div> {/* Saffron */}
        <div className="bg-white flex-1"></div>       {/* White */}
        <div className="bg-[#138808] flex-1"></div>   {/* Green */}
      </div>

      {/* Accessibility and Metadata Header */}
      <div className="bg-gray-50 border-b border-gray-200 py-1.5 px-4 md:px-8 text-xs flex justify-between items-center text-gray-600">
        <div className="flex items-center gap-4">
          <span className="font-medium flex items-center gap-1">
            <span className="inline-block w-2 h-2 rounded-full bg-[#138808]"></span>
            Government of India
          </span>
          <span className="hidden sm:inline text-gray-400">|</span>
          <span className="hidden sm:inline">Ministry of Electronics & Information Technology (MeitY)</span>
        </div>
        <div className="flex items-center gap-4">
          {/* Text Size Accessibility */}
          <div className="flex items-center gap-1 border-r border-gray-300 pr-4">
            <button 
              onClick={() => setTextSize('normal')} 
              className={`px-1.5 py-0.5 rounded font-bold hover:bg-gray-200 transition ${textSize === 'normal' ? 'bg-[#002F6C] text-white' : 'text-gray-700'}`}
              title="Normal Text Size"
            >
              A
            </button>
            <button 
              onClick={() => setTextSize('large')} 
              className={`px-1.5 py-0.5 rounded font-bold hover:bg-gray-200 transition ${textSize === 'large' ? 'bg-[#002F6C] text-white' : 'text-gray-700'}`}
              title="Large Text Size"
            >
              A+
            </button>
            <button 
              onClick={() => setTextSize('xlarge')} 
              className={`px-1.5 py-0.5 rounded font-bold hover:bg-gray-200 transition ${textSize === 'xlarge' ? 'bg-[#002F6C] text-white' : 'text-gray-700'}`}
              title="Extra Large Text Size"
            >
              A++
            </button>
          </div>

          {/* Contrast Selector */}
          <button
            onClick={() => setHighContrast(!highContrast)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded hover:bg-gray-200 transition ${highContrast ? 'bg-black text-yellow-400 font-bold border border-yellow-400' : 'text-gray-700'}`}
            title="Toggle Accessibility High Contrast"
          >
            <Eye size={12} />
            <span className="hidden md:inline">{highContrast ? 'Standard View' : 'High Contrast'}</span>
          </button>

          {/* Lang Selector */}
          <div className="flex items-center gap-1 text-gray-700">
            <Languages size={12} className="text-gray-400" />
            <select 
              value={lang} 
              onChange={(e) => setLang(e.target.value)}
              className="bg-transparent border-0 cursor-pointer focus:ring-0 py-0 text-xs font-medium"
            >
              {languages.map(l => (
                <option key={l} value={l} className="text-gray-800">{l}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Branding Header */}
      <div className="px-4 md:px-8 py-3 flex flex-col lg:flex-row justify-between items-center gap-4 bg-white">
        {/* Emblem & Logo */}
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => setCurrentView('home')}>
          {/* Simplified High-Quality SVG Emblem */}
          <svg width="45" height="60" viewBox="0 0 100 130" className="text-gray-800">
            {/* Saffron Circle Backing */}
            <circle cx="50" cy="35" r="24" fill="none" stroke="#FF9933" strokeWidth="2" strokeDasharray="3 3" />
            {/* Main pillar pillar */}
            <path d="M42,95 L58,95 L54,60 L46,60 Z" fill="#718096" />
            {/* Ashoka Wheel in Navy */}
            <circle cx="50" cy="98" r="8" fill="none" stroke="#000080" strokeWidth="2" />
            {/* spokes */}
            <line x1="50" y1="90" x2="50" y2="106" stroke="#000080" strokeWidth="1" />
            <line x1="42" y1="98" x2="58" y2="98" stroke="#000080" strokeWidth="1" />
            <line x1="44" y1="92" x2="56" y2="104" stroke="#000080" strokeWidth="1" />
            <line x1="44" y1="104" x2="56" y2="92" stroke="#000080" strokeWidth="1" />
            {/* Lion Head outlines */}
            <path d="M40,55 C40,40 60,40 60,55 C60,57 58,58 58,60 L42,60 C42,58 40,57 40,55 Z" fill="#4A5568" />
            {/* Crown and details */}
            <path d="M46,45 C48,43 52,43 54,45 L50,38 Z" fill="#E2E8F0" />
            <path d="M30,110 L70,110 L65,115 L35,115 Z" fill="#A0AEC0" />
            <text x="50" y="125" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#002F6C">सत्यमेव जयते</text>
          </svg>

          <div className="flex flex-col border-l-2 border-[#FF9933] pl-4">
            <div className="flex items-center gap-2">
              <span className="text-xl md:text-2xl font-bold tracking-tight text-[#002F6C] font-sans">
                JanVoice <span className="text-[#FF9933]">AI</span>
              </span>
              <span className="bg-[#138808]/10 text-[#138808] text-[10px] font-bold px-2 py-0.5 rounded-full border border-[#138808]/20 flex items-center gap-1">
                <Sparkles size={10} className="animate-pulse" />
                NextGen Gov
              </span>
            </div>
            <span className="text-[10px] md:text-xs text-gray-500 font-medium font-sans uppercase tracking-wider">
              AI-Powered Citizen Governance Portal
            </span>
          </div>
        </div>

        {/* Search, Download ZIP & Dashboard Roles */}
        <div className="flex flex-wrap items-center justify-center lg:justify-end gap-3 w-full lg:w-auto">
          {/* Quick Ticket Tracker search */}
          <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-60">
            <input 
              type="text"
              placeholder="Track Complaint ID (e.g., JV-2026-9041)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-50 border border-gray-300 rounded-lg py-1.5 pl-3 pr-9 text-xs focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition outline-none"
            />
            <button type="submit" className="absolute right-2.5 top-2 text-gray-400 hover:text-[#002F6C]" title="Track Complaint">
              <Search size={14} />
            </button>
          </form>

          {/* Download ZIP Package Floating Developer action */}
          <button
            onClick={onDownloadZip}
            disabled={isDownloading}
            className="flex items-center gap-1.5 bg-[#138808] hover:bg-[#0e6306] text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow-xs transition disabled:opacity-75 cursor-pointer animate-fade-in"
            title="Download full project ZIP including all code and layout as requested"
          >
            <Download size={14} className={isDownloading ? "animate-bounce" : ""} />
            {isDownloading ? 'Source...' : 'Source ZIP'}
          </button>

          {/* Real-time Notification System Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-1.5 bg-gray-100 hover:bg-gray-200 border border-gray-200 text-gray-700 rounded-lg flex items-center justify-center transition cursor-pointer"
              title="View Alerts & Notifications"
            >
              <Bell size={15} className="text-[#002F6C]" />
              {notifications.filter(n => !n.read).length > 0 && (
                <span className="absolute -top-1 -right-1 w-4.5 h-4.5 bg-rose-600 text-white font-black text-[9px] rounded-full flex items-center justify-center animate-bounce">
                  {notifications.filter(n => !n.read).length}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden animate-fade-in font-sans">
                <div className="p-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                  <span className="text-xs font-black text-[#002F6C] uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles size={12} className="text-[#FF9933]" />
                    Ministry Updates ({notifications.length})
                  </span>
                  {notifications.length > 0 && setNotifications && (
                    <button
                      onClick={() => setNotifications([])}
                      className="text-[10px] text-rose-600 font-bold hover:underline flex items-center gap-0.5"
                    >
                      <Trash2 size={10} />
                      Clear
                    </button>
                  )}
                </div>

                <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-gray-400 font-medium">
                      No active system alerts or notifications.
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div 
                        key={n.id} 
                        onClick={() => {
                          if (setNotifications) {
                            setNotifications(
                              notifications.map(x => x.id === n.id ? { ...x, read: true } : x)
                            );
                          }
                        }}
                        className={`p-3 text-left transition cursor-pointer hover:bg-slate-50 flex gap-2 items-start ${
                          !n.read ? 'bg-amber-50/40' : ''
                        }`}
                      >
                        <span className="text-sm shrink-0">
                          {n.type === 'alert' ? '⚠️' : n.type === 'success' ? '✅' : 'ℹ️'}
                        </span>
                        <div className="space-y-0.5 min-w-0 flex-1">
                          <p className={`text-xs text-gray-800 leading-snug ${!n.read ? 'font-bold' : 'font-normal'}`}>
                            {n.title}
                          </p>
                          <span className="text-[9px] text-gray-400 block font-semibold">
                            {n.time || 'Just now'}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-2 bg-slate-50 border-t border-slate-100 text-center">
                  <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">
                    Secured by National Informatics Core
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Role Switching Interface - Beautifully customized */}
          <div className="bg-gray-100 p-1 rounded-lg flex items-center border border-gray-200">
            <span className="text-[10px] text-gray-500 font-semibold uppercase px-2 hidden xl:inline">Role Simulator:</span>
            <button
              onClick={() => {
                setUserRole('Citizen');
                setCurrentView('citizen-dashboard');
              }}
              className={`flex items-center gap-1 px-3 py-1 rounded-md text-xs font-semibold transition ${userRole === 'Citizen' ? 'bg-white text-[#002F6C] shadow-xs border border-gray-200' : 'text-gray-600 hover:text-[#002F6C]'}`}
            >
              <User size={13} className="text-[#FF9933]" />
              Citizen
            </button>
            <button
              onClick={() => {
                setUserRole('Officer');
                setCurrentView('officer-dashboard');
              }}
              className={`flex items-center gap-1 px-3 py-1 rounded-md text-xs font-semibold transition ${userRole === 'Officer' ? 'bg-[#002F6C] text-white shadow-xs' : 'text-gray-600 hover:text-[#002F6C]'}`}
            >
              <ShieldCheck size={13} className="text-white sm:text-[#002F6C]" />
              Officer
            </button>
            <button
              onClick={() => {
                setUserRole('MP');
                setCurrentView('mp-dashboard');
              }}
              className={`flex items-center gap-1 px-3 py-1 rounded-md text-xs font-semibold transition ${userRole === 'MP' ? 'bg-[#FF9933] text-white shadow-xs' : 'text-gray-600 hover:text-[#002F6C]'}`}
            >
              <TrendingUp size={13} className="text-white sm:text-[#138808]" />
              MP Dashboard
            </button>
          </div>
        </div>
      </div>

      {/* Main Government Style Horizontal Navigation Bar */}
      <nav className="bg-[#002F6C] text-white px-4 md:px-8 flex flex-col md:flex-row justify-between items-stretch md:items-center">
        <ul className="flex flex-wrap overflow-x-auto gap-0.5 md:gap-1 scrollbar-thin">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => setCurrentView(item.id)}
                  className={`px-4 py-3 text-xs md:text-sm font-medium transition cursor-pointer relative block text-left h-full ${isActive ? 'bg-[#FF9933] text-white font-semibold' : 'hover:bg-white/10'}`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-1 bg-[#138808]"></span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Dashboard quick routes */}
        <div className="flex gap-2 p-2 md:p-0 border-t border-white/10 md:border-t-0 justify-end">
          <button
            onClick={() => setCurrentView('citizen-dashboard')}
            className={`px-2.5 py-1 rounded text-xs font-medium border transition ${currentView === 'citizen-dashboard' ? 'bg-white text-[#002F6C] border-white' : 'text-white/80 border-white/20 hover:bg-white/10'}`}
          >
            Citizen Area
          </button>
          <button
            onClick={() => setCurrentView('officer-dashboard')}
            className={`px-2.5 py-1 rounded text-xs font-medium border transition ${currentView === 'officer-dashboard' ? 'bg-white text-[#002F6C] border-white' : 'text-white/80 border-white/20 hover:bg-white/10'}`}
          >
            Officer Area
          </button>
          <button
            onClick={() => setCurrentView('mp-dashboard')}
            className={`px-2.5 py-1 rounded text-xs font-medium border transition ${currentView === 'mp-dashboard' ? 'bg-white text-[#002F6C] border-white' : 'text-white/80 border-white/20 hover:bg-white/10'}`}
          >
            MP Area
          </button>
        </div>
      </nav>
    </header>
  );
}
