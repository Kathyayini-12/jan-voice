/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, Heart, ExternalLink, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  setCurrentView: (view: string) => void;
}

export default function Footer({ setCurrentView }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#1A202C] text-gray-300 font-sans border-t-4 border-[#002F6C]">
      {/* Upper Saffron Divider Strip */}
      <div className="h-1 w-full bg-[#FF9933]"></div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        
        {/* Portal Branding and Mission */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-white tracking-tight">
              JanVoice <span className="text-[#FF9933]">AI</span>
            </span>
            <span className="bg-[#FF9933]/10 text-[#FF9933] text-[9px] font-bold px-2 py-0.5 rounded border border-[#FF9933]/20">
              MEITY INITIATIVE
            </span>
          </div>
          <p className="text-xs leading-relaxed text-gray-400">
            Designed as a high-performance citizen grievance system leveraging state-of-the-art server-side AI routing, automated location tracking, and visual intelligence pipelines for transparent public service delivery.
          </p>
          <div className="flex flex-wrap gap-2 pt-2">
            <span className="bg-white/5 border border-white/10 px-2 py-1 rounded text-[10px] text-gray-400 font-medium">#DigitalIndia</span>
            <span className="bg-white/5 border border-white/10 px-2 py-1 rounded text-[10px] text-gray-400 font-medium">#MyGov</span>
            <span className="bg-white/5 border border-white/10 px-2 py-1 rounded text-[10px] text-gray-400 font-medium">#CPGRAMS</span>
          </div>
        </div>

        {/* Navigation Links */}
        <div>
          <h4 className="text-white font-bold text-sm border-b border-gray-700 pb-2 mb-4 uppercase tracking-wider">
            Important Links
          </h4>
          <ul className="space-y-2.5 text-xs">
            <li>
              <button onClick={() => setCurrentView('home')} className="hover:text-white transition hover:underline text-left">
                Home Portal
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('about')} className="hover:text-white transition hover:underline text-left">
                About the Initiative
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('departments')} className="hover:text-white transition hover:underline text-left">
                Ministries & Departments
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('raise')} className="hover:text-white transition hover:underline text-left text-[#FF9933] font-medium">
                Raise Citizen Complaint
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('track')} className="hover:text-white transition hover:underline text-left">
                Track Complaint Status
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('ai-assistant')} className="hover:text-white transition hover:underline text-left text-[#138808] font-medium">
                Interact with JanVoice AI
              </button>
            </li>
          </ul>
        </div>

        {/* Contact and Helpdesk */}
        <div>
          <h4 className="text-white font-bold text-sm border-b border-gray-700 pb-2 mb-4 uppercase tracking-wider">
            National Helpdesk
          </h4>
          <ul className="space-y-3 text-xs text-gray-400">
            <li className="flex items-start gap-2">
              <MapPin size={14} className="text-[#FF9933] shrink-0 mt-0.5" />
              <span>National Informatics Centre (NIC), MeitY, CGO Complex, Lodhi Road, New Delhi - 110003</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone size={14} className="text-[#FF9933] shrink-0" />
              <span>Toll Free: 1800-11-5500 (Grievances)</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail size={14} className="text-[#FF9933] shrink-0" />
              <span>support-janvoice@nic.in</span>
            </li>
          </ul>
        </div>

        {/* Official Governance Emblem / Certifications */}
        <div className="space-y-4">
          <h4 className="text-white font-bold text-sm border-b border-gray-700 pb-2 mb-4 uppercase tracking-wider">
            Platform Quality
          </h4>
          <div className="bg-black/30 border border-white/5 p-3 rounded space-y-2">
            <div className="flex items-center gap-2 text-xs text-gray-300 font-semibold">
              <ShieldCheck size={16} className="text-[#138808]" />
              Secure Gov Cloud
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              Maintained strictly as a secure client-side simulator. Complete source bundle compiles cleanly into a standalone zip in VS Code.
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-gray-500 pt-1">
            <span className="flex items-center gap-1">
              Made with <Heart size={10} className="text-red-500 fill-current" /> in India
            </span>
          </div>
        </div>

      </div>

      {/* Partners Logos / Seals of Government of India */}
      <div className="bg-[#121620] border-t border-gray-800 py-6 text-center text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-500">
          <div className="flex flex-wrap justify-center items-center gap-6">
            <span className="hover:text-gray-400 cursor-pointer flex items-center gap-1">
              MyGov Portal <ExternalLink size={10} />
            </span>
            <span>•</span>
            <span className="hover:text-gray-400 cursor-pointer flex items-center gap-1">
              National Portal of India <ExternalLink size={10} />
            </span>
            <span>•</span>
            <span className="hover:text-gray-400 cursor-pointer flex items-center gap-1">
              CPGRAMS <ExternalLink size={10} />
            </span>
            <span>•</span>
            <span className="hover:text-gray-400 cursor-pointer flex items-center gap-1">
              PMO India <ExternalLink size={10} />
            </span>
          </div>

          <p className="text-[11px] text-gray-600">
            © {currentYear} JanVoice AI, NIC. Simulated Government Platform Prototype. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
