/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  MapPin, 
  Users, 
  Award, 
  Building, 
  AlertTriangle, 
  TrendingUp, 
  CheckCircle, 
  Clock, 
  DollarSign, 
  ShieldAlert, 
  FileCheck,
  ChevronRight,
  TrendingDown,
  BarChart as BarIcon,
  Download,
  Search,
  Check,
  Building2,
  XCircle
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line 
} from 'recharts';
import { Complaint, Department, Priority } from '../types';
import InteractiveMap from './InteractiveMap';

interface MPDashboardProps {
  complaints: Complaint[];
  departments: Department[];
  onUpdateComplaintStatus?: (id: string, newStatus: string, note: string) => void;
}

export default function MPDashboard({ 
  complaints, 
  departments,
  onUpdateComplaintStatus 
}: MPDashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [actioningComplaint, setActioningComplaint] = useState<Complaint | null>(null);
  const [newStatusNote, setNewStatusNote] = useState('');
  const [newStatusVal, setNewStatusVal] = useState('In Progress');

  // Filter complaints within Visakhapatnam North
  const vizagComplaints = useMemo(() => {
    return complaints.filter(c => c.location.includes('Visakhapatnam North') || c.location.includes('Kalyanpur'));
  }, [complaints]);

  // Find Today's Highest Priority Problem (highest priorityScore calculated)
  const highestPriorityProblem = useMemo(() => {
    // Exclude resolved complaints
    const unresolved = vizagComplaints.filter(c => c.status !== 'Resolved' && c.status !== 'Rejected');
    if (unresolved.length === 0) return vizagComplaints[0]; // fallback
    return [...unresolved].sort((a, b) => (b.priorityScore || 0) - (a.priorityScore || 0))[0];
  }, [vizagComplaints]);

  // AI Recommendation Agent - Top 5 Issues to Solve Today
  const topFiveIssues = useMemo(() => {
    const unresolved = vizagComplaints.filter(c => c.status !== 'Resolved' && c.status !== 'Rejected');
    return [...unresolved]
      .sort((a, b) => (b.priorityScore || 0) - (a.priorityScore || 0))
      .slice(0, 5);
  }, [vizagComplaints]);

  // Analytics Agent - Calculate real stats dynamically
  const stats = useMemo(() => {
    const total = vizagComplaints.length;
    const resolved = vizagComplaints.filter(c => c.status === 'Resolved').length;
    const pending = vizagComplaints.filter(c => c.status === 'Pending').length;
    const inProgress = vizagComplaints.filter(c => c.status === 'In Progress').length;
    const resolvedPercent = total > 0 ? Math.round((resolved / total) * 100) : 0;
    
    // Average Priority Score
    const avgPriority = Math.round(vizagComplaints.reduce((acc, curr) => acc + (curr.priorityScore || 0), 0) / total);

    return { total, resolved, pending, inProgress, resolvedPercent, avgPriority };
  }, [vizagComplaints]);

  // Chart Data: Category Distribution (Problem Distribution)
  const categoryChartData = useMemo(() => {
    const counts: Record<string, number> = {};
    vizagComplaints.forEach(c => {
      counts[c.category] = (counts[c.category] || 0) + 1;
    });
    return Object.keys(counts).map(cat => ({
      name: cat,
      value: counts[cat]
    }));
  }, [vizagComplaints]);

  // Chart Data: Department Workloads
  const departmentWorkloadData = useMemo(() => {
    return departments.map(d => {
      // Find dynamic counts from active complaints list
      const unresolved = complaints.filter(c => c.department === d.name && c.status !== 'Resolved' && c.status !== 'Rejected').length;
      const resolved = complaints.filter(c => c.department === d.name && c.status === 'Resolved').length;
      return {
        name: d.name.split(' / ')[1] || d.name.split(' Y')[0] || d.name,
        'Active Issues': unresolved,
        'Resolved Works': resolved
      };
    });
  }, [departments, complaints]);

  // Chart Data: Monthly Trends (Historical speed)
  const monthlyTrendsData = [
    { month: 'Jan 2026', resolved: 45, pending: 20, speedDays: 6.2 },
    { month: 'Feb 2026', resolved: 58, pending: 15, speedDays: 5.5 },
    { month: 'Mar 2026', resolved: 72, pending: 22, speedDays: 4.8 },
    { month: 'Apr 2026', resolved: 90, pending: 18, speedDays: 4.1 },
    { month: 'May 2026', resolved: 110, pending: 25, speedDays: 3.4 },
    { month: 'Jun 2026', resolved: 135, pending: 30, speedDays: 2.1 },
    { month: 'Jul 2026', resolved: 165, pending: 28, speedDays: 1.4 } // Huge speed improvement with AI
  ];

  // Pie chart cell colors
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];

  // Handle Action Status update submission
  const submitStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (actioningComplaint && onUpdateComplaintStatus) {
      onUpdateComplaintStatus(actioningComplaint.id, newStatusVal, newStatusNote);
      alert(`Grievance status updated for ${actioningComplaint.id}! Live tracking updated.`);
      setActioningComplaint(null);
      setNewStatusNote('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans space-y-8">
      
      {/* MP Greeting & Constituency Header */}
      <div className="bg-[#002F6C] text-white p-6 rounded-2xl shadow-lg relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        {/* Decorative Saffron & Green visual circles */}
        <div className="absolute right-0 top-0 w-32 h-32 bg-[#FF9933] rounded-full blur-3xl opacity-10"></div>
        <div className="absolute left-1/4 bottom-0 w-32 h-32 bg-[#138808] rounded-full blur-3xl opacity-10"></div>
        
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#FF9933] text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider font-mono">
              Honorable MP Area
            </span>
            <span className="text-[11px] text-gray-300">| Visakhapatnam North</span>
          </div>
          <h2 className="text-2xl font-black tracking-tight mt-1">Namaste, Srikant K. Srivastav</h2>
          <p className="text-xs text-gray-300 mt-1">
            Analyzing 65 dynamic indicators, community budgets, and AI Agent performance indices for your legislative ward.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 text-center shrink-0">
          <span className="text-[10px] uppercase text-gray-300 tracking-wider block">Constituency Index</span>
          <span className="text-xl font-bold text-[#FF9933] block mt-0.5">Visakhapatnam North</span>
        </div>
      </div>

      {/* Hero Card: Today's Highest Priority Problem */}
      {highestPriorityProblem && (
        <div className="bg-white border border-rose-100 rounded-2xl shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Header & Scores (Left 5 cols) */}
          <div className="lg:col-span-5 bg-linear-to-br from-rose-50/50 via-white to-white p-6 border-b lg:border-b-0 lg:border-r border-gray-100 space-y-4">
            <div>
              <span className="bg-rose-100 text-rose-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider inline-flex items-center gap-1">
                <AlertTriangle size={11} className="animate-pulse" />
                Today's Highest Priority Problem
              </span>
              <h3 className="text-lg font-bold text-gray-900 mt-3 leading-tight">{highestPriorityProblem.title}</h3>
              <p className="text-[11px] text-gray-400 mt-1 flex items-center gap-1 font-semibold">
                <MapPin size={11} /> {highestPriorityProblem.location}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-rose-50/30 p-3 rounded-xl text-center border border-rose-100/40">
                <span className="text-[10px] font-bold text-gray-400 uppercase">Affected Citizens</span>
                <span className="text-lg font-black text-rose-600 block mt-0.5">
                  {(highestPriorityProblem.affectedCount || 12430).toLocaleString()}
                </span>
              </div>
              <div className="bg-amber-50/30 p-3 rounded-xl text-center border border-amber-100/40">
                <span className="text-[10px] font-bold text-gray-400 uppercase">Current Status</span>
                <span className="text-xs font-bold text-amber-600 block mt-1.5 uppercase bg-white border border-amber-200/50 px-2 py-0.5 rounded">
                  {highestPriorityProblem.status}
                </span>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2 relative overflow-hidden">
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-15">
                <Sparkles size={100} className="text-amber-400" />
              </div>
              <span className="text-[9px] bg-[#FF9933] text-slate-900 font-extrabold px-2 py-0.5 rounded font-mono uppercase tracking-wider">
                AI Agent Suggested Action
              </span>
              <p className="text-xs text-gray-200 leading-relaxed mt-1">
                "{highestPriorityProblem.suggestedAction || 'Immediate repair recommended. Delay may affect hospitals and schools.'}"
              </p>
              <div className="flex justify-between items-center text-[11px] text-gray-400 border-t border-slate-800 pt-2 mt-2">
                <span>Estimated Resolution Time:</span>
                <span className="font-bold text-amber-400">{highestPriorityProblem.estimatedResolutionTime || '6 Hours'}</span>
              </div>
            </div>
          </div>

          {/* Verification Formula & Insights (Right 7 cols) */}
          <div className="lg:col-span-7 p-6 space-y-5">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="font-bold text-gray-800 text-sm">Dynamic Priority Formula Calculation</h4>
                <p className="text-[11px] text-gray-400">P-Score = Verification × Urgency × Impact × Feasibility</p>
              </div>
              <div className="text-center bg-rose-50 border border-rose-100 px-4 py-2 rounded-xl shrink-0">
                <span className="text-3xl font-black text-rose-600">{highestPriorityProblem.priorityScore || 94}%</span>
                <p className="text-[9px] text-rose-500 uppercase font-mono tracking-widest mt-0.5">Priority Index</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Verification Score */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-gray-700">Verification Score</span>
                  <span className="font-mono text-gray-500 font-semibold">{highestPriorityProblem.verificationScore || 9}/10</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: `${(highestPriorityProblem.verificationScore || 9) * 10}%` }}></div>
                </div>
                <p className="text-[10px] text-gray-400 leading-tight">Verified via photos, coordinates, and local ward sentinel reports.</p>
              </div>

              {/* Urgency Score */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-gray-700">Urgency Score</span>
                  <span className="font-mono text-gray-500 font-semibold">{highestPriorityProblem.urgencyScore || 9}/10</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: `${(highestPriorityProblem.urgencyScore || 9) * 10}%` }}></div>
                </div>
                <p className="text-[10px] text-gray-400 leading-tight">Safety hazards, leakage speed, and weather triggers.</p>
              </div>

              {/* Impact Score */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-gray-700">Impact Score</span>
                  <span className="font-mono text-gray-500 font-semibold">{highestPriorityProblem.impactScore || 10}/10</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: `${(highestPriorityProblem.impactScore || 10) * 10}%` }}></div>
                </div>
                <p className="text-[10px] text-gray-400 leading-tight">Number of affected citizens and density indexes.</p>
              </div>

              {/* Feasibility Score */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-gray-700">Feasibility Score</span>
                  <span className="font-mono text-gray-500 font-semibold">{highestPriorityProblem.feasibilityScore || 8}/10</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: `${(highestPriorityProblem.feasibilityScore || 8) * 10}%` }}></div>
                </div>
                <p className="text-[10px] text-gray-400 leading-tight">Budget alignment and estimated repair difficulty.</p>
              </div>
            </div>

            {highestPriorityProblem.aiExplanation && (
              <div className="bg-amber-50/60 border border-amber-200/50 p-3 rounded-xl">
                <span className="text-[10px] text-amber-800 font-extrabold flex items-center gap-1">
                  <Sparkles size={11} className="text-amber-600 animate-pulse" /> AI JUSTIFICATION ANALYSIS
                </span>
                <p className="text-[11px] text-amber-950 leading-relaxed mt-1 font-medium">
                  {highestPriorityProblem.aiExplanation}
                </p>
              </div>
            )}

            <div className="flex gap-3 justify-end pt-2 border-t border-gray-100">
              <button
                onClick={() => {
                  setNewStatusVal('In Progress');
                  setActioningComplaint(highestPriorityProblem);
                }}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer"
              >
                Deploy Quick-Response Contractor
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Geospatial Complaints Monitor Map */}
      <div className="bg-white border border-gray-100 rounded-2xl shadow-xs p-6 space-y-4">
        <div>
          <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
            <span className="p-1 bg-[#002F6C] text-white rounded-md"><MapPin size={14} /></span>
            Andhra Pradesh Geo-Spatial Monitoring Grid
          </h3>
          <p className="text-[11px] text-gray-400 mt-1">
            Real-time geospatial visualization of citizens' issues across Visakhapatnam North constituency. Filters: Red (High/Critical), Orange (Medium), Green (Low), Blue (Resolved).
          </p>
        </div>
        <div className="border border-gray-100 rounded-xl overflow-hidden bg-gray-50">
          <InteractiveMap 
            complaints={vizagComplaints} 
            setSelectedComplaint={(c) => {
              setActioningComplaint(c);
            }} 
            setCurrentView={() => {}} 
          />
        </div>
      </div>

      {/* Core AI Recommendation Agent - Top 5 Issues, Budget, Expected Satisfaction */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-bold uppercase text-gray-400 tracking-wider">
            AI Recommendation Agent Insights
          </h3>
          <span className="text-xs text-[#138808] font-bold flex items-center gap-1">
            <Sparkles size={12} className="animate-pulse" /> Recommendations Active
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Top 5 list (Left 7 cols) */}
          <div className="lg:col-span-7 bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
            <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2 pb-2 border-b border-gray-100">
              <Award size={16} className="text-[#002F6C]" />
              Top 5 Actionable Complaints Today
            </h4>

            <div className="divide-y divide-gray-50 space-y-3">
              {topFiveIssues.map((issue, index) => (
                <div key={issue.id} className="flex items-center justify-between gap-4 pt-3 first:pt-0">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-linear-to-r from-[#002F6C] to-indigo-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shrink-0">
                        {index + 1}
                      </span>
                      <span className="font-bold text-gray-800 text-xs truncate">{issue.title}</span>
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-2">
                      <span>{issue.category}</span>
                      <span>•</span>
                      <span>{(issue.affectedCount || 500).toLocaleString()} citizens affected</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-bold text-slate-800 font-mono bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                      {issue.priorityScore}% Score
                    </span>
                    <button
                      onClick={() => setActioningComplaint(issue)}
                      className="text-[#002F6C] hover:text-white hover:bg-[#002F6C] p-1.5 rounded-lg border border-gray-100 transition text-xs font-bold cursor-pointer"
                      title="Update status"
                    >
                      Action
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Projected Impacts (Right 5 cols) */}
          <div className="lg:col-span-5 bg-linear-to-br from-slate-900 via-slate-900 to-indigo-950 text-white p-6 rounded-2xl shadow-md space-y-5">
            <h4 className="font-bold text-sm text-amber-400 flex items-center gap-2">
              <TrendingUp size={16} /> Projected Legislative Impact
            </h4>

            <div className="space-y-4">
              {/* Budget Recommendation */}
              <div className="space-y-1">
                <span className="text-[10px] uppercase text-gray-400 font-bold block">AI Budget Recommendation</span>
                <div className="flex items-center gap-1">
                  <DollarSign size={16} className="text-emerald-400" />
                  <span className="text-lg font-black text-white">₹1.42 Crore</span>
                  <span className="text-[10px] text-gray-400 ml-1">(Allocated from MPLADS reserve)</span>
                </div>
                <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>

              {/* Expected Citizen Satisfaction */}
              <div className="space-y-1">
                <span className="text-[10px] uppercase text-gray-400 font-bold block">Expected Citizen Satisfaction</span>
                <div className="flex items-center gap-1">
                  <span className="text-lg font-black text-white">96.8%</span>
                  <span className="text-emerald-400 text-[10px] font-bold flex items-center gap-0.5 ml-1">
                    +12.4% over last term
                  </span>
                </div>
                <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-400 rounded-full" style={{ width: '96%' }}></div>
                </div>
              </div>

              {/* Predicted Ward Health Impact */}
              <div className="space-y-1">
                <span className="text-[10px] uppercase text-gray-400 font-bold block">Predicted Ward Health Impact</span>
                <p className="text-xs text-gray-300 leading-relaxed">
                  Executing repair on Madhurawada pipeline prevents water contamination, removing dysentery risk for 14 village clusters.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Analytics Agent Graphs Panel */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold uppercase text-gray-400 tracking-wider">
          AI Analytics Agent Visualization
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Chart 1: Problem Distribution (Pie) */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
            <h4 className="font-bold text-gray-900 text-sm">Problem Category Distribution</h4>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} complaints`, 'Count']} />
                  <Legend verticalAlign="bottom" height={36} iconSize={10} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Resolution Speed trends (Line) */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
            <h4 className="font-bold text-gray-900 text-sm">Average Resolution Speed Trends (Days)</h4>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyTrendsData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                  <YAxis label={{ value: 'Mean Time (Days)', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="speedDays" 
                    stroke="#FF9933" 
                    strokeWidth={3} 
                    name="Mean Resolution (Days)"
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[10px] text-gray-400 text-center">AI integration on June 2026 reduced mean resolution time from 6.2 days to 1.4 days.</p>
          </div>
        </div>

        {/* Chart 3: Department Workloads */}
        <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
          <h4 className="font-bold text-gray-900 text-sm">Active workloads by Ministry / Department</h4>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentWorkloadData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} stroke="#4A5568" />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend iconSize={12} />
                <Bar dataKey="Active Issues" fill="#002F6C" stackId="a" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Resolved Works" fill="#138808" stackId="a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Action Update Modal Popup */}
      {actioningComplaint && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-2xl max-w-md w-full overflow-hidden animate-scale-up">
            <div className="bg-[#002F6C] text-white p-4 flex justify-between items-center">
              <h3 className="font-bold text-sm">Deploy Resources: {actioningComplaint.id}</h3>
              <button 
                onClick={() => setActioningComplaint(null)}
                className="text-white/80 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={submitStatusUpdate} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Grievance Title</label>
                <div className="text-xs font-bold text-gray-800 bg-gray-50 p-2.5 rounded-lg border border-gray-200">
                  {actioningComplaint.title}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Dispatch Target Status</label>
                <select
                  value={newStatusVal}
                  onChange={(e) => setNewStatusVal(e.target.value)}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 outline-none focus:ring-1 focus:ring-[#002F6C]"
                >
                  <option value="In Progress">Deploy Contractor (In Progress)</option>
                  <option value="Resolved">Verify Resolution (Resolved)</option>
                  <option value="Rejected">Flag as Duplicate / spam (Rejected)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Operational note</label>
                <textarea
                  value={newStatusNote}
                  onChange={(e) => setNewStatusNote(e.target.value)}
                  placeholder="e.g., Ward contractor S. Apparao dispatched to weld pipeline sleeve..."
                  rows={3}
                  required
                  className="w-full text-xs border border-gray-200 rounded-lg p-2.5 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C]"
                />
              </div>

              <div className="flex gap-2 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setActioningComplaint(null)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#002F6C] hover:bg-[#001f49] text-white font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer"
                >
                  Confirm Dispatch Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
