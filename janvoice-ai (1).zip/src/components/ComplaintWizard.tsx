/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  MapPin, 
  Upload, 
  Brain, 
  ShieldAlert, 
  Cpu, 
  FileCheck, 
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Clock,
  ThumbsUp,
  Download,
  Share2,
  Trash2,
  FileText
} from 'lucide-react';
import { Complaint, Priority } from '../types';

interface ComplaintWizardProps {
  onAddComplaint: (complaint: Complaint) => void;
  setCurrentView: (view: string) => void;
  setSelectedComplaint: (c: Complaint) => void;
}

export default function ComplaintWizard({ 
  onAddComplaint, 
  setCurrentView,
  setSelectedComplaint 
}: ComplaintWizardProps) {
  const [step, setStep] = useState<number>(1);
  const [title, setTitle] = useState<string>('');
  const [category, setCategory] = useState<string>('Roads');
  const [description, setDescription] = useState<string>('');
  const [location, setLocation] = useState<string>('MVP Colony, Visakhapatnam North');
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  
  // Simulation switches
  const [gpsMatched, setGpsMatched] = useState<boolean>(true);
  const [imageDuplicateDetected, setImageDuplicateDetected] = useState<boolean>(false);
  const [isProcessingStep2, setIsProcessingStep2] = useState<boolean>(false);

  // Auto generated stats for validation
  const generatedId = `JV-2026-${Math.floor(1000 + Math.random() * 9000)}`;

  // Photo presets for easy simulated uploads
  const mockPhotos = [
    { name: 'Damaged Asphalt', url: 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=300&q=80' },
    { name: 'Blocked Drain Sewer', url: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=300&q=80' },
    { name: 'Broken Electrical Pole', url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=300&q=80' }
  ];

  // Start AI pipeline processing
  const runAIEnginePipeline = () => {
    setIsProcessingStep2(true);
    setTimeout(() => {
      setIsProcessingStep2(false);
      setStep(2);
    }, 1500);
  };

  const handleCreateTicket = () => {
    const priorityScoreCalc = Math.round(
      (gpsMatched ? 9.5 : 5.0) * 
      (category === 'Electricity' ? 9.2 : 8.0) * 
      9.0 * 
      8.5 / 10
    );

    const newTicket: Complaint = {
      id: generatedId,
      title: title || `Damaged Infrastructure near ${location.split(',')[0]}`,
      category: category,
      description: description || `Localized issues pertaining to ${category}. Needs repair.`,
      location: location,
      status: 'Pending',
      reporter: 'Varada Venugopal',
      phone: '8765432109',
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      priority: category === 'Electricity' ? 'Critical' : 'High',
      verificationConfidence: gpsMatched ? 96 : 45,
      priorityScore: priorityScoreCalc,
      affectedCount: Math.floor(250 + Math.random() * 800),
      suggestedAction: `Deploy structural repair crew to ${location.split(',')[0]} and secure target perimeter.`,
      estimatedResolutionTime: category === 'Electricity' ? '4 Hours' : '24 Hours',
      urgencyScore: category === 'Electricity' ? 9.2 : 8.0,
      impactScore: 9.0,
      verificationScore: gpsMatched ? 9.5 : 5.0,
      feasibilityScore: 8.5,
      department: category === 'Roads' 
        ? 'Ministry of Road Transport & Highways / PWD'
        : category === 'Water'
        ? 'Ministry of Jal Shakti / Water Board'
        : category === 'Electricity'
        ? 'Ministry of Power / DisCom'
        : 'Municipal Corporation Division',
      lat: 17.6904 + (Math.random() - 0.5) * 0.05,
      lng: 83.2084 + (Math.random() - 0.5) * 0.05,
      updates: [
        {
          date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
          status: 'Submitted',
          note: 'Grievance lodged successfully via interactive citizen wizard.',
          officer: 'JanVoice AI Core'
        }
      ]
    };

    onAddComplaint(newTicket);
    setStep(4);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 font-sans">
      
      {/* Dynamic Header Progress timeline bar */}
      <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-xs mb-8 flex justify-between items-center text-xs">
        <div className="flex items-center gap-1.5">
          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold font-mono ${step >= 1 ? 'bg-[#002F6C] text-white' : 'bg-gray-100 text-gray-500'}`}>1</span>
          <span className={`font-semibold ${step === 1 ? 'text-[#002F6C]' : 'text-gray-400'}`}>Submit details</span>
        </div>
        <div className="w-10 h-0.5 bg-gray-100 flex-1 mx-3"></div>
        <div className="flex items-center gap-1.5">
          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold font-mono ${step >= 2 ? 'bg-[#002F6C] text-white' : 'bg-gray-100 text-gray-500'}`}>2</span>
          <span className={`font-semibold ${step === 2 ? 'text-[#002F6C]' : 'text-gray-400'}`}>AI Analysis</span>
        </div>
        <div className="w-10 h-0.5 bg-gray-100 flex-1 mx-3"></div>
        <div className="flex items-center gap-1.5">
          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold font-mono ${step >= 3 ? 'bg-[#002F6C] text-white' : 'bg-gray-100 text-gray-500'}`}>3</span>
          <span className={`font-semibold ${step === 3 ? 'text-[#002F6C]' : 'text-gray-400'}`}>Route & Dispatch</span>
        </div>
        <div className="w-10 h-0.5 bg-gray-100 flex-1 mx-3"></div>
        <div className="flex items-center gap-1.5">
          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold font-mono ${step >= 4 ? 'bg-[#002F6C] text-white' : 'bg-gray-100 text-gray-500'}`}>4</span>
          <span className={`font-semibold ${step === 4 ? 'text-[#002F6C]' : 'text-gray-400'}`}>Receipt</span>
        </div>
      </div>

      {/* STEP 1: Details Submit form */}
      {step === 1 && (
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 text-base">➕ Submit a New Grievance Report</h3>
            <p className="text-gray-400 text-xs mt-1">Provide short details. Our parallel AI Agent fleet will analyze, score and dispatch this instantly.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Title & category */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Short Issue Heading</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Road pothole hazard / sewage line leakage"
                  className="w-full text-xs border border-gray-200 rounded-xl p-3 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Select Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full text-xs border border-gray-200 rounded-xl p-3 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition bg-white"
                >
                  <option value="Roads">Roads & National Highways (PWD)</option>
                  <option value="Water">Water Infrastructure (Jal Shakti / Jal Board)</option>
                  <option value="Electricity">Electricity DisCom (Falling wire / sparks)</option>
                  <option value="Garbage">Garbage / Solid Waste Cleanup</option>
                  <option value="Safety">Safety & Civil Hazards</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Ward Location Landmark</label>
                <select
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full text-xs border border-gray-200 rounded-xl p-3 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition bg-white"
                >
                  <option value="MVP Colony, Visakhapatnam North">MVP Colony, Visakhapatnam North</option>
                  <option value="Gajuwaka Junction, Visakhapatnam North">Gajuwaka Junction, Visakhapatnam North</option>
                  <option value="Muralinagar Sector 3, Visakhapatnam North">Muralinagar Sector 3, Visakhapatnam North</option>
                  <option value="Madhurawada Village, Visakhapatnam North">Madhurawada Village, Visakhapatnam North</option>
                  <option value="Kalyanpur, Visakhapatnam North">Kalyanpur, Visakhapatnam North</option>
                </select>
              </div>
            </div>

            {/* Simulated Photo Upload block */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Simulate File Upload</label>
                <div className="border border-dashed border-gray-200 rounded-2xl p-4 text-center bg-gray-50/50 flex flex-col items-center justify-center space-y-2 h-44">
                  {selectedPhoto ? (
                    <div className="relative h-full w-full rounded-xl overflow-hidden">
                      <img src={selectedPhoto} className="w-full h-full object-cover" alt="Uploaded asset preview" />
                      <button 
                        onClick={() => setSelectedPhoto('')}
                        className="absolute top-2 right-2 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-lg text-xs"
                      >
                        ✕ Remove
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload size={24} className="text-gray-300" />
                      <div className="text-[10px] text-gray-400">Click a sample photo below to simulate local smartphone upload.</div>
                    </>
                  )}
                </div>
              </div>

              {/* Sample presets */}
              <div className="flex gap-2">
                {mockPhotos.map((p) => (
                  <button
                    key={p.name}
                    type="button"
                    onClick={() => {
                      setSelectedPhoto(p.url);
                      if (p.name === 'Damaged Asphalt') {
                        setTitle('Deep dangerous road pothole');
                        setCategory('Roads');
                        setDescription('A hazardous deep pothole in the high speed lane, causing riders to skid.');
                      } else if (p.name === 'Blocked Drain Sewer') {
                        setTitle('Blocked sewer line overflowing');
                        setCategory('Water');
                        setDescription('Sewer manhole overflows and foul smelling black water is blocking pedestrians.');
                      } else {
                        setTitle('Broken sparking transformer pole');
                        setCategory('Electricity');
                        setDescription('A roadside transformer pole has sparks and loose high voltage line hanging.');
                      }
                    }}
                    className="flex-1 bg-white border border-gray-200 p-1.5 rounded-lg text-[9px] font-semibold hover:border-[#002F6C] hover:text-[#002F6C] transition cursor-pointer"
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 uppercase">Hazard Description Details</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what is broken, nearest house door number, and details of safety hazard..."
              rows={3}
              className="w-full text-xs border border-gray-200 rounded-xl p-3 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition"
              required
            />
          </div>

          {/* AI Simulation Settings */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-700">Simulate GPS EXIF Match</span>
                <p className="text-[10px] text-gray-400">Coordinates in photo match user location pin.</p>
              </div>
              <input
                type="checkbox"
                checked={gpsMatched}
                onChange={(e) => setGpsMatched(e.target.checked)}
                className="w-4 h-4 text-[#002F6C] focus:ring-[#002F6C] border-gray-300 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-700">Simulate Duplicate Detection</span>
                <p className="text-[10px] text-gray-400">Prompt a warning if a similar issue exists nearby.</p>
              </div>
              <input
                type="checkbox"
                checked={imageDuplicateDetected}
                onChange={(e) => setImageDuplicateDetected(e.target.checked)}
                className="w-4 h-4 text-[#002F6C] focus:ring-[#002F6C] border-gray-300 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Nav buttons */}
          <div className="flex justify-end pt-2">
            <button
              onClick={runAIEnginePipeline}
              disabled={isProcessingStep2}
              className="bg-[#002F6C] hover:bg-[#001d44] disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition shadow-md flex items-center gap-1 cursor-pointer"
            >
              {isProcessingStep2 ? 'Scanning lexical inputs...' : 'Trigger JanVoice AI Pipeline'}
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: AI Analysis & Verification */}
      {step === 2 && (
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
            <div>
              <h3 className="font-bold text-gray-900 text-base">🧠 JanVoice Neural Scan Pipeline</h3>
              <p className="text-gray-400 text-xs">AI Complaint Analysis Agent & Verification Agent running validation</p>
            </div>
            <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded uppercase">Confidence: 96%</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left box: Analysis Results */}
            <div className="space-y-4">
              <div className="bg-indigo-50 border border-indigo-100/60 p-4 rounded-xl space-y-3">
                <div className="text-[10px] font-mono font-bold text-indigo-800 flex items-center gap-1">
                  <Brain size={12} className="animate-pulse" />
                  COGNITIVE CLASSIFICATION AGENT REPORT
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Segment Category:</span>
                    <strong className="text-gray-800">{category}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Resolved Area:</span>
                    <strong className="text-gray-800">{location.split(',')[0]}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Language Signature:</span>
                    <strong className="text-gray-800">English PWD-Lex</strong>
                  </div>
                </div>
              </div>

              {/* Photo check results */}
              <div className="border border-gray-100 p-4 rounded-xl space-y-2">
                <h4 className="text-xs font-bold text-gray-700">Verification Integrity Logs</h4>
                <div className="text-[11px] space-y-1.5 text-gray-600">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${gpsMatched ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                    <span>EXIF GPS Location Verification: <strong>{gpsMatched ? 'Passed (14m matched)' : 'Failed (4.1km mismatch)'}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>Reverse Image Search: <strong>No duplication found</strong></span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right box: Duplicate Detection popup warning if simulated */}
            <div className="space-y-4">
              {imageDuplicateDetected ? (
                <div className="border border-purple-200 bg-purple-50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-1.5 text-purple-800 font-bold text-xs">
                    <AlertTriangle size={14} className="text-purple-600 animate-bounce" />
                    Geo-Spatial Duplicate Detected Nearby!
                  </div>
                  <p className="text-[11px] text-purple-700 leading-relaxed">
                    A neighbor citizen (*Varada*) has already filed ticket **JV-2026-9041** for a similar road pothole within 80 meters.
                  </p>
                  <div className="bg-white border border-purple-100 p-3 rounded-lg text-[10px]">
                    <div className="font-bold text-gray-800">Pothole near Gajuwaka crossroads</div>
                    <div className="text-purple-600 mt-1">Status: In Progress | Priority: 94%</div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        alert("Thank you! You upvoted the existing ticket instead. Auto-merging complete.");
                        setCurrentView('citizen');
                      }}
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold p-2 rounded-lg text-[10px] transition cursor-pointer"
                    >
                      Upvote Existing Ticket (+1)
                    </button>
                    <button
                      onClick={() => setImageDuplicateDetected(false)}
                      className="bg-transparent hover:bg-purple-100 text-purple-800 border border-purple-200 font-bold p-2 rounded-lg text-[10px] transition cursor-pointer"
                    >
                      File Separately
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-xs">
                    <CheckCircle size={14} className="text-emerald-600" />
                    Uniqueness Scan Completed
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    No matching active complaints found inside this geographical grid. This is a unique localized hazard, requiring direct resource dispatch.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between border-t border-gray-100 pt-4">
            <button
              onClick={() => setStep(1)}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
            >
              <ArrowLeft size={13} /> Back
            </button>
            <button
              onClick={() => setStep(3)}
              className="bg-[#002F6C] hover:bg-[#001d44] text-white font-bold px-6 py-2 rounded-xl text-xs transition shadow-md flex items-center gap-1 cursor-pointer"
            >
              Calculate Priority & Route <ArrowRight size={13} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Automated Routing & Dispatch */}
      {step === 3 && (
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 text-base">🤖 Auto Routing & Dispatch Panel</h3>
            <p className="text-gray-400 text-xs">AI Routing Agent sending complaint to legislative departments instantly</p>
          </div>

          <div className="bg-[#002F6C] text-white p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded font-mono uppercase tracking-wider">
                AUTO-ROUTED TARGET
              </span>
              <h4 className="text-md font-bold mt-1.5">
                {category === 'Roads' 
                  ? 'Ministry of Road Transport & Highways / PWD' 
                  : category === 'Water'
                  ? 'Ministry of Jal Shakti / Jal Board'
                  : 'Municipal Corporation Ward Division'}
              </h4>
              <p className="text-xs text-gray-300 mt-1">Bypassed manual municipal triaging speed. Dispatched instantly.</p>
            </div>
            <div className="text-center bg-white/10 px-4 py-2.5 rounded-xl shrink-0 border border-white/10">
              <span className="text-2xl font-black text-amber-400">
                {category === 'Electricity' ? 98 : 88}%
              </span>
              <p className="text-[9px] text-gray-300 uppercase tracking-widest mt-0.5">Priority Index</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="border border-gray-100 p-4 rounded-xl space-y-1">
              <span className="text-gray-400 uppercase font-mono text-[9px] font-bold block">Estimated Resolution Time</span>
              <strong className="text-gray-800 text-base block">{category === 'Electricity' ? '4 Hours' : '24 Hours'}</strong>
              <p className="text-[10px] text-gray-400 mt-0.5">Based on historical contractor deployment schedules.</p>
            </div>

            <div className="border border-gray-100 p-4 rounded-xl space-y-1">
              <span className="text-gray-400 uppercase font-mono text-[9px] font-bold block">MPLADS Schemes Match</span>
              <strong className="text-gray-800 text-base block">₹1.42 Crore Pool aligned</strong>
              <p className="text-[10px] text-gray-400 mt-0.5">Fund is fully active for Visakhapatnam North municipal budget.</p>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between border-t border-gray-100 pt-4">
            <button
              onClick={() => setStep(2)}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
            >
              <ArrowLeft size={13} /> Back
            </button>
            <button
              onClick={handleCreateTicket}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition shadow-md flex items-center gap-1 cursor-pointer"
            >
              Create Ticket & Print Receipt <FileCheck size={14} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Success confirmation Receipt */}
      {step === 4 && (
        <div className="bg-white border border-gray-150 rounded-2xl p-6 shadow-sm space-y-6 text-center animate-scale-up">
          <div className="w-12 h-12 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center text-lg mx-auto">
            ✓
          </div>

          <div>
            <span className="text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded uppercase font-bold tracking-wider">
              Grievance Registered Successfully
            </span>
            <h3 className="text-xl font-bold text-gray-900 mt-3">Your Ticket ID is {generatedId}</h3>
            <p className="text-gray-400 text-xs mt-1 max-w-md mx-auto">
              Your issue has been verified and dispatched to target departments. A confirmation SMS receipt has been pushed to your registered smartphone.
            </p>
          </div>

          <div className="bg-gray-50 border border-gray-150 rounded-2xl p-4 max-w-md mx-auto text-xs text-left divide-y divide-gray-100">
            <div className="flex justify-between py-2 first:pt-0">
              <span className="text-gray-500">Ticket Category:</span>
              <strong className="text-gray-800">{category}</strong>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-gray-500">Auto Routed:</span>
              <strong className="text-gray-800">{category === 'Roads' ? 'PWD Roads Division' : 'Jal Shakti Water Board'}</strong>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-gray-500">AI Priority Score:</span>
              <strong className="text-indigo-600">{category === 'Electricity' ? 98 : 88}%</strong>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto pt-2">
            <button
              onClick={() => {
                alert("Receipt PDF file generated! Direct receipt download simulated successfully.");
              }}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-2 rounded-xl text-xs transition border border-gray-200 flex items-center justify-center gap-1 cursor-pointer"
            >
              <Download size={13} /> Download Receipt
            </button>
            <button
              onClick={() => {
                setCurrentView('citizen');
              }}
              className="flex-1 bg-[#002F6C] hover:bg-[#001d44] text-white font-bold px-4 py-2 rounded-xl text-xs transition shadow-md cursor-pointer"
            >
              Back to Citizen Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
