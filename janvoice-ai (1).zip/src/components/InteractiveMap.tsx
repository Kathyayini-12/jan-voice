/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Filter, 
  Layers, 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Eye, 
  Sparkles,
  Info,
  ThumbsUp,
  Zap,
  PhoneCall
} from 'lucide-react';
import { Complaint, Priority } from '../types';
import { APIProvider, Map, AdvancedMarker, Pin, useMap } from '@vis.gl/react-google-maps';

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

function BoundaryPolygon() {
  const map = useMap();
  useEffect(() => {
    if (!map || typeof google === 'undefined') return;
    const boundaryCoords = [
      { lat: 17.78, lng: 83.21 },
      { lat: 17.77, lng: 83.28 },
      { lat: 17.73, lng: 83.34 },
      { lat: 17.69, lng: 83.31 },
      { lat: 17.69, lng: 83.23 },
      { lat: 17.73, lng: 83.20 },
    ];
    const polygon = new google.maps.Polygon({
      paths: boundaryCoords,
      strokeColor: '#6366f1',
      strokeOpacity: 0.8,
      strokeWeight: 2.5,
      fillColor: '#6366f1',
      fillOpacity: 0.08,
    });
    polygon.setMap(map);
    return () => polygon.setMap(null);
  }, [map]);
  return null;
}

interface InteractiveMapProps {
  complaints: Complaint[];
  setSelectedComplaint: (c: Complaint) => void;
  setCurrentView: (view: string) => void;
  onUpvoteComplaint?: (id: string) => void;
}

export default function InteractiveMap({ 
  complaints, 
  setSelectedComplaint, 
  setCurrentView,
  onUpvoteComplaint 
}: InteractiveMapProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [mapType, setMapType] = useState<'vector' | 'satellite'>('vector');
  const [activePin, setActivePin] = useState<Complaint | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [heatmapEnabled, setHeatmapEnabled] = useState<boolean>(false);
  const [clusteringEnabled, setClusteringEnabled] = useState<boolean>(false);
  const [useGoogleMaps, setUseGoogleMaps] = useState<boolean>(hasValidKey);

  const getMarkerColor = (complaint: Complaint) => {
    if (complaint.status === 'Resolved') return '#2563EB'; // Blue
    if (complaint.priority === 'Critical' || complaint.priority === 'High') return '#DC2626'; // Red
    if (complaint.priority === 'Medium') return '#F97316'; // Orange
    return '#16A34A'; // Green
  };

  // Categories
  const categories = ['all', 'Roads', 'Water', 'Electricity', 'Health', 'Education', 'Sanitation', 'Garbage', 'Traffic', "Women's Safety", 'Others'];

  // Filter complaints that have coordinates
  const mapComplaints = complaints.filter(c => {
    const matchesCategory = selectedCategory === 'all' || c.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || c.status === selectedStatus;
    const matchesSearch = searchQuery === '' || 
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      c.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesStatus && matchesSearch;
  });

  // Simple clustering algorithm
  const clusterNodes = React.useMemo(() => {
    if (!clusteringEnabled) return [];
    
    const results: { lat: number; lng: number; count: number; items: Complaint[] }[] = [];
    const threshold = 0.025; // Lat/Lng distance grouping threshold
    
    mapComplaints.forEach(item => {
      // Find matching cluster
      const matched = results.find(c => {
        const dist = Math.sqrt(Math.pow(c.lat - item.lat, 2) + Math.pow(c.lng - item.lng, 2));
        return dist < threshold;
      });
      
      if (matched) {
        matched.count += 1;
        matched.items.push(item);
      } else {
        results.push({ lat: item.lat, lng: item.lng, count: 1, items: [item] });
      }
    });
    
    return results;
  }, [mapComplaints, clusteringEnabled]);

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case 'Critical': return 'text-red-600 bg-red-100 border-red-300';
      case 'High': return 'text-red-500 bg-red-50 border-red-200';
      case 'Medium': return 'text-orange-600 bg-orange-100 border-orange-300';
      case 'Low': return 'text-green-600 bg-green-100 border-green-300';
    }
  };

  const getStatusPinColor = (status: string, priority: Priority) => {
    if (status === 'Resolved') return 'bg-blue-600 ring-blue-300';
    if (status === 'Rejected') return 'bg-gray-400 ring-gray-200';
    if (priority === 'Critical') return 'bg-red-600 ring-red-400 animate-pulse';
    if (priority === 'High') return 'bg-red-500 ring-red-300';
    if (priority === 'Medium') return 'bg-orange-500 ring-orange-300';
    return 'bg-green-500 ring-green-300';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans">
      {/* Page Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            <span className="p-1.5 bg-[#002F6C] text-white rounded-lg"><MapPin size={18} /></span>
            Geo-Spatial Complaints Live Map
          </h2>
          <p className="text-gray-500 text-xs mt-1">
            Visualizing 50+ localized issues, emergencies, and resolved works across Visakhapatnam North constituency.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Map Provider selector */}
          <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200 shrink-0">
            <button 
              onClick={() => setUseGoogleMaps(true)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition flex items-center gap-1.5 cursor-pointer ${useGoogleMaps ? 'bg-indigo-600 text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <span>🗺️ Google Maps Live</span>
              {hasValidKey ? (
                <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>
            <button 
              onClick={() => setUseGoogleMaps(false)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${!useGoogleMaps ? 'bg-slate-800 text-white shadow-xs' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Offline Vector Grid
            </button>
          </div>

          {/* Map Type toggle */}
          <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200 shrink-0">
            <button 
              onClick={() => setMapType('vector')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${mapType === 'vector' ? 'bg-white text-gray-800 shadow-xs' : 'text-gray-500'}`}
            >
              Vector Street Grid
            </button>
            <button 
              onClick={() => setMapType('satellite')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition cursor-pointer ${mapType === 'satellite' ? 'bg-white text-gray-800 shadow-xs' : 'text-gray-500'}`}
            >
              AI Satellite Scan
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Filters Sidebar */}
        <div className="lg:col-span-3 space-y-5">
          <div className="bg-white border border-gray-100 p-4 rounded-xl shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-gray-800 flex items-center gap-2 border-b border-gray-100 pb-2">
              <Filter size={15} className="text-[#002F6C]" />
              Filter Map Layers
            </h3>

            {/* Quick search */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-400 uppercase">Search Location/ID</label>
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="e.g., Gajuwaka..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg py-1.5 pl-8 pr-3 outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C]"
                />
                <Search size={13} className="text-gray-400 absolute left-2.5 top-2.5" />
              </div>
            </div>

            {/* Category Filter */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-400 uppercase">Grievance Category</label>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 text-[11px] rounded-md transition font-medium border ${
                      selectedCategory === cat 
                        ? 'bg-[#002F6C] text-white border-[#002F6C]' 
                        : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    {cat === 'all' ? 'All categories' : cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Status Filter */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-400 uppercase">Grievance Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-lg p-2 outline-none focus:ring-1 focus:ring-[#002F6C]"
              >
                <option value="all">All Statuses</option>
                <option value="Pending">Pending Validation</option>
                <option value="In Progress">In Progress / Assigned</option>
                <option value="Resolved">Resolved / Completed</option>
                <option value="Rejected">Rejected / Closed</option>
              </select>
            </div>

            {/* Map Layers Toggles */}
            <div className="space-y-2 border-t border-gray-100 pt-3">
              <label className="text-[10px] font-bold text-gray-400 uppercase block">Advanced AI Layers</label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={heatmapEnabled}
                    onChange={(e) => {
                      setHeatmapEnabled(e.target.checked);
                      if (e.target.checked) setClusteringEnabled(false);
                    }}
                    className="rounded text-[#002F6C] focus:ring-[#002F6C] h-3.5 w-3.5 border-gray-300"
                  />
                  <span className="text-[11px] font-medium text-gray-700 flex items-center gap-1">🔥 AI Heatmap Overlay</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={clusteringEnabled}
                    onChange={(e) => {
                      setClusteringEnabled(e.target.checked);
                      if (e.target.checked) setHeatmapEnabled(false);
                    }}
                    className="rounded text-[#002F6C] focus:ring-[#002F6C] h-3.5 w-3.5 border-gray-300"
                  />
                  <span className="text-[11px] font-medium text-gray-700 flex items-center gap-1">🗂️ Cluster Grouping</span>
                </label>
              </div>
            </div>
          </div>

          {/* Quick Legend Info */}
          <div className="bg-slate-900 text-white p-4 rounded-xl space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Map Legend</h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-600 border border-white animate-pulse inline-block"></span>
                <span>Red = High / Critical Priority</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-orange-500 border border-white inline-block"></span>
                <span>Orange = Medium Priority</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-green-500 border border-white inline-block"></span>
                <span>Green = Low Priority</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-blue-600 border border-white inline-block"></span>
                <span>Blue = Resolved Works</span>
              </div>
            </div>
          </div>
        </div>

        {/* Live Map Canvas container */}
        <div className="lg:col-span-9 space-y-4">
          <div className="relative h-[500px] border border-gray-200 rounded-2xl overflow-hidden bg-[#EDF2F7] shadow-sm z-0">
            {useGoogleMaps && hasValidKey ? (
              <APIProvider apiKey={API_KEY} version="weekly">
                <Map
                  defaultCenter={{ lat: 17.73, lng: 83.275 }}
                  defaultZoom={12}
                  mapId="DEMO_MAP_ID"
                  mapTypeId={mapType === 'satellite' ? 'satellite' : 'roadmap'}
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  style={{ width: '100%', height: '100%' }}
                >
                  <BoundaryPolygon />

                  {/* Heatmap Overlays inside Google Map */}
                  {heatmapEnabled && mapComplaints.map((c) => {
                    if (c.status === 'Resolved' || (c.priority !== 'Critical' && c.priority !== 'High')) return null;
                    const intensityColor = c.priority === 'Critical' ? 'rgba(239, 68, 68, 0.45)' : 'rgba(249, 115, 22, 0.35)';
                    const radius = c.priority === 'Critical' ? 'w-16 h-16' : 'w-12 h-12';
                    return (
                      <AdvancedMarker
                        key={`g-heat-${c.id}`}
                        position={{ lat: c.lat, lng: c.lng }}
                      >
                        <div
                          className={`${radius} rounded-full pointer-events-none -translate-x-1/2 -translate-y-1/2 animate-pulse`}
                          style={{
                            background: `radial-gradient(circle, ${intensityColor} 0%, rgba(255,255,255,0) 70%)`
                          }}
                        />
                      </AdvancedMarker>
                    );
                  })}

                  {/* Pins / Clusters inside Google Map */}
                  {!clusteringEnabled ? (
                    mapComplaints.map((c) => (
                      <AdvancedMarker
                        key={`g-pin-${c.id}`}
                        position={{ lat: c.lat, lng: c.lng }}
                        onClick={() => setActivePin(c)}
                      >
                        <Pin
                          background={getMarkerColor(c)}
                          borderColor="#ffffff"
                          glyphColor="#ffffff"
                        />
                      </AdvancedMarker>
                    ))
                  ) : (
                    clusterNodes.map((node, nIdx) => {
                      if (node.count === 1) {
                        const c = node.items[0];
                        return (
                          <AdvancedMarker
                            key={`g-clustered-single-${c.id}`}
                            position={{ lat: c.lat, lng: c.lng }}
                            onClick={() => setActivePin(c)}
                          >
                            <Pin
                              background={getMarkerColor(c)}
                              borderColor="#ffffff"
                              glyphColor="#ffffff"
                            />
                          </AdvancedMarker>
                        );
                      }
                      return (
                        <AdvancedMarker
                          key={`g-cluster-node-${nIdx}`}
                          position={{ lat: node.lat, lng: node.lng }}
                          onClick={() => setActivePin(node.items[0])}
                        >
                          <div className="relative w-8 h-8 rounded-full bg-slate-950 text-white border-2 border-white shadow-xl flex items-center justify-center font-bold text-xs transform transition hover:scale-110 cursor-pointer">
                            <span>{node.count}</span>
                            <span className="absolute -inset-1 border border-slate-950 rounded-full opacity-40 animate-ping"></span>
                          </div>
                        </AdvancedMarker>
                      );
                    })
                  )}
                </Map>
              </APIProvider>
            ) : !hasValidKey && useGoogleMaps ? (
              <div className="absolute inset-0 bg-slate-900 text-white flex flex-col items-center justify-center p-8 text-center overflow-y-auto">
                <div className="max-w-md space-y-4">
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-2xl w-fit mx-auto">
                    <AlertTriangle className="text-red-400 font-bold" size={32} />
                  </div>
                  <h3 className="text-lg font-bold tracking-tight">Google Maps API Key Required</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    To enable the live, interactive Google Maps GIS grid with real-world satellite scans, geolocated pins, and routing, please connect your Google Maps Platform API key.
                  </p>
                  
                  <div className="bg-slate-800/80 border border-slate-700/60 p-4 rounded-xl text-left space-y-3">
                    <p className="text-[11px] font-semibold text-indigo-300 flex items-center gap-1">
                      <Sparkles size={12} /> SECURE SETUP INSTRUCTIONS:
                    </p>
                    <ol className="text-[11px] text-slate-200 list-decimal pl-4 space-y-2 leading-relaxed">
                      <li>
                        Get an API key: <a href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais" target="_blank" rel="noopener noreferrer" className="text-indigo-400 underline font-semibold hover:text-indigo-300">Google Cloud Console</a>
                      </li>
                      <li>
                        When the <strong>"Enter your environment variable to continue"</strong> popup appears, paste your key.
                      </li>
                      <li>
                        Or manually: Go to <strong>Settings</strong> (⚙️ top-right) → <strong>Secrets</strong> → add <code>GOOGLE_MAPS_PLATFORM_KEY</code> as secret name and paste your key.
                      </li>
                    </ol>
                  </div>

                  <div className="flex gap-3 justify-center pt-2">
                    <button
                      onClick={() => setUseGoogleMaps(false)}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition shadow-md"
                    >
                      Use Local Vector Map (No API Key)
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // Offline Simulated Map
              <>
                {mapType === 'satellite' ? (
                  <div className="absolute inset-0 bg-[#1A202C] opacity-90 transition-all duration-300">
                    {/* Beautiful custom vector constellation simulating GPS map satellite overlay */}
                    <div className="absolute inset-0 bg-[radial-gradient(#4a5568_1px,transparent_1px)] [background-size:24px_24px] opacity-40"></div>
                    {/* Mock sea boundary for Vizag port */}
                    <div className="absolute right-0 bottom-0 w-1/3 h-2/3 bg-[#0B2545] rounded-tl-[120px] border-l border-t border-teal-800/40 flex items-center justify-center">
                      <span className="text-[10px] text-teal-600/60 font-semibold tracking-widest font-mono uppercase">Bay of Bengal</span>
                    </div>
                    {/* Simulated contour scanlines */}
                    <div className="absolute left-12 top-24 w-40 h-40 border border-teal-500/20 rounded-full animate-pulse pointer-events-none"></div>
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-[#E2E8F0] transition-all duration-300">
                    {/* Light vector street grid */}
                    <div className="absolute inset-0 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:20px_20px]"></div>
                    {/* Draw mock main roads intersecting Vizag */}
                    <div className="absolute inset-y-0 left-1/3 w-3.5 bg-white border-x border-slate-300 rotate-12"></div>
                    <div className="absolute inset-x-0 top-1/2 h-3 bg-white border-y border-slate-300 -rotate-6"></div>
                    <div className="absolute inset-y-0 right-1/4 w-2.5 bg-white border-x border-slate-300"></div>
                    <div className="absolute inset-x-0 bottom-1/4 h-2 bg-white border-y border-slate-300"></div>
                    
                    {/* Water body for Vizag coast */}
                    <div className="absolute right-0 bottom-0 w-1/3 h-2/3 bg-blue-100 rounded-tl-[120px] border-l border-t border-blue-200 flex items-center justify-center">
                      <span className="text-[10px] text-blue-400 font-semibold tracking-widest font-mono uppercase">Vizag Coastline</span>
                    </div>
                  </div>
                )}

                {/* Constituency Boundary SVG Overlay */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                  <polygon
                    points="100,50 350,80 500,220 380,420 120,380 50,200"
                    className="fill-indigo-600/5 stroke-indigo-600/40 stroke-2"
                    style={{ strokeDasharray: '6 4' }}
                  />
                  <text x="120" y="70" className="fill-indigo-800 text-[10px] font-black uppercase tracking-wider font-sans opacity-75">
                    🛡️ Visakhapatnam North boundary
                  </text>
                </svg>

                {/* AI Heatmap Overlay */}
                {heatmapEnabled && mapComplaints.map((c) => {
                  if (c.status === 'Resolved' || (c.priority !== 'Critical' && c.priority !== 'High')) return null;
                  const topPercent = 100 - ((c.lat - 17.68) / 0.10) * 100;
                  const leftPercent = ((c.lng - 83.20) / 0.15) * 100;
                  const top = Math.max(8, Math.min(topPercent, 92));
                  const left = Math.max(8, Math.min(leftPercent, 92));
                  const intensityColor = c.priority === 'Critical' ? 'rgba(239, 68, 68, 0.45)' : 'rgba(249, 115, 22, 0.35)';
                  const radius = c.priority === 'Critical' ? '50px' : '35px';

                  return (
                    <div
                      key={`heat-${c.id}`}
                      className="absolute rounded-full pointer-events-none -translate-x-1/2 -translate-y-1/2 animate-pulse"
                      style={{
                        top: `${top}%`,
                        left: `${left}%`,
                        width: radius,
                        height: radius,
                        background: `radial-gradient(circle, ${intensityColor} 0%, rgba(255,255,255,0) 70%)`,
                        zIndex: 5
                      }}
                    />
                  );
                })}

                {/* Simulated GPS Pins or Clustered Nodes */}
                {!clusteringEnabled ? (
                  mapComplaints.map((c) => {
                    const topPercent = 100 - ((c.lat - 17.68) / 0.10) * 100;
                    const leftPercent = ((c.lng - 83.20) / 0.15) * 100;
                    const top = Math.max(8, Math.min(topPercent, 92));
                    const left = Math.max(8, Math.min(leftPercent, 92));

                    return (
                      <button
                        key={c.id}
                        onClick={() => setActivePin(c)}
                        className="absolute group z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
                        style={{ top: `${top}%`, left: `${left}%` }}
                      >
                        <div className="relative">
                          <span className={`w-4 h-4 rounded-full border-2 border-white shadow-md block transition-all group-hover:scale-135 ${getStatusPinColor(c.status, c.priority)}`}></span>
                          {c.priority === 'Critical' && c.status !== 'Resolved' && (
                            <span className="absolute -inset-1.5 border-2 border-red-600 rounded-full animate-ping opacity-60"></span>
                          )}
                          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] px-2 py-0.5 rounded shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition duration-150 pointer-events-none z-20">
                            {c.category} - {c.id}
                          </div>
                        </div>
                      </button>
                    );
                  })
                ) : (
                  clusterNodes.map((node, nIdx) => {
                    const topPercent = 100 - ((node.lat - 17.68) / 0.10) * 100;
                    const leftPercent = ((node.lng - 83.20) / 0.15) * 100;
                    const top = Math.max(8, Math.min(topPercent, 92));
                    const left = Math.max(8, Math.min(leftPercent, 92));

                    if (node.count === 1) {
                      const c = node.items[0];
                      return (
                        <button
                          key={`clustered-single-${c.id}`}
                          onClick={() => setActivePin(c)}
                          className="absolute group z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
                          style={{ top: `${top}%`, left: `${left}%` }}
                        >
                          <div className="relative">
                            <span className={`w-4 h-4 rounded-full border-2 border-white shadow-md block transition-all group-hover:scale-135 ${getStatusPinColor(c.status, c.priority)}`}></span>
                            <div className="absolute bottom-5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] px-2 py-0.5 rounded shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition duration-150 pointer-events-none z-20">
                              {c.category} - {c.id}
                            </div>
                          </div>
                        </button>
                      );
                    }

                    // Node cluster with count > 1
                    return (
                      <button
                        key={`cluster-node-${nIdx}`}
                        onClick={() => {
                          // Set active pin to the first item of the cluster
                          setActivePin(node.items[0]);
                        }}
                        className="absolute z-15 -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                        style={{ top: `${top}%`, left: `${left}%` }}
                      >
                        <div className="relative w-7 h-7 rounded-full bg-slate-950 text-white border-2 border-white shadow-xl flex items-center justify-center font-bold text-[10px] transform transition hover:scale-115">
                          <span>{node.count}</span>
                          <span className="absolute -inset-1 border border-slate-950 rounded-full opacity-40 group-hover:animate-ping"></span>
                        </div>
                      </button>
                    );
                  })
                )}
              </>
            )}

            {/* Instructions Overlay */}
            <div className="absolute left-4 top-4 bg-white/85 backdrop-blur-md border border-gray-200 px-3 py-1.5 rounded-lg text-[10px] font-semibold text-gray-700 flex items-center gap-1.5 pointer-events-none">
              <Info size={12} className="text-[#002F6C]" />
              <span>Click on any color-coded pin to view real-time AI Analysis report.</span>
            </div>

            {/* Active Pin Detailed Overlay Card Modal (Bottom Right of Map) */}
            {activePin && (
              <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-80 bg-white/95 backdrop-blur-md border border-indigo-100 rounded-xl shadow-xl p-4 animate-fade-in z-30 space-y-3">
                <div className="flex justify-between items-start">
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase border ${getPriorityColor(activePin.priority)}`}>
                    {activePin.priority} Urgent
                  </span>
                  <button 
                    onClick={() => setActivePin(null)}
                    className="text-gray-400 hover:text-gray-600 text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>

                <div>
                  <h4 className="font-bold text-gray-900 text-xs leading-tight line-clamp-2">{activePin.title}</h4>
                  <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">{activePin.description}</p>
                  <p className="text-[10px] text-gray-400 mt-1.5 flex items-center gap-1">
                    <MapPin size={10} /> {activePin.location}
                  </p>
                </div>

                <div className="bg-indigo-50/70 border border-indigo-100/60 p-2.5 rounded-lg space-y-1">
                  <div className="text-[9px] font-mono font-bold text-indigo-700 flex items-center gap-1">
                    <Sparkles size={10} /> AI AGENT VERIFICATION REPORT
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-600">
                    <span>Authenticity Index:</span>
                    <span className="font-bold text-indigo-700">{activePin.verificationConfidence || 92}% Verified</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-600">
                    <span>Priority Score:</span>
                    <span className="font-bold text-indigo-700">{activePin.priorityScore || 85}% Priority</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => {
                      setSelectedComplaint(activePin);
                      setCurrentView('track');
                    }}
                    className="flex-1 bg-[#002F6C] hover:bg-[#00234e] text-white text-center py-1.5 rounded-lg text-[10px] font-semibold transition cursor-pointer"
                  >
                    Track Progress Status
                  </button>
                  {onUpvoteComplaint && (
                    <button
                      onClick={() => {
                        onUpvoteComplaint(activePin.id);
                        alert(`Thank you! Your citizen support has been added to ticket ${activePin.id}.`);
                      }}
                      className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-1.5 rounded-lg text-[10px] font-semibold border border-gray-200 flex items-center gap-1 transition cursor-pointer"
                      title="Mark as duplicate / Upvote support"
                    >
                      <ThumbsUp size={11} />
                      <span>Upvote</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Stats Panel Below Map */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white border border-gray-100 p-3.5 rounded-xl text-center shadow-xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Visible Pins</span>
              <span className="text-xl font-bold text-gray-800 block mt-0.5">{mapComplaints.length}</span>
            </div>
            <div className="bg-white border border-gray-100 p-3.5 rounded-xl text-center shadow-xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Resolved Works</span>
              <span className="text-xl font-bold text-emerald-600 block mt-0.5">
                {mapComplaints.filter(c => c.status === 'Resolved').length}
              </span>
            </div>
            <div className="bg-white border border-gray-100 p-3.5 rounded-xl text-center shadow-xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Critical Spots</span>
              <span className="text-xl font-bold text-rose-600 block mt-0.5">
                {mapComplaints.filter(c => c.priority === 'Critical' && c.status !== 'Resolved').length}
              </span>
            </div>
            <div className="bg-white border border-gray-100 p-3.5 rounded-xl text-center shadow-xs">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">AI Auto-Routed</span>
              <span className="text-xl font-bold text-[#002F6C] block mt-0.5">100%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
