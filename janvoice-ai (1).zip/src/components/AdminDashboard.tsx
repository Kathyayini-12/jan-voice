/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { 
  Building, 
  Users, 
  Activity, 
  TrendingUp, 
  CheckCircle, 
  Clock, 
  ShieldAlert,
  ThumbsUp,
  Award,
  Sparkles,
  PieChart as PieIcon,
  AlertTriangle,
  Flame,
  Check
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  AreaChart,
  Area,
  Cell
} from 'recharts';
import { Complaint, Department } from '../types';

interface AdminDashboardProps {
  complaints: Complaint[];
  departments: Department[];
}

export default function AdminDashboard({ complaints, departments }: AdminDashboardProps) {

  // Dynamic Metrics calculations
  const metrics = useMemo(() => {
    const total = complaints.length;
    const resolved = complaints.filter(c => c.status === 'Resolved').length;
    const pending = complaints.filter(c => c.status === 'Pending').length;
    const inProgress = complaints.filter(c => c.status === 'In Progress').length;
    
    const resolvedPercent = total > 0 ? Math.round((resolved / total) * 100) : 0;
    const pendingPercent = total > 0 ? Math.round((pending / total) * 100) : 0;
    const inProgressPercent = total > 0 ? Math.round((inProgress / total) * 100) : 0;

    // Fraud Detection (AI Verification Confidence scan)
    const verificationScores = complaints.map(c => c.verificationConfidence || 85);
    const averageVerificationConfidence = Math.round(verificationScores.reduce((acc, curr) => acc + curr, 0) / total);
    const flaggedPotentialFranks = complaints.filter(c => (c.verificationConfidence || 85) < 80).length;

    // Citizen Satisfaction approximation
    const satisfactionIndex = 94.2;

    return { 
      total, 
      resolved, 
      pending, 
      inProgress, 
      resolvedPercent, 
      pendingPercent, 
      inProgressPercent,
      averageVerificationConfidence,
      flaggedPotentialFranks,
      satisfactionIndex 
    };
  }, [complaints]);

  // AI Suggested Priorities list (top 4 critical items sorted by Priority Score)
  const aiSuggestedPriorities = useMemo(() => {
    return complaints
      .filter(c => c.status !== 'Resolved' && c.status !== 'Rejected')
      .sort((a, b) => (b.priorityScore || 0) - (a.priorityScore || 0))
      .slice(0, 4);
  }, [complaints]);

  // Department Perf mapping for graph
  const departmentPerformanceData = useMemo(() => {
    return departments.map(d => {
      const total = complaints.filter(c => c.department === d.name).length;
      const solved = complaints.filter(c => c.department === d.name && c.status === 'Resolved').length;
      const perfRatio = total > 0 ? Math.round((solved / total) * 100) : d.resolvedCount > 0 ? Math.round((d.resolvedCount / (d.resolvedCount + d.unresolvedCount)) * 100) : 80;
      return {
        name: d.name.split(' / ')[1] || d.name.split(' Y')[0] || d.name,
        efficiency: perfRatio,
        headCount: d.staffCount
      };
    });
  }, [departments, complaints]);

  // Daily intake trend data (Area Chart)
  const intakeTrendData = [
    { day: 'Jul 01', incoming: 12, resolved: 14 },
    { day: 'Jul 02', incoming: 18, resolved: 11 },
    { day: 'Jul 03', incoming: 15, resolved: 16 },
    { day: 'Jul 04', incoming: 22, resolved: 18 },
    { day: 'Jul 05', incoming: 9, resolved: 13 },
    { day: 'Jul 06', incoming: 24, resolved: 21 },
    { day: 'Jul 07', incoming: 28, resolved: 25 }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans space-y-8">
      
      {/* Page Title & Status */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            <span className="p-1.5 bg-[#002F6C] text-white rounded-lg"><Activity size={18} /></span>
            National Administrative Grid / Officer Console
          </h2>
          <p className="text-gray-500 text-xs mt-1">
            Analyzing central response vectors, department performance indices, and real-time fraud alerts.
          </p>
        </div>

        <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full border border-emerald-100 flex items-center gap-1.5 shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Synchronized to CPGRAMS Nodes
        </span>
      </div>

      {/* Main Stats Row - 4 KPI metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Metric 1 */}
        <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-xs space-y-3 relative overflow-hidden">
          <div className="text-gray-400 font-bold text-[10px] uppercase tracking-wider block">Total Complaints Intake</div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-gray-800">{metrics.total}</span>
            <span className="text-emerald-500 text-xs font-bold font-mono">+12% (M-o-M)</span>
          </div>
          <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-[#002F6C] rounded-full" style={{ width: '85%' }}></div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-xs space-y-3">
          <div className="text-gray-400 font-bold text-[10px] uppercase tracking-wider block">Grievance Resolution %</div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-emerald-600">{metrics.resolvedPercent}%</span>
            <span className="text-gray-400 text-xs font-mono">({metrics.resolved} cases solved)</span>
          </div>
          <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${metrics.resolvedPercent}%` }}></div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-xs space-y-3">
          <div className="text-gray-400 font-bold text-[10px] uppercase tracking-wider block">Average Resolution Speed</div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-gray-800">1.4 Days</span>
            <span className="text-[#FF9933] text-xs font-bold font-mono">-72% with AI</span>
          </div>
          <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-[#FF9933] rounded-full" style={{ width: '92%' }}></div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-xs space-y-3">
          <div className="text-gray-400 font-bold text-[10px] uppercase tracking-wider block">Citizen Satisfaction Index</div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-indigo-600">{metrics.satisfactionIndex}%</span>
            <span className="text-indigo-400 text-xs font-bold font-mono">Excellent</span>
          </div>
          <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${metrics.satisfactionIndex}%` }}></div>
          </div>
        </div>
      </div>

      {/* Advanced AI Fraud Alerts & Suggested Priorities */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Suggested Priorities list (Left 7 cols) */}
        <div className="lg:col-span-7 bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
          <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2 border-b border-gray-100 pb-2">
            <Sparkles size={16} className="text-[#002F6C]" />
            AI Suggested Priority Ranking
          </h3>

          <div className="space-y-4 divide-y divide-gray-50">
            {aiSuggestedPriorities.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-4 pt-4 first:pt-0">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-rose-50 text-rose-800 text-[10px] font-bold px-1.5 py-0.5 rounded border border-rose-100">
                      Score: {item.priorityScore}%
                    </span>
                    <span className="font-bold text-gray-800 text-xs truncate">{item.title}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1 truncate">{item.location}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-bold text-gray-500 font-mono">
                    {(item.affectedCount || 500).toLocaleString()} Affected
                  </span>
                  <span className="text-[11px] font-bold text-[#002F6C] bg-indigo-50 px-2 py-0.5 rounded">
                    Auto-Routed
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Fraud & Security Alerts (Right 5 cols) */}
        <div className="lg:col-span-5 bg-linear-to-br from-slate-900 via-slate-950 to-rose-950 text-white p-6 rounded-2xl shadow-md space-y-5">
          <h3 className="font-bold text-sm text-rose-400 flex items-center gap-2">
            <ShieldAlert size={16} />
            AI Fraud & Spoof Protection Vault
          </h3>

          <div className="space-y-4">
            <div className="bg-white/5 border border-white/10 p-4 rounded-xl space-y-1">
              <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Average Verification Confidence</span>
              <span className="text-2xl font-black text-emerald-400">{metrics.averageVerificationConfidence}%</span>
              <p className="text-[10px] text-gray-400">Scan checks pass with highly-correlated GPS coordinates and authentic timestamps.</p>
            </div>

            <div className="bg-rose-900/25 border border-rose-800/30 p-4 rounded-xl space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-rose-300 uppercase tracking-wider flex items-center gap-1">
                  <Flame size={13} className="animate-pulse text-rose-400" /> Potential Fraud Flagged
                </span>
                <span className="bg-rose-600 text-white text-[9px] font-bold px-2 py-0.5 rounded uppercase">
                  {metrics.flaggedPotentialFranks} cases
                </span>
              </div>
              <p className="text-[11px] text-rose-200/80 leading-relaxed">
                JanVoice AI blocked 2 submission attempts today because the photo metadata EXIF coordinate did not match client location pins by over 4 kilometers.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Recharts Performance Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Intake trend (Area chart) */}
        <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
          <h3 className="font-bold text-gray-900 text-sm">Grievance Intake vs Resolution Curve</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={intakeTrendData}>
                <defs>
                  <linearGradient id="colorIncoming" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#002F6C" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#002F6C" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#138808" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#138808" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Area type="monotone" dataKey="incoming" stroke="#002F6C" fillOpacity={1} fill="url(#colorIncoming)" name="Incoming Reports" strokeWidth={2} />
                <Area type="monotone" dataKey="resolved" stroke="#138808" fillOpacity={1} fill="url(#colorResolved)" name="Resolved Grievances" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department Efficiency (Bar chart) */}
        <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs space-y-4">
          <h3 className="font-bold text-gray-900 text-sm">Department Resolution Efficiency Rate (%)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} stroke="#4A5568" />
                <YAxis label={{ value: 'Efficiency %', angle: -90, position: 'insideLeft', fontSize: 10 }} domain={[0, 100]} />
                <Tooltip formatter={(value) => [`${value}%`, 'Resolution efficiency']} />
                <Bar dataKey="efficiency" fill="#FF9933" radius={[4, 4, 0, 0]}>
                  {departmentPerformanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.efficiency > 85 ? '#138808' : '#FF9933'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
