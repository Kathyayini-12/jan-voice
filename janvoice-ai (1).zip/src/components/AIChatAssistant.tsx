/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Sparkles, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Languages, 
  CheckCircle, 
  Phone, 
  AlertTriangle, 
  HelpCircle,
  Clock,
  ShieldCheck,
  User,
  Info
} from 'lucide-react';
import { ChatMessage, Complaint, UserRole } from '../types';

interface AIChatAssistantProps {
  complaints: Complaint[];
  userRole: UserRole;
  onAutoCreateComplaint?: (category: string, title: string, desc: string, location: string) => void;
}

export default function AIChatAssistant({ 
  complaints, 
  userRole,
  onAutoCreateComplaint 
}: AIChatAssistantProps) {
  const [activeLang, setActiveLang] = useState<string>('English');
  const [inputText, setInputText] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-init',
      sender: 'ai',
      text: 'Namaste! I am your JanVoice AI Smart Civic Companion. I can help you check complaint status, map nearby issues, fetch emergency contacts, find voting booths, or draft a direct complaint using your voice. How can I serve you today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  // Voice States
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [speechTextGenerated, setSpeechTextGenerated] = useState<string>('');
  const [textToSpeechActive, setTextToSpeechActive] = useState<boolean>(false);
  const recordingTimer = useRef<any>(null);

  const languages = ['English', 'हिन्दी (Hindi)', 'తెలుగు (Telugu)', 'தமிழ் (Tamil)', 'मराठी (Marathi)'];

  // Start recording voice simulation
  const startRecordingSimulation = () => {
    setIsRecording(true);
    setRecordingSeconds(0);
    setSpeechTextGenerated('');
    
    recordingTimer.current = setInterval(() => {
      setRecordingSeconds(prev => {
        if (prev >= 6) {
          clearInterval(recordingTimer.current);
          setIsRecording(false);
          // Auto fill standard complaint
          const transcribedText = "There is a huge pothole near Gajuwaka Junction.";
          setSpeechTextGenerated(transcribedText);
          setInputText(transcribedText);
          return 6;
        }
        return prev + 1;
      });
    }, 1000);
  };

  const stopRecordingSimulation = () => {
    clearInterval(recordingTimer.current);
    setIsRecording(false);
    const transcribedText = "There is a huge pothole near Gajuwaka Junction.";
    setSpeechTextGenerated(transcribedText);
    setInputText(transcribedText);
  };

  // Quick action prompts
  const quickActions = [
    { label: 'Check Complaint Status', prompt: 'Status check for JV-2026-9041' },
    { label: 'Show Nearby Issues', prompt: 'What are the main resolved or active issues in Visakhapatnam North?' },
    { label: 'Government Contacts', prompt: 'Show me critical ministry phone numbers and email helpdesks.' },
    { label: 'Emergency Guidance', prompt: 'What is the standard procedure for toxic leaks or spark transformer safety?' },
    { label: 'Voting Information', prompt: 'How is municipal voting organized and where are localized booths?' },
    { label: 'Department Details', prompt: 'Show workload statistics of local Roads and Water boards.' },
    { label: 'General Civic Questions', prompt: 'What is the role of an MP in ward budget approvals (MPLADS)?' }
  ];

  // Voice speech translation map based on language select
  const voiceSpeechMap: Record<string, string> = {
    English: "There is a huge pothole near Gajuwaka Junction.",
    'हिन्दी (Hindi)': "गाजूवाका जंक्शन के पास एक बहुत बड़ा गड्ढा है।",
    'తెలుగు (Telugu)': "గాజువాక జంక్షన్ సమీపంలో ఒక పెద్ద గోతి ఉంది.",
    'தமிழ் (Tamil)': "காஜுவாகா சந்திப்புக்கு அருகில் ஒரு பெரிய குழி உள்ளது.",
    'मराठी (Marathi)': "गाजुवाका जंक्शन जवळ एक मोठा खड्डा आहे."
  };

  useEffect(() => {
    return () => clearInterval(recordingTimer.current);
  }, []);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    // Add user message
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    // Generate smart simulated response
    setTimeout(() => {
      let responseText = '';
      let isComplaintCreated = false;

      const normText = textToSend.toLowerCase();

      if (normText.includes('jv-2026-9041') || normText.includes('status check')) {
        responseText = "🔍 **Ticket Status for JV-2026-9041**: We have located your complaint! The status is **[IN PROGRESS]**. It has been assigned to *AE Satish Yadav* of the Roads Department. Immediate road patching work order has been issued. Delay is currently 0.0 days.";
      } else if (normText.includes('pothole') && normText.includes('gajuwaka')) {
        responseText = "🤖 **AI Intelligent Intent Detected!** \n\nYou reported: *'There is a huge pothole near Gajuwaka Junction.'* \n\nOur **AI Route Agent** has automatically parsed this hazard:\n- **Category:** Roads & PWD\n- **Estimated Severity:** Critical\n- **Confidence:** 98% GPS Authenticity\n- **Action:** A new complaint draft has been created and logged in the MP Dashboard. Target dispatch set to Roads department instantly!";
        isComplaintCreated = true;
        // Trigger parent callback to dynamically append
        if (onAutoCreateComplaint) {
          onAutoCreateComplaint(
            'Roads',
            'AI-Generated: Pothole Hazard near Gajuwaka Junction',
            'Citizen reported pothole hazard near Gajuwaka Junction via multilingual Voice Assistant. Auto-assigned to PWD.',
            'Gajuwaka Junction, Visakhapatnam North'
          );
        }
      } else if (normText.includes('nearby') || normText.includes('what are the main resolved')) {
        responseText = "📍 **Visakhapatnam North Civic Scan**: \nThere are currently 65 registered grievances in your region:\n- **Resolved:** 48 issues (including garbage cleanup at MVP Colony Girls High School)\n- **Active/Assigned:** 12 cases (including high-tension line trim at Muralinagar)\n- **Pending Validation:** 5 cases.\n\nYou can click on the 'Nearby Issues' tab above to see these color-coded on the map canvas!";
      } else if (normText.includes('contacts') || normText.includes('phone')) {
        responseText = "📞 **Constituency Helpdesk Registry**: \n- **Jal Shakti (Water Supply):** 1800-11-2244 (Director Smt. Rekha Vyas)\n- **PWD Roads Engineering Division:** 1800-11-PWD8 (Shri AE Satish Yadav)\n- **State Women Safety Cell:** 1091 (S.I. Neha Singh)\n- **DisCom Electrical emergency:** 1912\n- **National CPGRAMS Portal Support:** support-janvoice@nic.in";
      } else if (normText.includes('emergency') || normText.includes('safety')) {
        responseText = "🚨 **Critical Safety Advisory Directive**: \nIf you spot live sparks or biological hazards:\n1. Keep a 10-meter boundary distance.\n2. Do NOT touch wet surfaces or metal fences.\n3. Click our high-speed **'Emergency Report'** button inside the Citizen panel for instant 4-minute field dispatch bypassing manual paperwork desks.";
      } else if (normText.includes('voting') || normText.includes('booth')) {
        responseText = "🗳 **Constituency Voting & Booth Locator**: \nVisakhapatnam North municipal voting occurs on Ward Primary School centers. To verify your voter register ID card, please draft a text including your ward number, or visit the election directory node at eci.gov.in.";
      } else if (normText.includes('department') || normText.includes('workload')) {
        responseText = "🏢 **Department Workload Index**: \n- **PWD / Highways:** 18 unresolved, 312 solved. (Rating 4.6 ★)\n- **Jal Shakti / Water:** 22 unresolved, 185 solved. (Rating 4.1 ★)\n- **Solid Waste (Municipality):** 35 unresolved, 512 solved. (Rating 3.9 ★)\n- **DisCom Power Utility:** 11 unresolved, 298 solved. (Rating 4.4 ★)";
      } else {
        responseText = "💡 **General Civic Response**: \nThank you for reaching out. Under the central MPLADS legislative scheme, your local Member of Parliament has authorized ₹1.42 Crore for water and drainage upgrades in Visakhapatnam North ward clusters. How can I help you draft a complaint report or check coordinates today?";
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans">
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Voice Assistant Panel (Left 4 cols) */}
        <div className="lg:col-span-4 bg-linear-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md flex flex-col justify-between space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-[#FF9933]">
              <Sparkles size={16} className="animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-wider font-mono">Bilingual Voice Module</span>
            </div>
            <h3 className="text-lg font-black text-white">AI Voice Assistant</h3>
            <p className="text-xs text-gray-300 leading-relaxed">
              Submit complaints in regional languages simply by speaking. The AI listens, translates to bilingual registers, and compiles the grievance automatically.
            </p>
          </div>

          {/* Voice Waves Visualizer */}
          <div className="bg-slate-950/40 border border-slate-800 p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-4 py-8 relative overflow-hidden">
            {isRecording ? (
              <div className="space-y-4">
                {/* Simulated Audio Spectrum waves */}
                <div className="flex items-center justify-center gap-1 h-12">
                  <span className="w-1 bg-amber-400 rounded-full animate-bounce h-8" style={{ animationDelay: '0.1s' }}></span>
                  <span className="w-1 bg-amber-500 rounded-full animate-bounce h-12" style={{ animationDelay: '0.3s' }}></span>
                  <span className="w-1 bg-amber-400 rounded-full animate-bounce h-6" style={{ animationDelay: '0.5s' }}></span>
                  <span className="w-1 bg-amber-500 rounded-full animate-bounce h-10" style={{ animationDelay: '0.2s' }}></span>
                  <span className="w-1 bg-amber-400 rounded-full animate-bounce h-7" style={{ animationDelay: '0.4s' }}></span>
                </div>
                <div>
                  <span className="text-rose-500 text-xs font-bold font-mono uppercase tracking-wider animate-pulse flex items-center gap-1.5 justify-center">
                    <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                    Recording ({recordingSeconds}s)
                  </span>
                  <p className="text-[10px] text-gray-400 mt-1">Speaking: "{voiceSpeechMap[activeLang]}"</p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-gray-400 mx-auto border border-slate-700">
                  <MicOff size={20} />
                </div>
                <div>
                  <span className="text-xs text-gray-400 font-bold uppercase">Microphone Standby</span>
                  <p className="text-[10px] text-gray-500 mt-1">Select language and click recording button below.</p>
                </div>
              </div>
            )}

            {speechTextGenerated && (
              <div className="bg-white/5 border border-white/10 p-3 rounded-xl text-xs text-left w-full space-y-1">
                <span className="text-[9px] font-mono text-amber-500 font-bold uppercase block">AI TRANSCRIBED</span>
                <p className="text-gray-200">"{speechTextGenerated}"</p>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="space-y-4">
            {/* Language Selector */}
            <div className="space-y-1 text-xs">
              <label className="text-gray-400 font-bold uppercase text-[9px]">Listening Language</label>
              <div className="flex bg-slate-950 p-1.5 rounded-lg border border-slate-800 items-center justify-between">
                <Languages size={13} className="text-gray-400 shrink-0" />
                <select
                  value={activeLang}
                  onChange={(e) => setActiveLang(e.target.value)}
                  className="bg-transparent text-xs text-white border-none cursor-pointer outline-none w-full ml-2 focus:ring-0"
                >
                  {languages.map(l => (
                    <option key={l} value={l} className="text-gray-800">{l}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Mic trigger */}
            {isRecording ? (
              <button
                onClick={stopRecordingSimulation}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-2.5 rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
              >
                <MicOff size={15} /> Stop & Parse Recording
              </button>
            ) : (
              <button
                onClick={startRecordingSimulation}
                className="w-full bg-linear-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
              >
                <Mic size={15} /> Simulate Voice Input (6s)
              </button>
            )}
          </div>
        </div>

        {/* Chat Interface Panel (Right 8 cols) */}
        <div className="lg:col-span-8 bg-white border border-gray-150 rounded-2xl shadow-sm flex flex-col justify-between min-h-[550px] overflow-hidden">
          
          {/* Header */}
          <div className="bg-[#002F6C] text-white p-4 flex items-center justify-between border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="bg-white/10 p-2 rounded-xl text-white">
                <Sparkles size={18} />
              </div>
              <div>
                <h3 className="font-bold text-sm">JanVoice AI Civic Companion</h3>
                <p className="text-[10px] text-gray-300">Intelligent chat assistant in Indian Languages</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[9px] bg-white/10 text-white border border-white/10 px-2 py-0.5 rounded-full uppercase tracking-wider font-mono font-bold">
                Bilingual v4.0
              </span>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="p-4 flex-1 overflow-y-auto space-y-4 max-h-[350px]">
            {/* Quick Helper Banner */}
            <div className="bg-gray-50 border border-gray-200 p-3 rounded-xl text-[11px] text-gray-500 flex items-start gap-2 leading-relaxed">
              <Info size={14} className="text-[#002F6C] shrink-0 mt-0.5" />
              <span>Ask about ticket status, nearby complaints, local department contact numbers, emergency warnings, or say "pothole at Gajuwaka" to trigger automated AI routing.</span>
            </div>

            {messages.map((m) => {
              const isAi = m.sender === 'ai';
              return (
                <div key={m.id} className={`flex gap-3 max-w-2xl ${isAi ? 'mr-auto text-left' : 'ml-auto flex-row-reverse text-right'}`}>
                  {/* Icon */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs shrink-0 shadow-xs border ${isAi ? 'bg-indigo-50 border-indigo-100 text-[#002F6C]' : 'bg-[#002F6C] border-[#002F6C] text-white'}`}>
                    {isAi ? <Sparkles size={14} /> : <User size={14} />}
                  </div>

                  {/* Body Bubble */}
                  <div className={`p-3.5 rounded-2xl text-xs space-y-1.5 border leading-relaxed ${isAi ? 'bg-white border-gray-150 text-gray-800 rounded-tl-none shadow-xs' : 'bg-linear-to-r from-[#002F6C] to-indigo-700 border-[#002F6C] text-white rounded-tr-none shadow-md'}`}>
                    <p className="whitespace-pre-line">{m.text}</p>
                    <span className="text-[9px] text-gray-400 block font-mono mt-1">{m.timestamp}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Actions & Input Section */}
          <div className="p-4 border-t border-gray-100 space-y-3 bg-gray-50/50">
            {/* Quick response buttons */}
            <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-none">
              {quickActions.map((qa) => (
                <button
                  key={qa.label}
                  onClick={() => handleSendMessage(qa.prompt)}
                  className="bg-white border border-gray-200 px-3 py-1 rounded-full text-[10px] text-gray-600 font-semibold hover:border-[#002F6C] hover:text-[#002F6C] transition shadow-xs cursor-pointer shrink-0"
                >
                  {qa.label}
                </button>
              ))}
            </div>

            {/* Input form */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputText);
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type your civic query or describe an issue..."
                className="flex-1 bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-xs outline-none focus:ring-1 focus:ring-[#002F6C] focus:border-[#002F6C] transition shadow-inner"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="bg-[#002F6C] hover:bg-[#00204b] disabled:opacity-50 text-white px-4 rounded-xl transition shadow-md flex items-center justify-center cursor-pointer"
              >
                <Send size={14} />
              </button>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
}
