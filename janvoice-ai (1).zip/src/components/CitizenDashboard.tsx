/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  PlusCircle, 
  FileText, 
  MapPin, 
  Vote, 
  BellRing, 
  AlertOctagon, 
  Sparkles,
  Map,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  ThumbsUp,
  Check
} from 'lucide-react';
import { Complaint, Priority } from '../types';

interface CitizenDashboardProps {
  complaints: Complaint[];
  setCurrentView: (view: string) => void;
  setSelectedComplaint: (c: Complaint) => void;
  onUpvoteComplaint?: (id: string) => void;
  onTriggerEmergencyReport?: (category: string, title: string, desc: string, location: string) => void;
}

export default function CitizenDashboard({ 
  complaints, 
  setCurrentView, 
  setSelectedComplaint,
  onUpvoteComplaint,
  onTriggerEmergencyReport
}: CitizenDashboardProps) {
  const [activeTab, setActiveTab] = useState<'menu' | 'my-complaints' | 'vote' | 'emergency'>('menu');
  const [emergencySent, setEmergencySent] = useState(false);
  const [emergencyCat, setEmergencyCat] = useState('Power Hazard');
  const [emergencyDesc, setEmergencyDesc] = useState('');
  const [emergencyLocation, setEmergencyLocation] = useState('Gajuwaka Crossing, Visakhapatnam North');

  const citizenName = "Varada Venugopal";
  const constituency = "Visakhapatnam North";

  // Filter complaints reported by Varada
  const myComplaints = useMemo(() => {
    return complaints.filter(c => c.reporter === citizenName);
  }, [complaints]);

  // Filter un-resolved complaints for the "Community Priorities Voting" section
  const votableComplaints = useMemo(() => {
    return complaints
      .filter(c => c.status !== 'Resolved' && c.status !== 'Rejected' && c.reporter !== citizenName)
      .slice(0, 5);
  }, [complaints]);

  // Handle emergency trigger
  const handleEmergencySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onTriggerEmergencyReport) {
      onTriggerEmergencyReport(
        emergencyCat,
        `CRITICAL EMERGENCY: ${emergencyCat}`,
        emergencyDesc || `Severe emergency reported. Immediate civil danger.`,
        emergencyLocation
      );
      setEmergencySent(true);
      setTimeout(() => {
        setEmergencySent(false);
        setEmergencyDesc('');
        setActiveTab('menu');
      }, 3000);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'In Progress': return 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse';
      case 'Resolved': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Rejected': return 'bg-gray-50 text-gray-700 border-gray-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 font-sans space-y-8">
      
      {/* 👋 Welcome Header banner */}
      <div className="bg-linear-to-r from-[#002F6C] to-indigo-800 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        {/* Subtle decorative mesh background */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none"></div>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">👋 Good Morning, {citizenName}</h2>
          <p className="text-xs text-gray-300 mt-1 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#138808] inline-block"></span>
            Constituency Area: <strong className="text-white">{constituency}</strong>
          </p>
        </div>
        <div className="bg-[#FF9933] text-slate-950 font-bold text-xs px-3.5 py-1.5 rounded-lg border border-orange-400">
          Citizen ID Verified
        </div>
      </div>

      {activeTab === 'menu' && (
        <div className="space-y-6">
          {/* Announcements block (Government bulleting) */}
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start gap-3">
            <BellRing className="text-amber-600 shrink-0 mt-0.5" size={18} />
            <div className="text-xs">
              <span className="font-bold text-amber-800 block">📢 Announcements & Ward Advisories</span>
              <p className="text-amber-900/80 leading-relaxed mt-0.5">
                <strong>Water Supply Shutdown:</strong> Scheduled pipeline maintenance at Muralinagar on July 8 from 9:00 AM to 3:00 PM. Residents are advised to store drinking water.
              </p>
            </div>
          </div>

          {/* Core Feature Grid - 6 Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* 1. Report Issue */}
            <button 
              onClick={() => setCurrentView('raise')}
              className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs hover:border-[#002F6C]/20 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-[#002F6C]/5 text-[#002F6C] rounded-xl w-fit group-hover:bg-[#002F6C] group-hover:text-white transition">
                <PlusCircle size={22} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">➕ Report New Issue</h3>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  Submit a photo, audio note, or text describing an infrastructural hazard. AI classifies, verifies, and routes it instantly.
                </p>
              </div>
            </button>

            {/* 2. My Complaints */}
            <button 
              onClick={() => setActiveTab('my-complaints')}
              className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs hover:border-[#002F6C]/20 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-[#002F6C]/5 text-[#002F6C] rounded-xl w-fit group-hover:bg-[#002F6C] group-hover:text-white transition">
                <FileText size={22} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">📊 My Complaints</h3>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  Monitor the dynamic status and live audit timelines of your reported grievances ({myComplaints.length} active).
                </p>
              </div>
            </button>

            {/* 3. Nearby Issues */}
            <button 
              onClick={() => setCurrentView('map')}
              className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs hover:border-[#002F6C]/20 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-[#002F6C]/5 text-[#002F6C] rounded-xl w-fit group-hover:bg-[#002F6C] group-hover:text-white transition">
                <MapPin size={22} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">📍 Nearby Issues</h3>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  Open the geo-spatial map to inspect live grievances, hazard zones, and completed works in your neighborhood.
                </p>
              </div>
            </button>

            {/* 4. Community Priorities */}
            <button 
              onClick={() => setActiveTab('vote')}
              className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs hover:border-[#002F6C]/20 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-[#002F6C]/5 text-[#002F6C] rounded-xl w-fit group-hover:bg-[#002F6C] group-hover:text-white transition">
                <Vote size={22} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">🗳 Community Priorities</h3>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  Cast support for neighbor reports. The AI priority engine uses voter weight to bump priority scoring.
                </p>
              </div>
            </button>

            {/* 5. Announcements */}
            <button 
              onClick={() => {
                alert("Announcements Panel: Standard civil alerts are shown in the top advisory strip. More coming soon!");
              }}
              className="bg-white border border-gray-100 p-6 rounded-2xl shadow-xs hover:border-[#002F6C]/20 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-[#002F6C]/5 text-[#002F6C] rounded-xl w-fit group-hover:bg-[#002F6C] group-hover:text-white transition">
                <BellRing size={22} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">📢 Active Announcements</h3>
                <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                  View structural bulletins, power schedules, and active health warnings published by Visakhapatnam authorities.
                </p>
              </div>
            </button>

            {/* 6. Emergency Report */}
            <button 
              onClick={() => setActiveTab('emergency')}
              className="bg-rose-50 border border-rose-100 p-6 rounded-2xl shadow-xs hover:border-rose-200 hover:shadow-md transition-all duration-200 text-left cursor-pointer space-y-4 group"
            >
              <div className="p-3 bg-rose-600 text-white rounded-xl w-fit group-hover:bg-rose-700 transition">
                <AlertOctagon size={22} />
              </div>
              <div>
                <h3 className="font-bold text-rose-900 text-sm">⭐ Emergency Report</h3>
                <p className="text-xs text-rose-700 mt-1 leading-relaxed">
                  Report high-risk public threats (sparking live wire, gas leaks, water logging) for instant 5-minute dispatch.
                </p>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* View Tab: My Complaints */}
      {activeTab === 'my-complaints' && (
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 text-base flex items-center gap-2">
              <FileText size={18} className="text-[#002F6C]" />
              Your Grievance Portfolio
            </h3>
            <button 
              onClick={() => setActiveTab('menu')}
              className="text-xs text-gray-500 hover:text-gray-800 font-semibold"
            >
              ← Back to Main Menu
            </button>
          </div>

          {myComplaints.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-xs space-y-2">
              <p>You have not submitted any complaints yet. Your dashboard is clean!</p>
              <button 
                onClick={() => setCurrentView('raise')}
                className="bg-[#002F6C] text-white px-3 py-1.5 rounded-lg font-bold"
              >
                File Your First Complaint
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {myComplaints.map((c) => (
                <div key={c.id} className="border border-gray-150 rounded-xl p-4 flex flex-col md:flex-row justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-gray-400">{c.id}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${getStatusBadge(c.status)}`}>
                        {c.status}
                      </span>
                    </div>
                    <h4 className="font-bold text-gray-900 text-sm">{c.title}</h4>
                    <p className="text-xs text-gray-500 leading-relaxed max-w-2xl">{c.description}</p>
                    <p className="text-[10px] text-gray-400 flex items-center gap-1 mt-1">
                      <MapPin size={10} /> {c.location}
                    </p>
                  </div>

                  <div className="flex flex-col justify-between items-end gap-3 shrink-0">
                    <span className="text-xs font-bold font-mono text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                      {c.priorityScore}% priority
                    </span>
                    <button
                      onClick={() => {
                        setSelectedComplaint(c);
                        setCurrentView('track');
                      }}
                      className="text-[#002F6C] hover:underline text-xs font-bold flex items-center gap-1"
                    >
                      Audit timeline <ArrowRight size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* View Tab: Community Priorities Voting */}
      {activeTab === 'vote' && (
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
            <div>
              <h3 className="font-bold text-gray-900 text-base flex items-center gap-2">
                <Vote size={18} className="text-[#002F6C]" />
                Community Priorities Ledger
              </h3>
              <p className="text-[11px] text-gray-400">Help prioritize issues reported by neighbor wards. Vote to increase their impact score.</p>
            </div>
            <button 
              onClick={() => setActiveTab('menu')}
              className="text-xs text-gray-500 hover:text-gray-800 font-semibold shrink-0"
            >
              ← Back to Main Menu
            </button>
          </div>

          <div className="space-y-4">
            {votableComplaints.map((c) => (
              <div key={c.id} className="border border-gray-100 p-4 rounded-xl flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-gray-100 text-gray-600 text-[10px] font-mono px-2 py-0.5 rounded">{c.category}</span>
                    <span className="text-[10px] text-gray-400">by {c.reporter}</span>
                  </div>
                  <h4 className="font-bold text-gray-800 text-xs leading-snug">{c.title}</h4>
                  <p className="text-[11px] text-gray-400 flex items-center gap-1"><MapPin size={10} /> {c.location}</p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <span className="text-xs font-bold font-mono text-gray-700 block">{(c.priorityScore || 50) + 12} Upvotes</span>
                    <span className="text-[9px] text-gray-400">AI Priority: {c.priorityScore}%</span>
                  </div>
                  <button
                    onClick={() => {
                      if (onUpvoteComplaint) onUpvoteComplaint(c.id);
                      alert(`Grievance ${c.id} supported. Auto-score updated in priority queue.`);
                    }}
                    className="p-2 bg-indigo-50 hover:bg-indigo-600 text-[#002F6C] hover:text-white rounded-lg transition border border-indigo-100 shadow-xs cursor-pointer"
                    title="Upvote community concern"
                  >
                    <ThumbsUp size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* View Tab: Emergency Portal */}
      {activeTab === 'emergency' && (
        <div className="bg-rose-50 border border-rose-100 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center border-b border-rose-200 pb-3">
            <div className="flex items-center gap-2 text-rose-800">
              <AlertOctagon size={20} className="animate-bounce" />
              <h3 className="font-bold text-base">Critical Emergency Portal</h3>
            </div>
            <button 
              onClick={() => setActiveTab('menu')}
              className="text-xs text-rose-700 hover:text-rose-900 font-semibold"
            >
              ✕ Exit Emergency Portal
            </button>
          </div>

          {emergencySent ? (
            <div className="p-8 text-center text-rose-800 font-bold text-sm bg-white rounded-xl border border-rose-200 flex flex-col items-center justify-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-rose-600 text-white flex items-center justify-center text-lg font-black animate-ping">
                🚨
              </div>
              <div>
                <p>CRITICAL ALERT RECORDED BY JANVOICE AI</p>
                <p className="text-xs text-rose-600 font-normal mt-1">Automatic location extracted. Police & Fire hazard networks notified. ETA 4 minutes.</p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleEmergencySubmit} className="space-y-4">
              <p className="text-xs text-rose-700 leading-relaxed">
                <strong>Attention:</strong> Report only active physical dangers (live falling power lines, gas leakages, toxic clouds, structural collapses). Misuse of the emergency cell triggers penalties under civic codes.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-rose-800">Select Danger Category</label>
                  <select
                    value={emergencyCat}
                    onChange={(e) => setEmergencyCat(e.target.value)}
                    className="w-full text-xs bg-white border border-rose-200 rounded-lg p-2.5 outline-none text-rose-900 focus:ring-1 focus:ring-rose-500"
                  >
                    <option value="Live Sparking Cables">Live Sparking High Voltage Cables</option>
                    <option value="Municipal Chemical Leak">Municipal Chemical/Gas Leakage</option>
                    <option value="Primary Water Outbreak">Severe Main Sewer Flood/Water Collapse</option>
                    <option value="Structural Damage">Bridges or Building Cracks Collapse Threat</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-rose-800">Location Coordinate / Landmark</label>
                  <input
                    type="text"
                    value={emergencyLocation}
                    onChange={(e) => setEmergencyLocation(e.target.value)}
                    className="w-full text-xs bg-white border border-rose-200 rounded-lg p-2.5 outline-none text-rose-900 focus:ring-1 focus:ring-rose-500"
                    placeholder="Enter landmark near Visakhapatnam North..."
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-rose-800">Short Hazard Description</label>
                <textarea
                  value={emergencyDesc}
                  onChange={(e) => setEmergencyDesc(e.target.value)}
                  placeholder="e.g., transformer pole is sparking heavily and has set tree branches on fire near block crossroads..."
                  rows={3}
                  required
                  className="w-full text-xs bg-white border border-rose-200 rounded-lg p-2.5 outline-none text-rose-900 focus:ring-1 focus:ring-rose-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-rose-600 hover:bg-rose-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <AlertOctagon size={15} />
                  Dispatch AI Emergency Signal
                </button>
              </div>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
