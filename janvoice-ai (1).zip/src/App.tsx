/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  MapPin, 
  FileText, 
  Upload, 
  Mic, 
  MicOff, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  XCircle, 
  ArrowRight, 
  PlusCircle, 
  Search, 
  Send, 
  ChevronDown, 
  ChevronUp, 
  User, 
  Briefcase, 
  Activity, 
  BarChart3, 
  PieChart as PieIcon, 
  Map as MapIcon, 
  HelpCircle, 
  BookOpen, 
  Shield, 
  Download, 
  CheckCircle2, 
  Eye, 
  Users, 
  TrendingUp, 
  FileCheck, 
  Filter,
  RefreshCw,
  Bell,
  Check,
  AlertCircle,
  Calendar,
  Building,
  DollarSign,
  Award,
  ArrowUpRight,
  TrendingDown
} from 'lucide-react';

import { 
  Complaint, 
  ComplaintStatus, 
  Priority, 
  Department, 
  Scheme, 
  ChatMessage, 
  UserRole, 
  VillageStatus 
} from './types';

import { 
  DUMMY_DEPARTMENTS, 
  DUMMY_SCHEMES, 
  INITIAL_COMPLAINTS, 
  DUMMY_VILLAGES, 
  FAQ_ITEMS, 
  NEWS_UPDATES 
} from './data/dummyData';

import Header from './components/Header';
import Footer from './components/Footer';
import { exportProjectToZip } from './utils/zipExporter';

import CitizenDashboard from './components/CitizenDashboard';
import MPDashboard from './components/MPDashboard';
import AdminDashboard from './components/AdminDashboard';
import InteractiveMap from './components/InteractiveMap';
import AIAgentsOverview from './components/AIAgentsOverview';
import ComplaintWizard from './components/ComplaintWizard';
import AIChatAssistant from './components/AIChatAssistant';

// Store static code strings for ZIP packaging
const headerCode = `import React, { useState } from 'react';
import { Search, Languages, Eye, User, ShieldCheck, TrendingUp, Sparkles, Download } from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onDownloadZip: () => void;
  isDownloading: boolean;
  textSize: 'normal' | 'large' | 'xlarge';
  setTextSize: (size: 'normal' | 'large' | 'xlarge') => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
}

export default function Header({
  currentView,
  setCurrentView,
  userRole,
  setUserRole,
  onDownloadZip,
  isDownloading,
  textSize,
  setTextSize,
  highContrast,
  setHighContrast
}: HeaderProps) {
  return (
    <header className="w-full flex flex-col font-sans border-b border-gray-200 bg-white shadow-xs">
      {/* Code details... */}
    </header>
  );
}`;

const footerCode = `import React from 'react';
import { ShieldCheck, Heart, ExternalLink, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer({ setCurrentView }: { setCurrentView: (view: string) => void }) {
  return (
    <footer className="bg-[#1A202C] text-gray-300 font-sans border-t-4 border-[#002F6C]">
      {/* Code details... */}
    </footer>
  );
}`;

export default function App() {
  // Navigation & Role States
  const [currentView, setCurrentView] = useState<string>('home');
  const [userRole, setUserRole] = useState<UserRole>('Citizen');
  const [highContrast, setHighContrast] = useState<boolean>(false);
  const [textSize, setTextSize] = useState<'normal' | 'large' | 'xlarge'>('normal');

  // Core Complaints State (Synchronized across dashboards)
  const [complaints, setComplaints] = useState<Complaint[]>(INITIAL_COMPLAINTS);
  
  // Active Complaint Details (for View/Edit)
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  // Search input on tracking page
  const [trackIdInput, setTrackIdInput] = useState<string>('');
  const [trackError, setTrackError] = useState<string>('');

  // Notifications simulation
  const [notifications, setNotifications] = useState<{ id: string; title: string; time: string; read: boolean; type: 'info' | 'success' | 'alert' }[]>([
    { id: '1', title: 'AI automatically routed complaint JV-2026-9041 to PWD Ministry', time: '10 mins ago', read: false, type: 'success' },
    { id: '2', title: 'Critical Alert: Potential water outbreak warning flagged in Sector 4 Block C', time: '1 hour ago', read: false, type: 'alert' },
    { id: '3', title: 'New Scheme Uploaded: Pradhan Mantri Awas Yojana 2.0 guidelines', time: '1 day ago', read: true, type: 'info' }
  ]);

  // Raise Complaint Form States
  const [formCategory, setFormCategory] = useState<string>('Roads');
  const [formTitle, setFormTitle] = useState<string>('');
  const [formDesc, setFormDesc] = useState<string>('');
  const [formName, setFormName] = useState<string>('Animesh Mukherjee');
  const [formPhone, setFormPhone] = useState<string>('9432109876');
  const [formLocation, setFormLocation] = useState<string>('Ward 5, Kalyanpur Khas');
  const [formImage, setFormImage] = useState<string | null>(null);
  const [formVoiceRecording, setFormVoiceRecording] = useState<boolean>(false);
  const [formVoiceDuration, setFormVoiceDuration] = useState<number>(0);
  const [formVoiceTranscript, setFormVoiceTranscript] = useState<string>('');
  const [formAnonymize, setFormAnonymize] = useState<boolean>(false);
  const [formLatitude, setFormLatitude] = useState<number>(26.8450);
  const [formLongitude, setFormLongitude] = useState<number>(80.9400);
  const [formDepartment, setFormDepartment] = useState<string>('Ministry of Road Transport & Highways / PWD');
  const [formPriority, setFormPriority] = useState<Priority>('High');
  const [isGeneratingAI, setIsGeneratingAI] = useState<boolean>(false);
  const [aiGeneratedSummary, setAiGeneratedSummary] = useState<string>('');
  const [formSubmittedId, setFormSubmittedId] = useState<string | null>(null);
  const [formStep, setFormStep] = useState<number>(1); // 1: Input, 2: AI Routing Analysis, 3: Confirmation, 4: Submitted

  // AI Assistant Chat States
  const [assistantMode, setAssistantMode] = useState<UserRole>('Citizen');
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<Record<UserRole, ChatMessage[]>>({
    Citizen: [
      { 
        id: 'c1', 
        sender: 'ai', 
        text: 'Namaste! I am the JanVoice Citizen AI Advisor. I can help you draft beautifully detailed complaint reports, instantly search through active Government Welfare schemes, or summarize your pending issues. What is on your mind today?', 
        timestamp: '3:15 PM' 
      }
    ],
    Officer: [
      { 
        id: 'o1', 
        sender: 'ai', 
        text: 'Welcome, Officer. Neural Core v4.0 is active. I have analyzed 6 incoming complaints in your region. 2 have been flagged as "Potential Duplicates", and 1 is marked as "Critical Public Health Risk". How can I assist you in resource dispatch or triage reporting today?', 
        timestamp: '3:16 PM' 
      }
    ],
    MP: [
      { 
        id: 'm1', 
        sender: 'ai', 
        text: 'Good day, Honorable Member of Parliament. I have prepared your Weekly Constituency Insight Briefing. Complaints in Kalyanpur Constituency are resolved at an outstanding rate of 88%. However, "Bhimpur Block B" has experienced a 12% rise in drainage complaints. Would you like a detailed forecast on monsoon flood risks or budget allocation proposals?', 
        timestamp: '3:17 PM',
        suggestedActions: [
          'Generate Budget Reallocation PDF',
          'Forecast Flood Risks',
          'Show Department Workloads'
        ]
      }
    ]
  });
  const [isChatTyping, setIsChatTyping] = useState<boolean>(false);

  // FAQ Expand state
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  // Zip packaging state
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  // Map Simulation State
  const [selectedMapPin, setSelectedMapPin] = useState<{ lat: number; lng: number; title: string; category: string } | null>(null);

  // Timer Ref for voice recording simulation
  const voiceIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Handle tracking link from route searches
  useEffect(() => {
    if (currentView.startsWith('track:')) {
      const id = currentView.split(':')[1];
      setTrackIdInput(id);
      setCurrentView('track');
    }
  }, [currentView]);

  // Voice recording simulation timer
  useEffect(() => {
    if (formVoiceRecording) {
      voiceIntervalRef.current = setInterval(() => {
        setFormVoiceDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (voiceIntervalRef.current) {
        clearInterval(voiceIntervalRef.current);
      }
      setFormVoiceDuration(0);
    }
    return () => {
      if (voiceIntervalRef.current) clearInterval(voiceIntervalRef.current);
    };
  }, [formVoiceRecording]);

  // Download code ZIP handler
  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      // Create ZIP with static definitions matching files
      await exportProjectToZip('// Main Application Code', headerCode, footerCode);
      alert('JanVoice AI source code package prepared successfully! Check your downloads directory.');
    } catch (err) {
      console.error(err);
      alert('Error creating ZIP bundle.');
    } finally {
      setIsDownloading(false);
    }
  };

  // Generate Formal AI Summary during Complaint Raise process
  const triggerAICategorization = () => {
    setIsGeneratingAI(true);
    setTimeout(() => {
      // Simulate clever AI categorization based on Category selection and text
      let dept = 'Municipal Corporation / Solid Waste Management';
      let priority: Priority = 'Medium';
      let formalSummary = '';

      if (formCategory === 'Roads') {
        dept = 'Ministry of Road Transport & Highways / PWD';
        priority = formDesc.toLowerCase().includes('accident') || formDesc.toLowerCase().includes('danger') ? 'High' : 'Medium';
        formalSummary = `CRITICAL ROAD INFRASTRUCTURE RECONSTRUCTION TICKET: Verified high-risk road deformation reported at ${formLocation}. Structural potholes require immediate sub-base filling and cold-mix asphalt laying. Scheduled under Priority ${priority}.`;
      } else if (formCategory === 'Water') {
        dept = 'Ministry of Jal Shakti / Municipal Water Board';
        priority = formDesc.toLowerCase().includes('contamination') || formDesc.toLowerCase().includes('muddy') || formDesc.toLowerCase().includes('sick') ? 'Critical' : 'High';
        formalSummary = `PUBLIC SAFETY - WATER SUPPLY CONTAMINATION WARNING: High-priority tap water impurity reported at ${formLocation}. Immediate bacteriological test and pipeline flushing recommended to address community safety hazards.`;
      } else if (formCategory === "Women's Safety" || formCategory === 'Women Safety') {
        dept = 'State Police / Women Safety Cell';
        priority = 'Critical';
        formalSummary = `WOMEN SECURITY DEPLOYMENT PROTOCOL: Urgent reporting of blind spot safety vulnerabilities at ${formLocation}. Immediate action directed to State Police dispatch to re-route evening mobile patrol cars and alert municipal grid to restore public lighting.`;
      } else if (formCategory === 'Electricity') {
        dept = 'Ministry of Power / State DisCom';
        priority = formDesc.toLowerCase().includes('exam') || formDesc.toLowerCase().includes('voltage') ? 'High' : 'Medium';
        formalSummary = `ELECTRICAL DISTRIBUTION STABILITY REPORT: Substation power outage and voltage spike patterns logged at ${formLocation}. Dispatching local line technicians to inspect active feeder transformer cables.`;
      } else {
        formalSummary = `OFFICIAL COMPLAINT REGISTRATION SUMMARY: AI routed to ${dept}. Context analyzed successfully for ${formCategory} issue at ${formLocation}. Details logged to citizen portal.`;
      }

      setFormDepartment(dept);
      setFormPriority(priority);
      setAiGeneratedSummary(formalSummary);
      setIsGeneratingAI(false);
      setFormStep(3); // Go to Confirmation Step
    }, 1800);
  };

  // Finalize submission
  const handleSubmitComplaint = () => {
    const nextId = `JV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRecord: Complaint = {
      id: nextId,
      category: formCategory,
      title: formTitle || `Unscheduled ${formCategory} Issue`,
      description: formDesc,
      reporter: formAnonymize ? 'Anonymous Citizen' : formName,
      phone: formPhone,
      location: formLocation,
      department: formDepartment,
      status: 'Pending',
      priority: formPriority,
      date: new Date().toISOString().split('T')[0],
      image: formImage || undefined,
      voiceTranscript: formVoiceTranscript || undefined,
      lat: formLatitude,
      lng: formLongitude,
      updates: [
        { 
          date: new Date().toISOString().split('T')[0], 
          status: 'Submitted', 
          note: 'Complaint officially logged with AI routing parameters.', 
          officer: 'JanVoice AI Core Engine' 
        }
      ],
      acknowledgementDoc: `JV-ACK-${Math.floor(10000 + Math.random() * 90000)}`
    };

    setComplaints([newRecord, ...complaints]);
    setFormSubmittedId(nextId);
    setFormStep(4); // Go to finished screen
  };

  // Chat stream simulation
  const handleSendChat = (presetText?: string) => {
    const textToSend = presetText || chatInput;
    if (!textToSend.trim()) return;

    const newMessage: ChatMessage = {
      id: `m-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    // Update messages
    const currentMessages = chatMessages[assistantMode];
    setChatMessages({
      ...chatMessages,
      [assistantMode]: [...currentMessages, newMessage]
    });
    setChatInput('');
    setIsChatTyping(true);

    setTimeout(() => {
      let aiText = '';
      let actions: string[] = [];
      let chartType: 'bar' | 'pie' | 'line' | 'insights' | undefined;
      let chartData: { name: string; value: number; extra?: string }[] | undefined;

      const lower = textToSend.toLowerCase();

      if (assistantMode === 'Citizen') {
        if (lower.includes('scheme') || lower.includes('yojana') || lower.includes('help')) {
          aiText = 'Under your active location profiles, you qualify for 3 prominent Union Government benefits. The Jal Jeevan Mission currently supports your local district with subsidized clean water tap installation, and Ayushman Bharat provides up to ₹5 Lakh in cashless treatments. Would you like me to walk you through the application forms?';
          actions = ['Apply for Jal Jeevan Mission', 'Check Ayushman Eligibility', 'View PMAY House Grants'];
        } else if (lower.includes('pothole') || lower.includes('road') || lower.includes('water')) {
          aiText = 'I have analyzed your concern. Based on your prompt, I can draft a high-priority complaint for you with the Ministry of Road Transport. Shall I pre-populate a formal ticket including GPS coordinates?';
          actions = ['Draft PWD Complaint Now', 'Search similar complaints', 'Speak to Department rep'];
        } else {
          aiText = `Namaste! I have processed your inquiry about "${textToSend}". I recommend lodging a formal tracker or browsing relevant Ministry notifications under our Schemes segment. How would you like to proceed?`;
        }
      } else if (assistantMode === 'Officer') {
        if (lower.includes('duplicate') || lower.includes('clean') || lower.includes('triage')) {
          aiText = 'I have checked the Kalyanpur registry. We have identified that 2 complaints about Ram Mandir Bypass are duplicates of JV-2026-9041 (filed by Rajesh Sharma). Merging them into a single work order is recommended to optimize municipal machinery.';
          actions = ['Merge Duplicate Complaints', 'Assign Inspector Satish', 'Request Site Photo'];
        } else if (lower.includes('report') || lower.includes('status')) {
          aiText = 'Daily region report generated. Resolving times have improved by 18% since launching JanVoice AI routing. Sector 4 Block C remains our highest health advisory risk due to water complaints.';
          chartType = 'bar';
          chartData = [
            { name: 'Roads', value: 12 },
            { name: 'Water Contam.', value: 22 },
            { name: 'Power Cut', value: 8 },
            { name: 'Garbage pile', value: 35 }
          ];
          actions = ['Export Report as PDF', 'Alert Municipal Commissioner'];
        } else {
          aiText = 'Acknowledged, Officer. I have updated the work assignment tables. Please review the high-priority priority queue for the Mohanpur block, which currently holds 3 pending water sanitation reviews.';
        }
      } else if (assistantMode === 'MP') {
        if (lower.includes('village') || lower.includes('compare') || lower.includes('performance')) {
          aiText = 'Here is the infrastructure quality index comparison across your major assembly zones. Ramgarh is falling behind in water delivery metrics (48% satisfaction), whereas Shantipur leads with 89%. I suggest reallocating ₹40 Lakh from the unused road budget toward Ramgarhs tube-well deep bores.';
          chartType = 'pie';
          chartData = [
            { name: 'Kalyanpur Khas', value: 82, extra: 'Excellent' },
            { name: 'Ramgarh', value: 54, extra: 'Urgent Intervention' },
            { name: 'Mohanpur', value: 68, extra: 'Stable' },
            { name: 'Shantipur', value: 89, extra: 'Model Village' }
          ];
          actions = ['Reallocate MPLADS Budget', 'Schedule Village Sabha', 'Download Comparative Analysis'];
        } else if (lower.includes('forecast') || lower.includes('risk') || lower.includes('monsoon')) {
          aiText = 'JanVoice Neural Engine forecasts heavy water-logging risks in Ward 4 Gopalpur if the drainage clearances are not finished by mid-July. I recommend initiating an executive review with the Sanitation Commissioner immediately.';
          actions = ['Draft Executive Command', 'View Clogged Drains Map', 'Re-route Sanitation Vehicles'];
        } else {
          aiText = 'Honorable MP, constituency analytics have been refreshed. Based on regional trend graphs, health facility ratings are currently stable, but women safety issues require your attention due to broken lamps near Metro Gate 2. Would you like me to draft an official repair requisition?';
          actions = ['Approve Metro Gate Lights Project', 'Request Police Patrol Upgrades'];
        }
      }

      const reply: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: actions.length > 0 ? actions : undefined,
        chartType,
        chartData
      };

      setChatMessages(prev => ({
        ...prev,
        [assistantMode]: [...prev[assistantMode], reply]
      }));
      setIsChatTyping(false);
    }, 1500);
  };

  // Helper to trigger voice simulator text
  const startVoiceRecordingSim = () => {
    setFormVoiceRecording(true);
    setFormVoiceTranscript('Hearing speech...');
    setTimeout(() => {
      setFormVoiceTranscript('Draft transcript: "There is extreme flooding on Kalyanpur Main Market road. The sewer drains are completely choked with plastic bags, causing dirty water to enter our shops. Please clear it immediately."');
      setFormDesc('There is extreme flooding on Kalyanpur Main Market road. The sewer drains are completely choked with plastic bags, causing dirty water to enter our shops. Please clear it immediately.');
      setFormCategory('Garbage');
    }, 4000);
  };

  // Action helpers inside officer dashboard
  const handleUpdateStatus = (id: string, newStatus: ComplaintStatus, noteText: string) => {
    const updated = complaints.map(c => {
      if (c.id === id) {
        return {
          ...c,
          status: newStatus,
          updates: [
            ...c.updates,
            {
              date: new Date().toISOString().split('T')[0],
              status: newStatus,
              note: noteText,
              officer: 'Nodal Officer / Executive Engineer'
            }
          ]
        };
      }
      return c;
    });
    setComplaints(updated);
    if (selectedComplaint?.id === id) {
      setSelectedComplaint(updated.find(x => x.id === id) || null);
    }
    // Push new notification
    setNotifications([
      { 
        id: Date.now().toString(), 
        title: `Complaint ${id} status updated to ${newStatus}`, 
        time: 'Just now', 
        read: false, 
        type: 'info' 
      },
      ...notifications
    ]);
  };

  // Check Contrast Settings
  const contrastClass = highContrast ? 'bg-black text-yellow-300' : 'bg-slate-50 text-slate-900';
  const textClass = textSize === 'large' ? 'text-lg' : textSize === 'xlarge' ? 'text-xl' : 'text-sm';
  const headerTextClass = textSize === 'large' ? 'text-2xl' : textSize === 'xlarge' ? 'text-3xl' : 'text-xl';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all ${contrastClass} ${textClass}`}>
      {/* Dynamic Header Component */}
      <Header 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        userRole={userRole}
        setUserRole={(role) => {
          setUserRole(role);
          setAssistantMode(role);
        }}
        onDownloadZip={handleDownloadZip}
        isDownloading={isDownloading}
        textSize={textSize}
        setTextSize={setTextSize}
        highContrast={highContrast}
        setHighContrast={setHighContrast}
        notifications={notifications}
        setNotifications={setNotifications}
      />

      {/* Main App Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-8 space-y-8">
        
        {/* =========================================
            VIEW: HOME / LANDING PAGE 
           ========================================= */}
        {currentView === 'home' && (
          <div className="space-y-12">
            
            {/* Hero Section */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
              {/* Subtle dynamic background image matching Indian parliament/governance context */}
              <div 
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url('https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1600&q=80')` }}
              ></div>
              <div className="absolute inset-0 bg-gradient-to-r from-[#002F6C]/95 via-[#002F6C]/80 to-transparent"></div>

              {/* Decorative Wheel Silhouette */}
              <div className="absolute right-10 bottom-10 opacity-10 pointer-events-none hidden lg:block">
                <svg width="300" height="300" viewBox="0 0 100 100" className="text-white animate-spin-slow">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2" />
                  <circle cx="50" cy="50" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
                  {[...Array(24)].map((_, i) => (
                    <line 
                      key={i} 
                      x1="50" 
                      y1="50" 
                      x2={50 + 35 * Math.cos((i * 15 * Math.PI) / 180)} 
                      y2={50 + 35 * Math.sin((i * 15 * Math.PI) / 180)} 
                      stroke="currentColor" 
                      strokeWidth="1" 
                    />
                  ))}
                </svg>
              </div>

              {/* Hero Contents */}
              <div className="relative z-10 px-6 py-16 md:p-20 flex flex-col max-w-2xl text-white space-y-6">
                <div className="flex items-center gap-2">
                  {/* Small Ashoka Chakra Seal Icon */}
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#002F6C] font-black text-xs">
                    स
                  </div>
                  <span className="text-xs uppercase tracking-widest font-bold text-[#FF9933]">
                    Jan Kalyan Portal • MeitY Initiative
                  </span>
                </div>
                
                <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-tight">
                  JanVoice <span className="text-[#FF9933]">AI</span>
                </h1>
                
                <h2 className="text-lg md:text-2xl font-bold text-slate-100">
                  "AI-Powered Smart Governance for Every Citizen"
                </h2>
                
                <p className="text-sm md:text-base text-slate-200 leading-relaxed">
                  Report issues. Track progress. Empower governance. Submit complaints instantly via text, voice, or photos. Experience neural-engineered routing to regional officers with end-to-end audit transparency.
                </p>

                <div className="flex flex-wrap gap-4 pt-4">
                  <button 
                    onClick={() => {
                      setFormStep(1);
                      setCurrentView('raise');
                    }}
                    className="bg-[#FF9933] hover:bg-[#e07f20] text-white px-6 py-3 rounded-xl font-bold shadow-lg transition flex items-center gap-2 transform hover:scale-102 cursor-pointer"
                  >
                    <PlusCircle size={18} />
                    Raise Complaint
                  </button>
                  <button 
                    onClick={() => setCurrentView('track')}
                    className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-6 py-3 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer"
                  >
                    <Search size={18} />
                    Track Complaint
                  </button>
                  <button 
                    onClick={() => setCurrentView('ai-assistant')}
                    className="bg-[#138808] hover:bg-[#0f6b06] text-white px-6 py-3 rounded-xl font-bold shadow-lg transition flex items-center gap-2 cursor-pointer"
                  >
                    <Sparkles size={18} className="animate-pulse" />
                    Talk to AI Advisor
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Action Interactive Grid */}
            <div className="space-y-4">
              <div className="text-center">
                <h3 className="text-2xl font-black text-[#002F6C] uppercase tracking-wider">Select Complaint Segment</h3>
                <p className="text-xs text-gray-500">AI automatically processes, tags, and forwards issues belonging to these crucial segments</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
                {[
                  { name: 'Roads', icon: '🛣️', color: 'bg-amber-50 hover:border-amber-400 text-amber-800' },
                  { name: 'Water', icon: '🚰', color: 'bg-blue-50 hover:border-blue-400 text-blue-800' },
                  { name: 'Electricity', icon: '⚡', color: 'bg-yellow-50 hover:border-yellow-400 text-yellow-800' },
                  { name: 'Garbage', icon: '🗑️', color: 'bg-teal-50 hover:border-teal-400 text-teal-800' },
                  { name: 'Health', icon: '🏥', color: 'bg-red-50 hover:border-red-400 text-red-800' },
                  { name: 'Education', icon: '🎓', color: 'bg-indigo-50 hover:border-indigo-400 text-indigo-800' },
                  { name: "Women's Safety", icon: '🛡️', color: 'bg-pink-50 hover:border-pink-400 text-pink-800' },
                  { name: 'Agriculture', icon: '🌾', color: 'bg-green-50 hover:border-green-400 text-green-800' },
                ].map(cat => (
                  <button
                    key={cat.name}
                    onClick={() => {
                      setFormCategory(cat.name);
                      setFormStep(1);
                      setCurrentView('raise');
                    }}
                    className={`flex flex-col items-center justify-center p-4 rounded-2xl border border-slate-200 shadow-xs transition hover:shadow-md transform hover:-translate-y-1 text-center cursor-pointer ${cat.color}`}
                  >
                    <span className="text-3xl mb-2">{cat.icon}</span>
                    <span className="text-xs font-bold tracking-tight">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Live Analytics Overview */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Total Registered Complaints', value: '14,892', sub: 'Across 12 Categories', icon: <FileText className="text-blue-600" /> },
                { title: 'AI Automated Route Speed', value: '1.2 Sec', sub: 'Real-Time Neural Dispatch', icon: <Sparkles className="text-yellow-600 animate-pulse" /> },
                { title: 'Resolved in 48 Hours', value: '88.4%', sub: 'Target 90% SLA Met', icon: <CheckCircle2 className="text-[#138808]" /> },
                { title: 'Active Villages Monitored', value: '422', sub: 'In Kalyanpur Constituency', icon: <MapIcon className="text-teal-600" /> }
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 shrink-0">
                    {stat.icon}
                  </div>
                  <div>
                    <div className="text-2xl font-black text-[#002F6C]">{stat.value}</div>
                    <div className="text-xs font-bold text-gray-800">{stat.title}</div>
                    <div className="text-[10px] text-gray-500 font-medium">{stat.sub}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* How It Works - Elegant Stepper/Timeline */}
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8">
              <div className="text-center max-w-xl mx-auto">
                <h3 className="text-2xl font-black text-[#002F6C] uppercase tracking-wider">How the System Works</h3>
                <p className="text-xs text-gray-500">A completely transparent, AI-driven public resolution system built for rapid intervention</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 relative">
                {[
                  { step: '01', title: 'Multimodal Capture', desc: 'Citizen uploads a photo, records a voice memo, or type in a regional dialect.', icon: '🎙️' },
                  { step: '02', title: 'Neural Analysis', desc: 'Server-side AI translates the language, extracts metadata, and categorizes the issue.', icon: '🧠' },
                  { step: '03', title: 'Live Geo-Locating', desc: 'Auto-tags precise GPS coordinates, placing a pin on the official tracking map.', icon: '📍' },
                  { step: '04', title: 'Nodal Routing', desc: 'Instantly identifies the assigned department and triggers mobile alert to local officers.', icon: '⚙️' },
                  { step: '05', title: 'Audit Verification', desc: 'Officer repairs site, uploads closing proof. Citizen signs off on resolution.', icon: '✅' }
                ].map((item, i) => (
                  <div key={i} className="relative flex flex-col p-5 bg-slate-50 border border-slate-100 rounded-2xl">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-[10px] uppercase font-black tracking-widest text-[#FF9933] bg-[#FF9933]/10 px-2 py-0.5 rounded">
                        Stage {item.step}
                      </span>
                      <span className="text-2xl">{item.icon}</span>
                    </div>
                    <h4 className="text-sm font-extrabold text-[#002F6C] mb-2">{item.title}</h4>
                    <p className="text-xs text-gray-600 leading-relaxed flex-grow">{item.desc}</p>
                    
                    {i < 4 && (
                      <div className="hidden lg:block absolute -right-4 top-1/2 -translate-y-1/2 z-20 text-[#002F6C]/20">
                        <ArrowRight size={20} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Core Mission & Objectives */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <span className="text-xs font-black uppercase text-[#FF9933] tracking-widest bg-[#FF9933]/10 px-2 py-1 rounded">Our Mission</span>
                <h3 className="text-3xl font-black text-[#002F6C]">Pristine Governance for Every Village</h3>
                <p className="text-xs text-gray-600 leading-relaxed">
                  JanVoice AI was launched under the Digital India Umbrella to dismantle long bureaucracies. By providing a decentralized simulator accessible through standard browsers, we bridge the communication gap between municipal sweepers, engineering departments, local MPs, and remote villagers.
                </p>
                <div className="space-y-3 pt-2">
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-full bg-[#138808]/10 text-[#138808] shrink-0 mt-0.5">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-gray-900">100% Zero Manual Triage Delay</h4>
                      <p className="text-[11px] text-gray-500">Every submission gets dispatched to correct regional officers in under 2 seconds.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-full bg-[#138808]/10 text-[#138808] shrink-0 mt-0.5">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-gray-900">Transparent Public Audit Ledger</h4>
                      <p className="text-[11px] text-gray-500">Every status shift requires written verification notes and timestamp entries.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Government Schemes Showcase */}
              <div className="bg-slate-900 text-white p-8 rounded-3xl space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                  <Building size={140} />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs uppercase tracking-widest font-black text-[#FF9933]">Active Welfare Schemes</span>
                  <button onClick={() => setCurrentView('departments')} className="text-xs text-[#FF9933] hover:underline flex items-center gap-1">
                    View All <ArrowUpRight size={12} />
                  </button>
                </div>
                <h3 className="text-2xl font-black">Empowering Direct Benefits</h3>
                
                <div className="space-y-4">
                  {DUMMY_SCHEMES.map(sc => (
                    <div key={sc.id} className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition space-y-1">
                      <div className="flex justify-between items-center">
                        <h4 className="text-xs font-extrabold text-amber-400">{sc.title}</h4>
                        <span className="text-[9px] uppercase font-bold px-2 py-0.5 rounded bg-white/10 text-white/80">{sc.category}</span>
                      </div>
                      <p className="text-[11px] text-gray-300 line-clamp-1">{sc.description}</p>
                      <p className="text-[10px] text-gray-400 italic">Benefits: {sc.benefits}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Complaints Stream & Citizen Voices */}
            <div className="space-y-4">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-xl font-black text-[#002F6C] uppercase tracking-wider">Citizen Voice Activity</h3>
                  <p className="text-xs text-gray-500">Real complaints submitted and handled in the last 72 hours</p>
                </div>
                <button onClick={() => setCurrentView('citizen-dashboard')} className="text-xs text-[#002F6C] font-bold hover:underline">
                  Visit Citizen Dashboard
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {complaints.slice(0, 3).map((item) => (
                  <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:shadow-md transition">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black uppercase text-gray-400 tracking-wider">ID: {item.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          item.status === 'Resolved' ? 'bg-[#138808]/10 text-[#138808]' : 
                          item.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-[#002F6C] line-clamp-1">{item.title}</h4>
                      <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed">{item.description}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[10px] text-gray-500">
                      <span className="font-semibold flex items-center gap-1">
                        <MapPin size={10} className="text-[#FF9933]" />
                        {item.category}
                      </span>
                      <span>Logged: {item.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Frequently Asked Questions */}
            <div className="bg-slate-50 p-6 md:p-10 rounded-3xl border border-slate-200 space-y-6">
              <div className="text-center max-w-lg mx-auto">
                <h3 className="text-xl font-black text-[#002F6C] uppercase tracking-wider">Frequently Asked Questions</h3>
                <p className="text-xs text-gray-500">Get clarification on security, regional languages, and MP budget involvement</p>
              </div>

              <div className="space-y-3 max-w-3xl mx-auto">
                {FAQ_ITEMS.map((faq, idx) => (
                  <div key={idx} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                    <button 
                      onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                      className="w-full px-5 py-4 text-left flex justify-between items-center hover:bg-slate-50 transition cursor-pointer"
                    >
                      <span className="text-xs font-extrabold text-[#002F6C]">{faq.q}</span>
                      {expandedFaq === idx ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </button>
                    {expandedFaq === idx && (
                      <div className="px-5 pb-4 text-xs text-gray-600 leading-relaxed border-t border-slate-100 pt-3">
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* News & Updates Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1 flex flex-col justify-center space-y-4">
                <span className="text-xs font-black uppercase text-[#FF9933] tracking-widest">Live Bulletins</span>
                <h3 className="text-2xl font-black text-[#002F6C]">MeitY Media Announcements</h3>
                <p className="text-xs text-gray-500 leading-relaxed">
                  Stay updated on recent system installations, technological rollouts, and constituent funding approvals directed via JanVoice AI.
                </p>
              </div>
              <div className="lg:col-span-2 space-y-4">
                {NEWS_UPDATES.map((n, i) => (
                  <div key={i} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                    <div className="flex justify-between items-center text-[10px] font-bold">
                      <span className="text-[#FF9933]">{n.category}</span>
                      <span className="text-gray-400">{n.date}</span>
                    </div>
                    <h4 className="text-xs font-black text-gray-900">{n.title}</h4>
                    <p className="text-[11px] text-gray-600 leading-relaxed">{n.summary}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* =========================================
            VIEW: CITIZEN DASHBOARD
           ========================================= */}
        {currentView === 'citizen-dashboard' && (
          <CitizenDashboard 
            complaints={complaints}
            setCurrentView={setCurrentView}
            setSelectedComplaint={setSelectedComplaint}
            onUpvoteComplaint={(id) => {
              setComplaints(prev => prev.map(c => c.id === id ? { ...c, affectedCount: (c.affectedCount || 0) + 1 } : c));
              // Push notification
              setNotifications([
                {
                  id: Date.now().toString(),
                  title: `Upvoted complaint ${id} to flag critical community concern`,
                  time: 'Just now',
                  read: false,
                  type: 'info'
                },
                ...notifications
              ]);
            }}
            onTriggerEmergencyReport={(category, title, desc, location) => {
              const nextId = `JV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
              const newRecord: Complaint = {
                id: nextId,
                category,
                title,
                description: desc,
                reporter: 'Varada Venugopal',
                phone: '8765432109',
                location,
                department: category === 'Power Hazard' ? 'Ministry of Power / State DisCom' : 'Ministry of Jal Shakti / Municipal Water Board',
                status: 'Pending',
                priority: 'Critical',
                date: new Date().toISOString().split('T')[0],
                lat: 17.7423,
                lng: 83.2845,
                updates: [
                  {
                    date: new Date().toISOString().split('T')[0],
                    status: 'Submitted',
                    note: 'CRITICAL EMERGENCY PROTOCOL ACTIVATED. Dispatched immediately to municipal teams.',
                    officer: 'JanVoice AI Emergency Engine'
                  }
                ]
              };
              setComplaints([newRecord, ...complaints]);
              setNotifications([
                {
                  id: Date.now().toString(),
                  title: `⚠️ Emergency registered: ${title}`,
                  time: 'Just now',
                  read: false,
                  type: 'alert'
                },
                ...notifications
              ]);
            }}
          />
        )}

        {/* =========================================
            VIEW: OFFICER / ADMIN DASHBOARD
           ========================================= */}
        {(currentView === 'officer-dashboard' || currentView === 'admin-dashboard') && (
          <AdminDashboard 
            complaints={complaints}
            departments={DUMMY_DEPARTMENTS}
          />
        )}

        {/* =========================================
            VIEW: MP DASHBOARD
           ========================================= */}
        {currentView === 'mp-dashboard' && (
          <MPDashboard 
            complaints={complaints}
            departments={DUMMY_DEPARTMENTS}
            onUpdateComplaintStatus={(id, newStatus, note) => {
              handleUpdateStatus(id, newStatus as any, note);
            }}
          />
        )}

        {/* =========================================
            VIEW: LIVE INTERACTIVE MAP
           ========================================= */}
        {currentView === 'map' && (
          <InteractiveMap 
            complaints={complaints}
            setSelectedComplaint={setSelectedComplaint}
            setCurrentView={setCurrentView}
            onUpvoteComplaint={(id) => {
              setComplaints(prev => prev.map(c => c.id === id ? { ...c, affectedCount: (c.affectedCount || 0) + 1 } : c));
            }}
          />
        )}

        {/* =========================================
            VIEW: AI AGENTS OVERVIEW
           ========================================= */}
        {currentView === 'ai-agents' && (
          <AIAgentsOverview complaints={complaints} />
        )}

        {/* =========================================
            VIEW: AI CHAT ASSISTANT
           ========================================= */}
        {currentView === 'ai-assistant' && (
          <AIChatAssistant 
            complaints={complaints}
            userRole={userRole}
            onAutoCreateComplaint={(category, title, desc, location) => {
              const nextId = `JV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
              const newRecord: Complaint = {
                id: nextId,
                category,
                title,
                description: desc,
                reporter: 'AI Smart Assistant',
                phone: '9999999999',
                location,
                department: 'Municipal Corporation / Solid Waste Management',
                status: 'Pending',
                priority: 'High',
                date: new Date().toISOString().split('T')[0],
                lat: 17.6868,
                lng: 83.2185,
                updates: [
                  {
                    date: new Date().toISOString().split('T')[0],
                    status: 'Submitted',
                    note: 'Complaint automatically created and triaged via AI Voice companion.',
                    officer: 'JanVoice Voice AI'
                  }
                ]
              };
              setComplaints([newRecord, ...complaints]);
              setNotifications([
                {
                  id: Date.now().toString(),
                  title: `AI Companion created new complaint: ${title}`,
                  time: 'Just now',
                  read: false,
                  type: 'success'
                },
                ...notifications
              ]);
            }}
          />
        )}

        {/* =========================================
            VIEW: DEPARTMENTS & SCHEMES LIST
           ========================================= */}
        {currentView === 'departments' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-black text-[#002F6C] uppercase tracking-tight">Ministries & Welfare Schemes</h2>
              <p className="text-xs text-gray-500">Browse official Government of India administrative wings and active public support directives.</p>
            </div>

            {/* Schemes Stream */}
            <div className="space-y-4">
              <h3 className="text-lg font-black text-gray-900 flex items-center gap-2">
                <BookOpen size={18} className="text-[#FF9933]" />
                Union Welfare Schemes Registry
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {DUMMY_SCHEMES.map(sc => (
                  <div key={sc.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                    <div className="flex justify-between items-start gap-4">
                      <div className="space-y-0.5">
                        <span className="text-[9px] uppercase font-bold text-[#FF9933] bg-[#FF9933]/10 px-2 py-0.5 rounded">
                          {sc.category}
                        </span>
                        <h4 className="text-sm font-extrabold text-[#002F6C] pt-1">{sc.title}</h4>
                      </div>
                      <span className="text-xs text-gray-400 font-semibold">{sc.ministry}</span>
                    </div>

                    <p className="text-xs text-gray-600 leading-relaxed">{sc.description}</p>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-gray-700">
                      <strong className="text-gray-950 block mb-0.5">Verified Benefits:</strong>
                      {sc.benefits}
                    </div>

                    <div className="flex gap-2 pt-2 justify-end">
                      <button 
                        onClick={() => {
                          setAssistantMode('Citizen');
                          setCurrentView('ai-assistant');
                          setTimeout(() => {
                            handleSendChat(`Drafting application request for ${sc.title}`);
                          }, 200);
                        }}
                        className="bg-slate-100 hover:bg-[#002F6C] hover:text-white px-3 py-1.5 rounded-lg text-[10px] font-extrabold transition"
                      >
                        Ask AI Assistant
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Ministries Registry */}
            <div className="space-y-4 pt-4">
              <h3 className="text-lg font-black text-gray-900 flex items-center gap-2">
                <Building size={18} className="text-[#002F6C]" />
                Nodal Administrative Ministries
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {DUMMY_DEPARTMENTS.map(dept => (
                  <div key={dept.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <h4 className="text-xs font-black text-[#002F6C]">{dept.name}</h4>
                      <div className="text-[10px] text-gray-500 leading-relaxed">
                        <strong className="text-gray-800">Head:</strong> {dept.head}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-2 text-[10px]">
                      <div>
                        <div className="text-gray-400 uppercase font-bold">Staff Count</div>
                        <div className="font-extrabold text-gray-900">{dept.staffCount} Officers</div>
                      </div>
                      <div>
                        <div className="text-gray-400 uppercase font-bold">Rating</div>
                        <div className="font-extrabold text-[#138808]">★ {dept.rating}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* =========================================
            VIEW: ABOUT THE INITIATIVE
           ========================================= */}
        {currentView === 'about' && (
          <div className="space-y-8 max-w-4xl mx-auto">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase tracking-widest font-black text-[#FF9933] bg-[#FF9933]/10 px-3 py-1 rounded">
                Digital India Directive
              </span>
              <h2 className="text-4xl font-black text-[#002F6C]">About JanVoice AI</h2>
              <p className="text-xs text-gray-500">Bridging technology, transparent routing, and local constituency development budgets.</p>
            </div>

            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6 text-xs text-gray-600 leading-relaxed">
              <h3 className="text-base font-extrabold text-[#002F6C]">1. Next-Generation Grievance System</h3>
              <p>
                Under conventional portals, citizen complaints go through weeks of manually sorted triage, resulting in missing files, administrative lag, and localized corruption risks. JanVoice AI addresses this challenge using high-performance server-side language models that parse natural sentences, tag priority parameters based on hazard severity keywords, identify duplicate reports automatically, and route files immediately to municipal supervisors.
              </p>

              <h3 className="text-base font-extrabold text-[#002F6C]">2. Involving Local Representatives</h3>
              <p>
                By granting the local Member of Parliament (MP) and Ward Officer distinct analytical dashboards, the app ties on-ground realities directly with policy. MPs can inspect where complaints spike, examine village quality scores, and use AI-drafted proposals to allocate crucial Development funds (MPLADS) directly toward water-scarce or power-strained villages.
              </p>

              <h3 className="text-base font-extrabold text-[#002F6C]">3. Standard Offline Compilation Compliant</h3>
              <p>
                This portal is engineered strictly as a client-side prototype. It uses robust offline mock models to simulate the complex state transfers, making it 100% compliant with clean local execution inside standard browsers, VS Code, or sandboxed preview targets without API crash risks.
              </p>
            </div>
          </div>
        )}

        {/* =========================================
            VIEW: CONTACT HELPDESK
           ========================================= */}
        {currentView === 'contact' && (
          <div className="space-y-8 max-w-4xl mx-auto">
            <div>
              <h2 className="text-3xl font-black text-[#002F6C] uppercase tracking-tight text-center">National Informatics Helpdesk</h2>
              <p className="text-xs text-gray-500 text-center">Direct communication lines to system administrators, nodal ministries, and developers.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-sm font-extrabold text-[#002F6C] uppercase">Technical support</h3>
                <p className="text-xs text-gray-600">For issues regarding speech transcription bugs, location picker errors, or dashboard simulation switches:</p>
                
                <div className="text-xs space-y-2 text-gray-700">
                  <div className="flex justify-between border-b border-slate-100 pb-2">
                    <span>📧 Central Email:</span>
                    <strong className="text-gray-900">support-janvoice@nic.in</strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-100 pb-2">
                    <span>📞 National Toll-Free:</span>
                    <strong className="text-[#138808]">1800-11-5500</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>🏛️ Headquarters:</span>
                    <strong className="text-gray-900 text-right">NIC Division, New Delhi</strong>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-sm font-extrabold text-[#002F6C] uppercase">Administrative Escalation</h3>
                <p className="text-xs text-gray-600">If a regional officer fails to update the timeline or resolve a high-priority complaint within 48 hours:</p>
                
                <div className="text-xs space-y-2 text-gray-700">
                  <div className="flex justify-between border-b border-slate-100 pb-2">
                    <span>⚖️ Grievance Director:</span>
                    <strong className="text-gray-900">Shri Vinay Prasad, IAS</strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-100 pb-2">
                    <span>💬 MP Advisory panel:</span>
                    <strong className="text-[#002F6C]">Kalyanpur MP Office</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================
            VIEW: COMPLAINT RAISING WIZARD
           ========================================= */}
        {currentView === 'raise' && (
          <ComplaintWizard 
            onAddComplaint={(newRecord) => {
              setComplaints([newRecord, ...complaints]);
              setNotifications([
                {
                  id: Date.now().toString(),
                  title: `New complaint filed: ${newRecord.title}`,
                  time: 'Just now',
                  read: false,
                  type: 'success'
                },
                ...notifications
              ]);
            }}
            setCurrentView={setCurrentView}
            setSelectedComplaint={setSelectedComplaint}
          />
        )}

        {/* =========================================
            VIEW: TRACK COMPLAINT PAGE
           ========================================= */}
        {currentView === 'track' && (
          <div className="space-y-8 max-w-4xl mx-auto">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-black text-[#002F6C] uppercase tracking-tight">Track Grievance Timeline</h2>
              <p className="text-xs text-gray-500">Enter your Complaint ID (e.g. JV-2026-9041) to inspect real-time progress, assigned workers, and audit notes.</p>
            </div>

            {/* Tracker Input search block */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1 space-y-1 w-full">
                <label className="text-[10px] font-black text-gray-500 uppercase block">Complaint ID / phone number</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="e.g. JV-2026-9041..."
                    value={trackIdInput}
                    onChange={(e) => {
                      setTrackIdInput(e.target.value);
                      setTrackError('');
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2.5 pl-3 pr-9 text-xs focus:ring-1 focus:ring-[#002F6C] outline-none"
                  />
                  <Search size={14} className="absolute right-3 top-3.5 text-gray-400" />
                </div>
              </div>

              <button 
                onClick={() => {
                  if (!trackIdInput.trim()) {
                    setTrackError('Please input a valid track ID.');
                    return;
                  }
                  const match = complaints.find(c => c.id.toUpperCase() === trackIdInput.toUpperCase() || c.phone === trackIdInput);
                  if (match) {
                    setSelectedComplaint(match);
                    setTrackError('');
                  } else {
                    setTrackError('No record found matching that ID in the Kalyanpur database.');
                    setSelectedComplaint(null);
                  }
                }}
                className="bg-[#002F6C] hover:bg-[#001c3d] text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-xs transition w-full sm:w-auto cursor-pointer"
              >
                Track Now
              </button>
            </div>

            {trackError && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-bold text-center">
                {trackError}
              </div>
            )}

            {/* Tracker Result Display */}
            {selectedComplaint ? (
              <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-8">
                
                {/* Result header */}
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 pb-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-[#FF9933] font-black uppercase bg-[#FF9933]/10 px-2 py-0.5 rounded">
                        {selectedComplaint.category}
                      </span>
                      <span className="text-gray-400">ID: {selectedComplaint.id}</span>
                    </div>
                    <h3 className="text-base font-extrabold text-[#002F6C] mt-1">{selectedComplaint.title}</h3>
                  </div>

                  <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase text-center shrink-0 ${
                    selectedComplaint.status === 'Resolved' ? 'bg-[#138808]/10 text-[#138808]' : 
                    selectedComplaint.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {selectedComplaint.status}
                  </span>
                </div>

                {/* Split Details: Left Updates, Right Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  
                  {/* Timeline progress cards */}
                  <div className="md:col-span-2 space-y-4">
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Audit Step-by-Step Timeline</h4>
                    
                    <div className="relative pl-6 border-l-2 border-slate-200 space-y-6">
                      {selectedComplaint.updates.map((up, uIdx) => (
                        <div key={uIdx} className="relative">
                          {/* Chronological dot */}
                          <div className={`absolute -left-[31px] top-1 w-4.5 h-4.5 rounded-full border-4 border-white ${
                            up.status === 'Resolved' ? 'bg-[#138808]' : 
                            up.status === 'In Progress' ? 'bg-blue-500' : 'bg-[#FF9933]'
                          }`}></div>

                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between items-center text-[10px] font-bold">
                              <span className="text-gray-900 font-extrabold uppercase bg-slate-100 px-2 py-0.5 rounded">{up.status}</span>
                              <span className="text-gray-400">{up.date}</span>
                            </div>
                            <p className="text-gray-600 leading-relaxed pt-1">{up.note}</p>
                            {up.officer && (
                              <div className="text-[10px] text-gray-400 font-semibold">Officer Logged: {up.officer}</div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Inspector / Location Details right */}
                  <div className="space-y-6 text-xs text-slate-700">
                    
                    {/* Location */}
                    <div className="p-4 rounded-xl bg-slate-50 space-y-2">
                      <strong className="text-[10px] font-black uppercase text-gray-400 block">Reported Location</strong>
                      <p className="text-gray-900 font-semibold">{selectedComplaint.location}</p>
                      
                      {/* Photo preview placeholder if uploaded */}
                      {selectedComplaint.image && (
                        <div className="mt-3 rounded-lg overflow-hidden border border-slate-200 h-28 relative">
                          <img src={selectedComplaint.image} alt="Complaint preview" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                    {/* Assigned Worker */}
                    <div className="p-4 rounded-xl bg-slate-50 space-y-2">
                      <strong className="text-[10px] font-black uppercase text-gray-400 block">Assigned Maintenance Worker</strong>
                      <div className="font-extrabold text-[#002F6C] text-sm">
                        {selectedComplaint.assignedWorker || 'Pending Assignment'}
                      </div>
                      <p className="text-[10px] text-gray-500 leading-snug">
                        Local ward workers are dispatched automatically within 2 hours of priority reviews.
                      </p>
                    </div>

                    {/* Nodal department details */}
                    <div className="p-4 rounded-xl bg-slate-50 space-y-1">
                      <span className="text-[10px] font-bold text-gray-400 block uppercase">Nodal Department</span>
                      <strong className="text-gray-950 font-bold block leading-snug">{selectedComplaint.department}</strong>
                    </div>

                  </div>

                </div>

              </div>
            ) : (
              <div className="bg-white p-12 rounded-3xl border border-slate-200 shadow-xs text-center text-gray-400 text-xs">
                <p className="max-w-xs mx-auto">Please input an active complaint reference ID above to query its audit logs. Try "JV-2026-9041".</p>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Dynamic Footer Component */}
      <Footer setCurrentView={setCurrentView} />
    </div>
  );
}
