/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

export async function exportProjectToZip(appCode: string, headerCode: string, footerCode: string) {
  const zip = new JSZip();

  // Root Files
  zip.file('.env.example', `# GEMINI_API_KEY: Required for Gemini AI API calls.
GEMINI_API_KEY="MY_GEMINI_API_KEY"
APP_URL="MY_APP_URL"
`);

  zip.file('.gitignore', `node_modules
dist
.env
.env.local
.DS_Store
`);

  zip.file('index.html', `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>JanVoice AI - AI-Powered Smart Governance Portal</title>
  </head>
  <body class="bg-slate-50">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`);

  zip.file('metadata.json', `{
  "name": "JanVoice AI",
  "description": "AI-Powered Smart Governance Platform for India, facilitating issue reporting, tracking, and MP/Officer dashboards.",
  "requestFramePermissions": [],
  "majorCapabilities": ["MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"]
}
`);

  zip.file('package.json', `{
  "name": "janvoice-ai",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview"
  },
  "dependencies": {
    "jszip": "^3.10.1",
    "lucide-react": "^0.546.0",
    "react": "^19.0.1",
    "react-dom": "^19.0.1"
  },
  "devDependencies": {
    "@types/react": "^19.0.1",
    "@types/react-dom": "^19.0.1",
    "@vitejs/plugin-react": "^5.0.4",
    "autoprefixer": "^10.4.21",
    "tailwindcss": "^4.1.14",
    "typescript": "~5.8.2",
    "vite": "^6.2.3"
  }
}
`);

  zip.file('tsconfig.json', `{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "allowJs": true,
    "jsx": "react-jsx",
    "paths": {
      "@/*": ["./*"]
    },
    "allowImportingTsExtensions": true,
    "noEmit": true
  }
}
`);

  zip.file('vite.config.ts', `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
  };
});
`);

  // Source files
  const src = zip.folder('src');
  if (src) {
    src.file('main.tsx', `import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
`);

    src.file('index.css', `@import "tailwindcss";
`);

    src.file('App.tsx', appCode);
    src.file('types.ts', `export type ComplaintStatus = 'Pending' | 'In Progress' | 'Resolved' | 'Rejected';
export type Priority = 'Critical' | 'High' | 'Medium' | 'Low';

export interface ComplaintUpdate {
  date: string;
  status: string;
  note: string;
  officer?: string;
}

export interface Complaint {
  id: string;
  category: string;
  title: string;
  description: string;
  reporter: string;
  phone: string;
  location: string;
  department: string;
  status: ComplaintStatus;
  priority: Priority;
  date: string;
  image?: string;
  voiceTranscript?: string;
  lat: number;
  lng: number;
  assignedWorker?: string;
  updates: ComplaintUpdate[];
  acknowledgementDoc?: string;
}

export interface Department {
  id: string;
  name: string;
  head: string;
  staffCount: number;
  unresolvedCount: number;
  resolvedCount: number;
  rating: number;
}

export interface Scheme {
  id: string;
  title: string;
  ministry: string;
  description: string;
  benefits: string;
  category: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  chartType?: 'bar' | 'pie' | 'line' | 'insights';
  chartData?: { name: string; value: number; extra?: string }[];
}

export type UserRole = 'Citizen' | 'Officer' | 'MP';

export interface VillageStatus {
  name: string;
  complaintsCount: number;
  resolvedCount: number;
  infrastructureScore: number;
  waterScore: number;
  healthScore: number;
  safetyScore: number;
}
`);

    const data = src.folder('data');
    if (data) {
      data.file('dummyData.ts', `import { Complaint, Department, Scheme, VillageStatus } from '../types';

export const DUMMY_DEPARTMENTS: Department[] = [
  { id: 'dept-roads', name: 'Ministry of Road Transport & Highways / PWD', head: 'Shri Nitin Gadkari (Union Minister)', staffCount: 142, unresolvedCount: 18, resolvedCount: 312, rating: 4.6 },
  { id: 'dept-water', name: 'Ministry of Jal Shakti / Municipal Water Board', head: 'Shri C. R. Patil (Union Minister)', staffCount: 95, unresolvedCount: 22, resolvedCount: 185, rating: 4.1 },
  { id: 'dept-power', name: 'Ministry of Power / State DisCom', head: 'Shri Manohar Lal (Union Minister)', staffCount: 110, unresolvedCount: 11, resolvedCount: 298, rating: 4.4 },
  { id: 'dept-waste', name: 'Municipal Corporation / Solid Waste Management', head: 'Smt. Ananya Rao (Commissioner)', staffCount: 250, unresolvedCount: 35, resolvedCount: 512, rating: 3.9 },
  { id: 'dept-health', name: 'Ministry of Health & Family Welfare', head: 'Shri J. P. Nadda (Union Minister)', staffCount: 180, unresolvedCount: 8, resolvedCount: 145, rating: 4.5 },
  { id: 'dept-safety', name: 'State Police / Women Safety Cell', head: 'Shri Amit Shah (Union Minister)', staffCount: 160, unresolvedCount: 5, resolvedCount: 220, rating: 4.8 },
  { id: 'dept-edu', name: 'Department of School Education & Literacy', head: 'Shri Dharmendra Pradhan (Union Minister)', staffCount: 85, unresolvedCount: 14, resolvedCount: 95, rating: 4.2 },
  { id: 'dept-agri', name: 'Ministry of Agriculture & Farmers Welfare', head: 'Shri Shivraj Singh Chouhan (Union Minister)', staffCount: 75, unresolvedCount: 12, resolvedCount: 160, rating: 4.3 }
];

export const DUMMY_SCHEMES: Scheme[] = [
  { id: 'scheme-ayushman', title: 'Ayushman Bharat PM-JAY', ministry: 'Ministry of Health and Family Welfare', description: 'Provides free health insurance cover of up to ₹5 Lakh per family.', benefits: 'Cashless treatment, covers over 1,350 medical procedures.', category: 'Healthcare' },
  { id: 'scheme-jjm', title: 'Jal Jeevan Mission (JJM)', ministry: 'Ministry of Jal Shakti', description: 'Provides safe drinking water tap connections to all rural households.', benefits: '55 liters of clean water per capita per day.', category: 'Water' },
  { id: 'scheme-kisan', title: 'PM-KISAN Samman Nidhi', ministry: 'Ministry of Agriculture & Farmers Welfare', description: 'Direct benefit of ₹6,000 per year directly in bank accounts of farmer families.', benefits: '₹6,000 yearly credit to back purchase of inputs.', category: 'Agriculture' }
];

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'JV-2026-9041',
    category: 'Roads',
    title: 'Severe Potholes on Ram Mandir Bypass Link Road',
    description: 'There are huge potholes near the bypass link road causing accidents.',
    reporter: 'Rajesh Sharma',
    phone: '9876543210',
    location: 'Ram Mandir Bypass, Kalyanpur',
    department: 'Ministry of Road Transport & Highways / PWD',
    status: 'In Progress',
    priority: 'High',
    date: '2026-07-02',
    lat: 26.8467,
    lng: 80.9462,
    assignedWorker: 'Inspector Satish Yadav',
    updates: [
      { date: '2026-07-02', status: 'Submitted', note: 'Complaint filed.' },
      { date: '2026-07-03', status: 'In Progress', note: 'PWD Inspector assigned.' }
    ]
  }
];

export const DUMMY_VILLAGES: VillageStatus[] = [
  { name: 'Kalyanpur Khas', complaintsCount: 42, resolvedCount: 35, infrastructureScore: 82, waterScore: 78, healthScore: 85, safetyScore: 90 },
  { name: 'Ramgarh', complaintsCount: 68, resolvedCount: 41, infrastructureScore: 54, waterScore: 48, healthScore: 62, safetyScore: 58 }
];
`);
    }

    const components = src.folder('components');
    if (components) {
      components.file('Header.tsx', headerCode);
      components.file('Footer.tsx', footerCode);
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'janvoice-ai-governance-frontend.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
