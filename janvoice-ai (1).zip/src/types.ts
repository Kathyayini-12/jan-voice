/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ComplaintStatus = 'Pending' | 'In Progress' | 'Resolved' | 'Rejected';
export type Priority = 'Critical' | 'High' | 'Medium' | 'Low';

export interface ComplaintUpdate {
  date: string;
  status: string;
  note: string;
  officer?: string;
}

export interface Complaint {
  id: string;
  category: string;
  title: string;
  description: string;
  reporter: string;
  phone: string;
  location: string;
  department: string;
  status: ComplaintStatus;
  priority: Priority;
  date: string;
  image?: string;
  voiceTranscript?: string;
  lat: number;
  lng: number;
  assignedWorker?: string;
  updates: ComplaintUpdate[];
  acknowledgementDoc?: string;
  // Advanced AI metadata fields
  urgencyScore?: number;
  impactScore?: number;
  verificationScore?: number;
  feasibilityScore?: number;
  priorityScore?: number;
  affectedCount?: number;
  isDuplicate?: boolean;
  duplicateParentId?: string;
  duplicateCount?: number;
  suggestedAction?: string;
  estimatedResolutionTime?: string;
  verificationConfidence?: number;
  gpsVerified?: boolean;
  voiceRecordingUrl?: string;
  aiExplanation?: string;
}

export interface Department {
  id: string;
  name: string;
  head: string;
  staffCount: number;
  unresolvedCount: number;
  resolvedCount: number;
  rating: number;
}

export interface Scheme {
  id: string;
  title: string;
  ministry: string;
  description: string;
  benefits: string;
  category: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  chartType?: 'bar' | 'pie' | 'line' | 'insights';
  chartData?: { name: string; value: number; extra?: string }[];
}

export type UserRole = 'Citizen' | 'Officer' | 'MP';

export interface VillageStatus {
  name: string;
  complaintsCount: number;
  resolvedCount: number;
  infrastructureScore: number; // 0-100
  waterScore: number;
  healthScore: number;
  safetyScore: number;
}
